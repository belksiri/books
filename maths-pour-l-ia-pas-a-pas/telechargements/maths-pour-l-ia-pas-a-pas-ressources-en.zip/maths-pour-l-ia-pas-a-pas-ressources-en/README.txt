Maths for AI, Step by Step, Belk Siri: reader resources (English), version 1.1.0
Companion page: https://belksiri.github.io/books/maths-pour-l-ia-pas-a-pas/en.html

These files complement the book; they do not replace it. Do the pen-and-paper exercises first,
then the chapter's notebook.

Contents
  notebooks/               two notebooks per chapter:
                             chNN_a_completer.ipynb  to do after the book's exercises
                             chNN_corrige.ipynb      the annotated solution
                             chapter 1: ch01_a_completer.ipynb, ch01_corrige.ipynb (Reading data)
                             chapter 2: ch02_a_completer.ipynb, ch02_corrige.ipynb (Computing with vectors and matrices)
                             chapter 3: ch03_a_completer.ipynb, ch03_corrige.ipynb (Fitting a model)
                             chapter 4: ch04_a_completer.ipynb, ch04_corrige.ipynb (Reasoning with probabilities)
                             chapter 5: ch05_a_completer.ipynb, ch05_corrige.ipynb (Classifying and making a decision)
                             chapter 6: ch06_a_completer.ipynb, ch06_corrige.ipynb (Evaluating a model and measuring uncertainty)
                             chapter 7: ch07_a_completer.ipynb, ch07_corrige.ipynb (How neural networks compute)
                             chapter 8: ch08_a_completer.ipynb, ch08_corrige.ipynb (Measuring similarity)
                             chapter 9: ch09_a_completer.ipynb, ch09_corrige.ipynb (Reducing the number of dimensions)
  donnees/                 the book's datasets (D1-1, D5-1…), as CSV files (column names in French;
                           the notebooks use English names, see each notebook's variables table)
  requirements.txt         the Python libraries you need
  verifier_installation.py checks that Python and the libraries are ready

The notebooks already contain their data: they need no file to run.
The CSV files are provided for those who want to open them in a spreadsheet.

Working in your browser, nothing to install
  Open the companion page and click “Open in Colab” (a Google account is required).
  In Colab, choose File > Save a copy in Drive to keep your answers.

Working on your computer
  1. Install Python 3.10 or later (for example Anaconda, which already includes everything).
  2. In a terminal, go to this folder, then:
       python -m pip install -r requirements.txt
       python verifier_installation.py
  3. Start: jupyter notebook
  4. Open notebooks/ch01_a_completer.ipynb and run the cells in order (Shift + Enter).
     As long as an answer is missing, the check displays “not yet completed”, without an error.
