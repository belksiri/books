"""Comprueba que Python y las bibliotecas de los notebooks están listos.

    python verifier_installation.py
"""
import importlib
import sys

REQUIS = [("numpy", (1, 26)), ("pandas", (2, 2)), ("matplotlib", (3, 8))]
FACULTATIF = [("sklearn", (1, 4), "scikit-learn, una comparación del capítulo 4")]


def version(module):
    return tuple(int(x) for x in module.__version__.split(".")[:2] if x.isdigit())


def main():
    manque = 0
    py = sys.version_info[:2]
    print(("OK   " if py >= (3, 10) else "NON  ") + f"Python {sys.version.split()[0]} (3.10 o posterior)")
    manque += py < (3, 10)
    for nom, mini in REQUIS:
        try:
            m = importlib.import_module(nom)
            bon = version(m) >= mini
            print(("OK   " if bon else "NON  ") + f"{nom} {m.__version__} ({'.'.join(map(str, mini))} o posterior)")
            manque += not bon
        except ImportError:
            print(f"NON  {nom} no instalado : python -m pip install -r requirements.txt")
            manque += 1
    try:
        importlib.import_module("notebook")
        print("OK   Jupyter Notebook")
    except ImportError:
        try:
            importlib.import_module("jupyterlab")
            print("OK   JupyterLab (inicia: jupyter lab)")
        except ImportError:
            print("NON  Jupyter no instalado : python -m pip install -r requirements.txt")
            manque += 1
    for nom, mini, role in FACULTATIF:
        try:
            m = importlib.import_module(nom)
            print(f"OK   {role} : {m.__version__}")
        except ImportError:
            print(f"--   opcional, no instalado : {role}")
    print("\nTodo está listo: inicia jupyter notebook." if not manque else
          f"\n{manque} elemento(s) por instalar o actualizar.")
    return 1 if manque else 0


if __name__ == "__main__":
    sys.exit(main())
