"""Vérifie que Python et les bibliothèques des notebooks sont prêts.

    python verifier_installation.py
"""
import importlib
import sys

REQUIS = [("numpy", (1, 26)), ("pandas", (2, 2)), ("matplotlib", (3, 8))]
FACULTATIF = [("sklearn", (1, 4), "scikit-learn, une comparaison du chapitre 4")]


def version(module):
    return tuple(int(x) for x in module.__version__.split(".")[:2] if x.isdigit())


def main():
    manque = 0
    py = sys.version_info[:2]
    print(("OK   " if py >= (3, 10) else "NON  ") + f"Python {sys.version.split()[0]} (3.10 ou plus récent)")
    manque += py < (3, 10)
    for nom, mini in REQUIS:
        try:
            m = importlib.import_module(nom)
            bon = version(m) >= mini
            print(("OK   " if bon else "NON  ") + f"{nom} {m.__version__} ({'.'.join(map(str, mini))} ou plus récent)")
            manque += not bon
        except ImportError:
            print(f"NON  {nom} absent : python -m pip install -r requirements.txt")
            manque += 1
    try:
        importlib.import_module("notebook")
        print("OK   Jupyter Notebook")
    except ImportError:
        try:
            importlib.import_module("jupyterlab")
            print("OK   JupyterLab (lancez : jupyter lab)")
        except ImportError:
            print("NON  Jupyter absent : python -m pip install -r requirements.txt")
            manque += 1
    for nom, mini, role in FACULTATIF:
        try:
            m = importlib.import_module(nom)
            print(f"OK   {role} : {m.__version__}")
        except ImportError:
            print(f"--   facultatif, absent : {role}")
    print("\nTout est prêt : lancez jupyter notebook." if not manque else
          f"\n{manque} élément(s) à installer ou à mettre à jour.")
    return 1 if manque else 0


if __name__ == "__main__":
    sys.exit(main())
