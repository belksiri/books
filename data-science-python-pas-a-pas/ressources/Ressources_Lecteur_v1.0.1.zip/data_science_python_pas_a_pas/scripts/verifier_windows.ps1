﻿# Vérification complète du projet SmartMarket sous Windows (PowerShell).
#
# Usage, depuis le dossier du projet :
#   powershell -ExecutionPolicy Bypass -File scripts\verifier_windows.ps1
#
# Le script crée (ou réutilise) l'environnement .venv, installe les
# dépendances figées, puis enchaîne : diagnostic, empreintes des données,
# exécution d'un notebook, projet de bout en bout et tests. Il écrit un
# rapport dans outputs\reports\verification_windows.txt et se termine
# avec le code 0 si tout a réussi, 1 sinon.
#
# Il fonctionne avec les deux archives : dans l'archive des corrigés, il
# ajoute les contrôles statistiques et les tests des corrigés.
#
# Ce script n'a pas été exécuté par l'auteur sur une machine Windows :
# il a fait l'objet d'une relecture statique (voir GUIDE_RESSOURCES.md).

$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONUTF8 = "1"
$env:MPLBACKEND = "Agg"

$rapport = "outputs\reports\verification_windows.txt"
New-Item -ItemType Directory -Force -Path "outputs\reports" | Out-Null
$lignes = @("Vérification Windows — $(Get-Date -Format s)")
$echecs = 0

function Etape([string]$nom, [scriptblock]$action) {
    Write-Host "`n== $nom" -ForegroundColor Cyan
    try {
        & $action
        if ($LASTEXITCODE -ne 0) { throw "code de sortie $LASTEXITCODE" }
        Write-Host "   OK" -ForegroundColor Green
        $script:lignes += "OK     $nom"
    } catch {
        Write-Host "   ÉCHEC : $_" -ForegroundColor Red
        $script:lignes += "ÉCHEC  $nom : $_"
        $script:echecs += 1
    }
}

Etape "Python 3.12 à 3.14 disponible (lanceur py)" {
    py -3 -c "import sys; assert (3, 12) <= sys.version_info[:2] <= (3, 14), sys.version"
}

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Etape "Création de l'environnement virtuel" { py -3 -m venv .venv }
}
$py = ".venv\Scripts\python.exe"

Etape "Installation des dépendances figées" {
    & $py -m pip install --upgrade pip --quiet
    if ($LASTEXITCODE -eq 0) { & $py -m pip install -r requirements.txt --quiet }
    if ($LASTEXITCODE -eq 0) { & $py -m pip install -e . --quiet }
}

Etape "Diagnostic de l'environnement" {
    & $py -m smartmarket.verifier_environnement
}

Etape "Empreintes SHA-256 des données (fins de ligne intactes)" {
    & $py -c @"
import hashlib, json
from smartmarket.chemins import FICHIER_MANIFESTE, RACINE
man = json.loads(FICHIER_MANIFESTE.read_text(encoding='utf-8'))
for nom, info in man['fichiers'].items():
    reel = hashlib.sha256((RACINE / nom).read_bytes()).hexdigest()
    assert reel == info['sha256'], nom
print(len(man['fichiers']), 'fichiers identiques')
"@
}

$corriges = Test-Path "src\smartmarket\controles_donnees.py"
if ($corriges) {
    Etape "Contrôles statistiques des données (archive des corrigés)" {
        & $py -m smartmarket.controles_donnees
    }
}

Etape "Exécution d'un notebook depuis un noyau propre" {
    # nbclient est installé avec jupyter (requirements.txt)
    & $py -c @"
import nbformat
from nbclient import NotebookClient
nb = nbformat.read('notebooks/06_premier_dataframe.ipynb', as_version=4)
NotebookClient(nb, timeout=600, kernel_name='python3',
               resources={'metadata': {'path': 'notebooks'}}).execute()
print('notebook exécuté')
"@
}

Etape "Projet de bout en bout" {
    & $py -m smartmarket.pipeline
    if ($LASTEXITCODE -eq 0) { & $py -m smartmarket.presentation }
}

Etape "Tests automatiques" {
    & $py -m pytest
}

if ($corriges) {
    Etape "Tests des corrigés (archive des corrigés)" {
        & $py -m pytest tests_corriges
    }
}

$lignes += "Échecs : $echecs"
$lignes | Set-Content -Encoding UTF8 $rapport
Write-Host "`nRapport : $rapport"
if ($echecs -gt 0) { exit 1 } else { exit 0 }
