# Dictionnaire des données SmartMarket

Données **fictives**, créées pour le livre « Data science avec Python,
pas à pas ». Situation extraite du système client de SmartMarket.

**Lecture du fichier** (séparateur `;`, décimale `,`, UTF-8) :

```python
import pandas as pd
from smartmarket.chemins import FICHIER_BRUT

clients = pd.read_csv(FICHIER_BRUT, sep=";", decimal=",")
```

- Date d'observation : **31 décembre 2024**.
- `depense_suivante` et `parti_6m` ont été ajoutées plus tard par
  l'équipe data, à partir des commandes de 2025.
- Une ligne correspond en principe à un client. En principe.

| Colonne | Signification | Valeurs | Source |
|---|---|---|---|
| `client_id` | Identifiant du client | C000001 à C006000 | historique 2024 |
| `date_inscription` | Date de création du compte | jj/mm/aaaa (quelques aaaa-mm-jj) | historique 2024 |
| `age` | Âge déclaré à l'inscription | années | historique 2024 |
| `region` | Zone de livraison | 7 zones | historique 2024 |
| `canal` | Canal d'acquisition | recherche, réseaux sociaux, parrainage, publicité, direct | historique 2024 |
| `abonnement` | Abonnement premium actif au 31/12/2024 | oui / non (variantes dans le brut) | historique 2024 |
| `nb_commandes_12m` | Commandes passées en 2024 | nombre | historique 2024 |
| `depense_12m` | Montant dépensé en 2024 | « 1 234,50 € » | historique 2024 |
| `recence_jours` | Jours entre la dernière commande et le 31/12/2024 | jours | historique 2024 |
| `part_promo` | Part des commandes 2024 passées avec un code promo | 0 à 1 | historique 2024 |
| `nb_retours_12m` | Articles retournés en 2024 | nombre | historique 2024 |
| `nb_contacts_sav` | Contacts avec le service client en 2024 | nombre | historique 2024 |
| `satisfaction` | Note de la dernière enquête | 1 à 5 | historique 2024 |
| `delai_livraison` | Délai moyen de livraison constaté | jours | historique 2024 |
| `ouverture_emails` | Taux d'ouverture des e-mails en 2024 | 0 à 1 | historique 2024 |
| `segment_mkt` | Segment de l'ancienne règle marketing | VIP, Fidèle, Standard, À relancer | historique 2024 |
| `statut_compte` | Statut du compte dans l'outil client (CRM) | actif, inactif, fermé | export CRM du 30/06/2025 |
| `depense_suivante` | Dépense totale 2025 | euros | commandes 2025 |
| `parti_6m` | Aucune commande du 01/01 au 30/06/2025 | 1 = parti | commandes 2025 |

## Variables que tu créeras toi-même

| Colonne | Signification |
|---|---|
| `anciennete_mois` | Mois d'ancienneté au 31/12/2024 |
| `panier_moyen` | Dépense 2024 par commande |
| `taux_retour` | Retours par commande |
| `a_repondu` | A répondu à l'enquête |
| `log_depense` | Logarithme de la dépense 2024 |

## Questions à te poser avant d'utiliser une colonne

1. Cette information était-elle connue le 31/12/2024 ?
2. Est-ce un identifiant ou une étiquette technique ?
3. Que signifie une valeur manquante ?
