# Data science avec Python, pas à pas

**Un seul projet, de l'installation à la décision : explorer, prédire et
segmenter des clients.**

Livre de **Belk Siri**.

Version **v1.0.1** (septembre 2026) des ressources du livre, en deux
archives :

- `Ressources_Lecteur_v1.0.1.zip` : données, notebooks de cours et
  énoncés d'exercices, code du projet, tests et scripts. C'est ce dossier.
- `Ressources_Corriges_v1.0.1.zip` : le même projet, plus les notebooks
  corrigés, les fichiers de vérité de la génération des données, la
  génération et la validation statistique, et les résultats attendus
  (voir `GUIDE_CORRIGES.md` dans cette archive).

Ce dossier contient les données, le code et les notebooks du projet
fil rouge **SmartMarket**, une boutique en ligne **fictive**. Aucune donnée
ne concerne une personne réelle.

## Démarrer en 15 minutes, sans rien installer

Ouvre `notebooks/00_demarrage_express.ipynb` dans VS Code **ou** dans
Google Colab (Fichier › Importer le notebook), puis exécute les cellules
une par une. L'extrait de données est inclus dans le notebook.

## Installer le projet complet

Python 3.12, 3.13 ou 3.14 est nécessaire. Les installations ont été
vérifiées sous macOS. Compatibilité Windows préparée et revue
statiquement, mais non validée sur une machine Windows.

Depuis le dossier du projet :

**macOS**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
python -m smartmarket.verifier_environnement
```

**Windows (PowerShell)**

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
python -m smartmarket.verifier_environnement
```

Si PowerShell refuse l'activation :
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, puis recommence.

Le diagnostic doit se terminer par :

```
Environnement SmartMarket prêt.
```

## Lancer le projet de bout en bout

Environnement activé, depuis le dossier du projet :

    python -m smartmarket.pipeline      # modèles, scores
    python -m smartmarket.presentation  # six diapositives
    python -m pytest                    # vérifications

Les résultats sont écrits dans `outputs/` : modèles,
métriques, figures et rapports. Ce dossier se régénère :
ne le modifie pas à la main. Les réglages sont réunis
dans `src/smartmarket/config.py`.

## Lire les données

Tous les CSV utilisent la même convention : **séparateur `;`, décimale `,`,
encodage UTF-8** (compatible avec Excel en français). La commande est
toujours :

```python
import pandas as pd
from smartmarket.chemins import FICHIER_BRUT

clients = pd.read_csv(FICHIER_BRUT, sep=";", decimal=",")
```

`smartmarket.chemins` retrouve la racine du projet quel que soit le dossier
courant : le code fonctionne aussi depuis `notebooks/` dans VS Code.

**Ne modifie jamais `data/raw/`** et ne réenregistre pas le CSV brut avec
Excel : le diagnostic vérifie son empreinte SHA-256.

## Contenu

| Dossier | Rôle |
|---|---|
| `data/raw/smartmarket_clients.csv` | export brut, imparfait (6 120 lignes) |
| `data/processed/clients_propres.csv` | point de reprise nettoyé (6 000 clients) |
| `data/scoring/clients_a_scorer.csv` | 800 clients observés au 31/12/2025, sans cibles |
| `data/reference/` | dictionnaires des données, manifeste des empreintes |
| `notebooks/` | un notebook par chapitre ; `exercices/` (énoncés), `annexes/` |
| `src/smartmarket/` | chemins, nettoyage, diagnostic, configuration, modèles, projet |
| `tests/` | tests automatisés (`python -m pytest`) |
| `outputs/` | figures, modèles, métriques et rapports que tu produis |
| `scripts/` | vérification sous Windows (`verifier_windows.ps1`) |

Les notebooks corrigés, les fichiers de vérité, les modules de génération
et de contrôle des données et leurs tests sont dans l'archive des
corrigés.

## Vérifier les données

`data/reference/manifest.json` enregistre la graine (`20241231`) et
l'empreinte SHA-256 de chaque fichier de données de ce dossier ; le
diagnostic et `python -m pytest` les vérifient. La régénération des
données (`python -m smartmarket.generer_donnees`) et leurs contrôles
statistiques (`python -m smartmarket.controles_donnees`) sont fournis
dans l'archive des corrigés.

## Licences

Code : MIT. Données fictives : CC BY 4.0. Polices du livre (Source Serif 4,
Source Sans 3, JetBrains Mono, STIX Two Math) : SIL Open Font License 1.1,
licences jointes aux sources du livre (`livre/assets/fonts/`).

Voir aussi `GUIDE_RESSOURCES.md` (contenu, systèmes testés).
