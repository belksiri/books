"""Retrouver les dossiers du projet, quel que soit le dossier courant.

Dans VS Code, un notebook s'exécute par défaut depuis SON dossier
(`notebooks/`). Un chemin relatif comme "data/raw/..." y échoue.
Ce module calcule donc les chemins à partir de la racine du projet.

Usage :
    from smartmarket.chemins import DONNEES_BRUTES
    clients = pd.read_csv(DONNEES_BRUTES / "smartmarket_clients.csv",
                          sep=";", decimal=",")
"""

from pathlib import Path

MARQUEUR = "pyproject.toml"


def trouver_racine(depart=None):
    """Remonte les dossiers jusqu'à trouver pyproject.toml."""
    candidats = []
    if depart is not None:
        candidats.append(Path(depart).resolve())
    # 1) le dossier qui contient ce fichier (installation -e .)
    candidats.append(Path(__file__).resolve().parent)
    # 2) le dossier courant (notebook, terminal)
    candidats.append(Path.cwd().resolve())
    for point in candidats:
        for dossier in (point, *point.parents):
            if (dossier / MARQUEUR).exists() and (dossier / "data").is_dir():
                return dossier
    raise FileNotFoundError(
        "Racine du projet introuvable : ouvre le dossier "
        "« data_science_python_pas_a_pas » dans VS Code, "
        "ou lance le notebook depuis ce dossier."
    )


RACINE = trouver_racine()
DONNEES = RACINE / "data"
DONNEES_BRUTES = DONNEES / "raw"
DONNEES_PROPRES = DONNEES / "processed"
DONNEES_SCORING = DONNEES / "scoring"
DONNEES_REFERENCE = DONNEES / "reference"
SORTIES = RACINE / "outputs"
FIGURES = SORTIES / "figures"
MODELES = SORTIES / "models"
METRIQUES = SORTIES / "metrics"
RAPPORTS = SORTIES / "reports"

FICHIER_BRUT = DONNEES_BRUTES / "smartmarket_clients.csv"
FICHIER_PROPRE = DONNEES_PROPRES / "clients_propres.csv"
FICHIER_SCORING = DONNEES_SCORING / "clients_a_scorer.csv"
FICHIER_VERITE = DONNEES_REFERENCE / "smartmarket_verite.csv"
FICHIER_MANIFESTE = DONNEES_REFERENCE / "manifest.json"

# Convention unique de tous les CSV du projet
CSV = {"sep": ";", "decimal": ",", "encoding": "utf-8"}
