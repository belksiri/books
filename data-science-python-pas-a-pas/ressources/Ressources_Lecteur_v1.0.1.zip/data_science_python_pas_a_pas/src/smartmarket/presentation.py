"""Présentation du projet en six diapositives (PDF 16:9).

    python -m smartmarket.pipeline      # d'abord : calcule les résultats
    python -m smartmarket.presentation  # puis : outputs/reports/...pdf

Chaque diapositive porte un seul message, écrit comme une phrase, et
un seul élément de preuve. Tous les nombres viennent de
outputs/metrics/projet.json : rien n'est recopié à la main.
"""

import json
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.image as mpimg  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402

from smartmarket.chemins import (FIGURES, METRIQUES,  # noqa: E402
                                 RAPPORTS)
from smartmarket.pipeline import fr  # noqa: E402

LARGEUR, HAUTEUR = 13.33, 7.5          # pouces, format 16:9
BLEU, GRIS, ENCRE = "#1f5f8b", "#6b7178", "#1b1b1b"


def diapositive(pdf, titre, message, corps=None, image=None,
                numero=None):
    fig = plt.figure(figsize=(LARGEUR, HAUTEUR))
    fig.text(0.06, 0.88, titre.upper(), fontsize=14, color=GRIS,
             weight="bold")
    fig.text(0.06, 0.76, message, fontsize=26, color=ENCRE,
             weight="bold", wrap=True)
    if corps:
        fig.text(0.06, 0.62, corps, fontsize=22, color=ENCRE,
                 va="top", linespacing=1.6)
    if image is not None:
        ax = fig.add_axes((0.50, 0.08, 0.45, 0.58))
        ax.imshow(mpimg.imread(image))
        ax.axis("off")
    if numero:
        fig.text(0.94, 0.04, f"{numero} / 6", fontsize=12,
                 color=GRIS, ha="right")
    fig.text(0.06, 0.04, "SmartMarket — données fictives",
             fontsize=12, color=GRIS)
    pdf.savefig(fig)
    plt.close(fig)


def main():
    bilan = json.loads((METRIQUES / "projet.json").read_text(
        encoding="utf-8"))
    d, p, s = bilan["depense"], bilan["depart"], bilan["scoring"]
    profils = bilan["profils"]
    chemin = RAPPORTS / "presentation_smartmarket.pdf"
    with PdfPages(chemin) as pdf:
        diapositive(
            pdf, "La question",
            "Qui contacter en priorité pour limiter les départs ?",
            "Budget de fidélisation limité.\n"
            "800 clients à évaluer, au 31/12/2025.\n"
            "Modèles appris sur les clients de 2024.", numero=1)
        diapositive(
            pdf, "La méthode",
            "Deux prédictions, combinées en valeur à risque",
            "probabilité de départ × dépense future prévue\n\n"
            "Modèles validés sur 4 800 clients,\n"
            "vérifiés une seule fois sur 1 200 autres.", numero=2)
        diapositive(
            pdf, "Le départ",
            f"Le modèle repère {fr(p['rappel_test'], pourcent=True)}"
            " des départs",
            f"AUC de test : {fr(p['auc_test'], 2)}\n"
            f"Précision au seuil {fr(p['seuil'], 2)} : "
            f"{fr(p['precision_test'], pourcent=True)}\n"
            f"Référence « personne ne part » : rappel nul",
            numero=3)
        diapositive(
            pdf, "La priorisation",
            f"Le top 20 % des clients porte "
            f"{fr(s['part_top20'], pourcent=True)} de la valeur "
            "à risque",
            f"{s['n_prioritaires']} clients à contacter\n"
            f"sur {s['n_clients']}.",
            image=FIGURES / "concentration_valeur.png", numero=4)
        piliers = profils["Piliers"]
        diapositive(
            pdf, "Les profils",
            "Quatre profils, quatre actions",
            f"Piliers : {fr(piliers['depart'], pourcent=True)} "
            "de départs,\nmais l'essentiel de la dépense.\n"
            "Endormis : relance peu coûteuse.\n"
            "Nouveaux inscrits : parcours d'accueil.",
            image=FIGURES / "depart_profils.png", numero=5)
        diapositive(
            pdf, "Décision et limites",
            "Lancer un test sur les clients prioritaires",
            "Mesurer l'effet avec un groupe témoin.\n"
            "Hypothèses de coût à confirmer.\n"
            f"Erreur de dépense : {fr(d['mae_test_knn'])} € "
            "en moyenne.\nDonnées fictives : méthode transposable,"
            "\nchiffres non.", numero=6)
    print(chemin.name, "enregistré : 6 diapositives")
    return 0


if __name__ == "__main__":
    sys.exit(main())
