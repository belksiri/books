"""Paramètres du projet SmartMarket, réunis en un seul endroit.

Chaque valeur a été choisie dans le livre, jamais sur le jeu de test :
- séparation et plis : chapitres 12 et 17 ;
- réglage du KNN de dépense : chapitre 19 ;
- hypothèses de coût du seuil de départ : chapitre 22 ;
- nombre de profils : chapitre 24.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    graine: int = 42
    part_test: float = 0.2
    plis: int = 5
    k_voisins: int = 50
    poids_voisins: str = "distance"
    cout_contact: float = 15.0
    perte_depart: float = 90.0
    efficacite: float = 0.40
    n_profils: int = 4


CONFIG = Config()
