"""Projet SmartMarket de bout en bout, en une commande.

    python -m smartmarket.pipeline

Étapes : charger le fichier propre, séparer, valider les modèles,
évaluer une seule fois sur le test, scorer les clients récents,
segmenter, puis enregistrer modèles, métriques, figures et rapports
dans outputs/. Les résultats sont identiques à ceux des chapitres 19,
22 et 24.
"""

import json
import sys
import time

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.dummy import DummyRegressor  # noqa: E402
from sklearn.metrics import (mean_absolute_error,  # noqa: E402
                             precision_score, recall_score,
                             roc_auc_score)
from sklearn.model_selection import (KFold,  # noqa: E402
                                     StratifiedKFold,
                                     cross_val_predict,
                                     cross_val_score,
                                     train_test_split)

from smartmarket import modeles  # noqa: E402
from smartmarket.chemins import (CSV, FICHIER_PROPRE,  # noqa: E402
                                 FICHIER_SCORING, FIGURES,
                                 METRIQUES, MODELES, RAPPORTS)
from smartmarket.config import CONFIG  # noqa: E402


_debut = time.perf_counter()


def etape(message):
    duree = time.perf_counter() - _debut
    print(f"-> {message}", flush=True)
    return duree


def charger():
    clients = pd.read_csv(FICHIER_PROPRE, **CSV)
    a_scorer = pd.read_csv(FICHIER_SCORING, **CSV)
    assert not set(modeles.INTERDITES[1:]) & set(a_scorer)
    return clients, a_scorer


def prevoir_depense(train, test, config):
    y_train = train["depense_suivante"]
    plis = KFold(config.plis, shuffle=True,
                 random_state=config.graine)
    mae = {}
    for nom, modele in [
            ("médiane", DummyRegressor(strategy="median")),
            ("KNN", modeles.modele_depense(config))]:
        s = -cross_val_score(modele, train, y_train, cv=plis,
                             scoring="neg_mean_absolute_error")
        mae[nom] = {"moyenne": s.mean(), "ecart_type": s.std()}
    knn = modeles.modele_depense(config).fit(train, y_train)
    ref = DummyRegressor(strategy="median").fit(train, y_train)
    y_test = test["depense_suivante"]
    return knn, {
        "mae_cv": mae,
        "mae_test_knn": mean_absolute_error(
            y_test, knn.predict(test)),
        "mae_test_mediane": mean_absolute_error(
            y_test, ref.predict(test))}


def prevoir_depart(train, test, config):
    y_train, y_test = train["parti_6m"], test["parti_6m"]
    plis = StratifiedKFold(config.plis, shuffle=True,
                           random_state=config.graine)
    proba_cv = cross_val_predict(
        modeles.modele_depart(), train, y_train, cv=plis,
        method="predict_proba")[:, 1]
    seuil = modeles.seuil_optimal(proba_cv, y_train, config)
    modele = modeles.modele_depart().fit(train, y_train)
    proba = modele.predict_proba(test)[:, 1]
    decision = (proba >= seuil).astype(int)
    return modele, {
        "auc_cv": roc_auc_score(y_train, proba_cv),
        "seuil": seuil,
        "auc_test": roc_auc_score(y_test, proba),
        "precision_test": precision_score(y_test, decision),
        "rappel_test": recall_score(y_test, decision)}


def scorer(a_scorer, depart, depense, seuil):
    scores = a_scorer[["client_id"]].copy()
    scores["probabilite_depart"] = depart.predict_proba(
        a_scorer)[:, 1]
    scores["depense_future_prevue"] = depense.predict(
        a_scorer)
    scores["valeur_a_risque"] = (
        scores["probabilite_depart"]
        * scores["depense_future_prevue"])
    scores = scores.sort_values("valeur_a_risque",
                                ascending=False)
    scores["prioritaire"] = scores["probabilite_depart"] >= seuil
    return scores


def figure_concentration(scores, chemin):
    cumul = (scores["valeur_a_risque"].cumsum()
             / scores["valeur_a_risque"].sum())
    rang = 100 * np.arange(1, len(cumul) + 1) / len(cumul)
    fig, ax = plt.subplots(figsize=(6, 3.8))
    ax.plot(rang, 100 * cumul.to_numpy(), color="#1f5f8b")
    ax.plot([0, 100], [0, 100], "--", color="#8c8c8c")
    ax.set_xlabel("Clients contactés (%)")
    ax.set_ylabel("Valeur à risque couverte (%)")
    fig.tight_layout()
    fig.savefig(chemin, dpi=150)
    plt.close(fig)


def figure_profils(clients, chemin):
    depart = clients.groupby("profil")["parti_6m"].mean()
    depart = depart.sort_values()
    fig, ax = plt.subplots(figsize=(6, 3.2))
    ax.barh(depart.index, 100 * depart, color="#1f5f8b")
    ax.set_xlabel("Clients partis en 2025 (%)")
    fig.tight_layout()
    fig.savefig(chemin, dpi=150)
    plt.close(fig)


def fr(x, decimales=0, pourcent=False):
    """Nombre au format français : virgule décimale, %."""
    valeur = 100 * x if pourcent else x
    texte = f"{valeur:,.{decimales}f}"
    texte = texte.replace(",", " ").replace(".", ",")
    return texte + (" %" if pourcent else "")


def ecrire_synthese(bilan, chemin):
    d, p, s = bilan["depense"], bilan["depart"], bilan["scoring"]
    lignes = [
        "# Synthèse du projet SmartMarket",
        "",
        "Données fictives. Modèles appris au 31/12/2024,",
        "appliqués aux 800 clients observés au 31/12/2025.",
        "",
        "## Dépense 2025",
        f"- Modèle : KNN à {CONFIG.k_voisins} voisins.",
        f"- Erreur moyenne sur le test : "
        f"{fr(d['mae_test_knn'])} €, contre "
        f"{fr(d['mae_test_mediane'])} € pour la médiane.",
        "",
        "## Départ au premier semestre 2025",
        f"- AUC sur le test : {fr(p['auc_test'], 2)}.",
        f"- Seuil de contact : {fr(p['seuil'], 2)} ; "
        f"rappel {fr(p['rappel_test'], pourcent=True)}, "
        f"précision {fr(p['precision_test'], pourcent=True)}.",
        "",
        "## Clients à scorer",
        f"- {s['n_prioritaires']} clients prioritaires sur "
        f"{s['n_clients']}.",
        f"- Les 20 % de clients à plus forte valeur à risque "
        f"couvrent {fr(s['part_top20'], pourcent=True)} de la "
        f"valeur à risque.",
        "",
        "## Limites",
        "- Données fictives ; hypothèses de coût à confirmer.",
        "- Corrélations, pas causes : l'effet des actions "
        "reste à mesurer avec un groupe témoin.",
    ]
    chemin.write_text("\n".join(lignes) + "\n",
                      encoding="utf-8")


def executer(config=CONFIG):
    for dossier in (FIGURES, METRIQUES, MODELES, RAPPORTS):
        dossier.mkdir(parents=True, exist_ok=True)
    etape("Chargement des données")
    clients, a_scorer = charger()
    train, test = train_test_split(
        clients, test_size=config.part_test,
        random_state=config.graine)
    etape("Modèle de dépense : validation et test")
    depense, bilan_depense = prevoir_depense(
        train, test, config)
    etape("Modèle de départ : seuil, validation et test")
    depart, bilan_depart = prevoir_depart(
        train, test, config)
    etape("Scoring des clients récents")
    scores = scorer(a_scorer, depart, depense,
                    bilan_depart["seuil"])
    top20 = scores["valeur_a_risque"].head(
        int(0.2 * len(scores))).sum()
    etape("Segmentation des clients")
    seg = modeles.segmentation(clients, config)
    clients = clients.assign(profil=seg["profils"])
    scores["profil"] = modeles.affecter_profils(
        a_scorer.set_index("client_id").loc[
            scores["client_id"]].reset_index(), seg)
    etape("Enregistrement des résultats")
    joblib.dump(depense, MODELES / "modele_depense.joblib")
    joblib.dump(depart, MODELES / "modele_depart.joblib")
    joblib.dump(seg, MODELES / "segmentation.joblib")
    scores.round(3).to_csv(RAPPORTS / "scores_clients.csv",
                           index=False, **CSV)
    figure_concentration(
        scores, FIGURES / "concentration_valeur.png")
    figure_profils(clients, FIGURES / "depart_profils.png")
    bilan = {
        "config": config.__dict__,
        "depense": bilan_depense,
        "depart": bilan_depart,
        "scoring": {
            "n_clients": len(scores),
            "n_prioritaires": int(scores["prioritaire"].sum()),
            "part_top20": top20
            / scores["valeur_a_risque"].sum()},
        "profils": clients.groupby("profil").agg(
            clients=("client_id", "count"),
            depart=("parti_6m", "mean")).round(3)
            .to_dict("index"),
    }
    (METRIQUES / "projet.json").write_text(
        json.dumps(bilan, indent=2, ensure_ascii=False,
                   default=float), encoding="utf-8")
    ecrire_synthese(bilan, RAPPORTS / "synthese.md")
    etape("Terminé : résultats dans outputs/")
    return bilan


def main():
    bilan = executer()
    d, p = bilan["depense"], bilan["depart"]
    print(f"MAE de test (dépense) : {fr(d['mae_test_knn'], 1)} €")
    print(f"AUC de test (départ) : {fr(p['auc_test'], 3)}")
    print(f"Clients prioritaires : "
          f"{bilan['scoring']['n_prioritaires']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
