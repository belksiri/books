"""Nettoyer le fichier brut SmartMarket et créer les variables dérivées.

Cette fonction produit `data/processed/clients_propres.csv`, le point
de reprise des chapitres qui ne portent pas sur le nettoyage. Elle sert
aussi de corrigé au notebook 02.

Règles de nettoyage (documentées dans le dictionnaire) :
- doublons exacts supprimés ; quasi-doublons : on garde, pour chaque
  client_id, la ligne la plus complète ;
- régions, canaux, abonnement : écritures harmonisées ;
- dates jj/mm/aaaa ou aaaa-mm-jj ; montants « 1 234,50 € » ;
- valeurs impossibles remplacées par une valeur manquante : âge hors
  18–100, note hors 1–5, délai > 30 jours, retours > commandes.
Les valeurs manquantes restent manquantes : l'imputation se fait
plus tard, dans un pipeline, sur les seules données d'entraînement.
"""

from __future__ import annotations

import re
import unicodedata
from datetime import date

import numpy as np
import pandas as pd

REGIONS = ["Île-de-France", "Nord-Est", "Nord-Ouest", "Sud-Est",
           "Sud-Ouest", "Centre", "Outre-mer"]
CANAUX = ["recherche", "réseaux sociaux", "parrainage", "publicité",
          "direct"]

COLONNES_PROPRES = [
    "client_id", "date_inscription", "anciennete_mois", "age",
    "region", "canal", "abonnement", "nb_commandes_12m", "depense_12m",
    "panier_moyen", "log_depense", "recence_jours", "part_promo",
    "nb_retours_12m", "taux_retour", "nb_contacts_sav", "satisfaction",
    "a_repondu", "delai_livraison", "ouverture_emails", "segment_mkt",
    "statut_compte", "depense_suivante", "parti_6m",
]


def _cle(texte):
    """'  Île de-France ' -> 'iledefrance' (sans accents ni séparateurs)."""
    if pd.isna(texte):
        return ""
    t = unicodedata.normalize("NFKD", str(texte))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^a-z]", "", t.lower())


_ALIAS_REGION = {_cle(r): r for r in REGIONS}
_ALIAS_REGION.update({"idf": "Île-de-France", "domtom": "Outre-mer"})
_ALIAS_CANAL = {_cle(c): c for c in CANAUX}
_ALIAS_CANAL.update({"moteurderecherche": "recherche",
                     "accesdirect": "direct"})
_ABONNEMENT = {"oui": True, "1": True, "true": True,
               "non": False, "0": False, "false": False}


def convertir_euros(serie):
    """'1 234,50 €' -> 1234.5 (espaces normaux ou insécables)."""
    texte = (serie.astype("string")
             .str.replace(r"[\s  €]", "", regex=True)
             .str.replace(",", ".", regex=False))
    return pd.to_numeric(texte.replace("", pd.NA), errors="coerce")


def convertir_dates(serie):
    """Dates jj/mm/aaaa, et quelques aaaa-mm-jj."""
    fr = pd.to_datetime(serie, format="%d/%m/%Y", errors="coerce")
    iso = pd.to_datetime(serie, format="%Y-%m-%d", errors="coerce")
    return fr.fillna(iso)


def dedoublonner(df):
    """Doublons exacts, puis ligne la plus complète par client_id."""
    df = df.drop_duplicates()
    completude = df.notna().sum(axis=1)
    return (df.assign(_completude=completude)
              .sort_values(["client_id", "_completude"],
                           ascending=[True, False])
              .drop_duplicates("client_id")
              .drop(columns="_completude")
              .reset_index(drop=True))


def preparer_formats(brut):
    """Étapes du chapitre 9 : écritures, dates, montants, doublons.

    Les valeurs impossibles et les variables dérivées (chapitre 10)
    ne sont pas traitées ici.
    """
    df = brut.copy()
    for col in ["region", "canal", "abonnement", "segment_mkt",
                "statut_compte", "client_id", "date_inscription",
                "depense_12m"]:
        if col in df:
            df[col] = df[col].astype("string").str.strip()
            df[col] = df[col].replace("", pd.NA)

    # Harmoniser les écritures AVANT de chercher les quasi-doublons
    df["region"] = df["region"].map(_cle).map(_ALIAS_REGION)
    df["canal"] = df["canal"].map(_cle).map(_ALIAS_CANAL)
    df["abonnement"] = (df["abonnement"].str.lower()
                        .map(_ABONNEMENT).astype("boolean"))
    df["date_inscription"] = convertir_dates(df["date_inscription"])
    df["depense_12m"] = convertir_euros(df["depense_12m"])
    return dedoublonner(df)


def nettoyer_clients(brut, date_observation=date(2024, 12, 31)):
    """Renvoie le tableau propre, trié par client_id."""
    df = preparer_formats(brut)

    # Valeurs impossibles -> manquantes
    df["age"] = df["age"].where(df["age"].between(18, 100))
    df["satisfaction"] = df["satisfaction"].where(
        df["satisfaction"].between(1, 5))
    df["delai_livraison"] = df["delai_livraison"].where(
        df["delai_livraison"] <= 30)
    incoherent = df["nb_retours_12m"] > df["nb_commandes_12m"]
    df.loc[incoherent, "nb_retours_12m"] = pd.NA

    # Variables dérivées
    obs = pd.Timestamp(date_observation)
    jours = (obs - df["date_inscription"]).dt.days
    df["anciennete_mois"] = np.floor(jours / 30.44).astype("Int64")
    commandes = df["nb_commandes_12m"].astype("Float64")
    df["panier_moyen"] = (df["depense_12m"] / commandes.where(
        commandes > 0)).round(2)
    df["taux_retour"] = (df["nb_retours_12m"] / commandes.where(
        commandes > 0)).round(3)
    df["a_repondu"] = df["satisfaction"].notna()
    df["log_depense"] = np.log1p(df["depense_12m"]).round(4)
    df["date_inscription"] = df["date_inscription"].dt.strftime(
        "%Y-%m-%d")

    for col in ["age", "nb_commandes_12m", "nb_retours_12m",
                "recence_jours", "nb_contacts_sav", "satisfaction"]:
        df[col] = df[col].astype("Int64")
    if "parti_6m" in df:
        df["parti_6m"] = df["parti_6m"].astype("Int64")
    colonnes = [c for c in COLONNES_PROPRES if c in df.columns]
    return df[colonnes].sort_values("client_id").reset_index(drop=True)


def charger_propres(chemin=None):
    """Lit clients_propres.csv avec la convention du projet."""
    from smartmarket.chemins import CSV, FICHIER_PROPRE
    return pd.read_csv(chemin or FICHIER_PROPRE, sep=CSV["sep"],
                       decimal=CSV["decimal"], encoding=CSV["encoding"])
