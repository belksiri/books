"""Modèles du projet SmartMarket : dépense, départ, profils.

Ces fonctions regroupent le code répété dans les notebooks des
chapitres 18 à 24. Un notebook ou un script les importe au lieu de
les recopier.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.preprocessing import (FunctionTransformer,
                                   OneHotEncoder,
                                   StandardScaler)

from smartmarket.config import CONFIG

EN_LOG = ["nb_commandes_12m", "depense_12m"]
NUM_DEPENSE = ["recence_jours", "anciennete_mois",
               "ouverture_emails", "part_promo",
               "panier_moyen"]
NUM_DEPART = NUM_DEPENSE + ["satisfaction",
                            "nb_contacts_sav",
                            "taux_retour",
                            "delai_livraison"]
CAT_DEPENSE = ["region", "canal", "abonnement"]
CAT_DEPART = CAT_DEPENSE + ["a_repondu"]
COMPORTEMENT = ["nb_commandes_12m", "depense_12m",
                "recence_jours", "part_promo",
                "ouverture_emails", "anciennete_mois"]
INTERDITES = ["client_id", "statut_compte",
              "depense_suivante", "parti_6m"]


def preparation(numeriques, categories):
    """Logarithme, imputation, standardisation, encodage."""
    logarithme = FunctionTransformer(
        np.log1p, feature_names_out="one-to-one")
    return ColumnTransformer([
        ("log", make_pipeline(logarithme,
                              StandardScaler()), EN_LOG),
        ("num", make_pipeline(
            SimpleImputer(strategy="median",
                          add_indicator=True),
            StandardScaler()), numeriques),
        ("cat", make_pipeline(
            SimpleImputer(strategy="constant",
                          fill_value="inconnue"),
            OneHotEncoder(handle_unknown="ignore")),
         categories),
    ])


def modele_depense(config=CONFIG):
    """KNN retenu au chapitre 19."""
    return Pipeline([
        ("preparation", preparation(NUM_DEPENSE,
                                    CAT_DEPENSE)),
        ("modele", KNeighborsRegressor(
            n_neighbors=config.k_voisins,
            weights=config.poids_voisins)),
    ])


def modele_depart():
    """Régression logistique des chapitres 20 à 22."""
    return Pipeline([
        ("preparation", preparation(NUM_DEPART,
                                    CAT_DEPART)),
        ("modele", LogisticRegression(max_iter=1000)),
    ])


def cout_seuil(proba, y, seuil, config=CONFIG):
    """Coût des contacts et des départs non évités."""
    contact = proba >= seuil
    evites = config.efficacite * (contact & (y == 1)).sum()
    departs = (y == 1).sum() - evites
    return (config.cout_contact * contact.sum()
            + config.perte_depart * departs)


def seuil_optimal(proba, y, config=CONFIG):
    """Seuil de coût minimal parmi 0,05 ; 0,10 ; … ; 0,95."""
    seuils = np.round(np.arange(0.05, 0.96, 0.05), 2)
    couts = [cout_seuil(proba, y, s, config) for s in seuils]
    return float(seuils[int(np.argmin(couts))])


def preparer_profils(donnees, recence_max):
    """Variables de comportement du chapitre 23."""
    X = donnees[COMPORTEMENT].astype(float).copy()
    X["recence_jours"] = X["recence_jours"].fillna(
        recence_max)
    X["part_promo"] = X["part_promo"].fillna(0)
    X["ouverture_emails"] = X["ouverture_emails"].fillna(0)
    for col in ["nb_commandes_12m", "depense_12m",
                "recence_jours", "anciennete_mois"]:
        X[col] = np.log1p(X[col])
    return X


def nommer_profils(donnees, groupes):
    """Nom de chaque groupe, selon la règle du chapitre 23."""
    profils = donnees.assign(g=groupes).groupby("g").agg(
        commandes=("nb_commandes_12m", "median"),
        depense=("depense_12m", "median"),
        promo=("part_promo", "mean"))
    conditions = [profils["commandes"] == 0,
                  profils["promo"] > 0.5,
                  profils["depense"] > 400]
    choix = ["Endormis", "Chasseurs de promotions",
             "Piliers"]
    noms = np.select(conditions, choix,
                     default="Occasionnels")
    return dict(zip(profils.index, noms))


def segmentation(clients, config=CONFIG):
    """Échelle, K-means et noms des profils."""
    recence_max = clients["recence_jours"].max()
    echelle = StandardScaler()
    Z = echelle.fit_transform(
        preparer_profils(clients, recence_max))
    kmeans = KMeans(n_clusters=config.n_profils, n_init=10,
                    random_state=config.graine)
    groupes = kmeans.fit_predict(Z)
    noms = nommer_profils(clients, groupes)
    return {"echelle": echelle, "kmeans": kmeans,
            "recence_max": recence_max, "noms": noms,
            "profils": pd.Series(groupes).map(noms).to_numpy()}


def affecter_profils(donnees, segmentation_apprise):
    """Profil de nouveaux clients, sans rien réapprendre."""
    s = segmentation_apprise
    Z = s["echelle"].transform(
        preparer_profils(donnees, s["recence_max"]))
    groupes = s["kmeans"].predict(Z)
    return pd.Series(groupes).map(s["noms"]).to_numpy()
