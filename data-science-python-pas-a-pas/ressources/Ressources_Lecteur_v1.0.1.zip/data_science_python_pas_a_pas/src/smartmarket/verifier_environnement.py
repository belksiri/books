"""Vérifier que l'environnement SmartMarket est prêt.

Commande (environnement virtuel activé, depuis n'importe quel dossier) :
    python -m smartmarket.verifier_environnement

Chaque vérification affiche OK ou ÉCHEC, avec une correction proposée.
Le script se termine avec le code 0 si tout est prêt, 1 sinon.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import sys
import tempfile
from pathlib import Path

VERSION_MIN = (3, 12)
VERSION_MAX = (3, 14)
PAQUETS = {
    "numpy": "2.5.3", "pandas": "3.0.5", "sklearn": "1.9.1",
    "matplotlib": "3.11.2", "seaborn": "0.13.2", "joblib": "1.6.0",
}

resultats = []


def verifier(nom, correction):
    """Décorateur : exécute un test et mémorise son résultat."""
    def enveloppe(fonction):
        def executer():
            try:
                detail = fonction()
                resultats.append((True, nom, detail or ""))
                print(f"  OK     {nom}" + (f" ({detail})" if detail else ""))
            except Exception as exc:  # message lisible, pas de trace
                resultats.append((False, nom, str(exc)))
                print(f"  ÉCHEC  {nom}\n         Cause : {exc}"
                      f"\n         Correction : {correction}")
        return executer
    return enveloppe


@verifier("Version de Python",
          "installe Python 3.12, 3.13 ou 3.14 depuis python.org, puis "
          "recrée l'environnement virtuel (chapitre 2).")
def v_python():
    v = sys.version_info
    if not (VERSION_MIN <= (v.major, v.minor) <= VERSION_MAX):
        raise RuntimeError(f"Python {v.major}.{v.minor} détecté")
    return f"{v.major}.{v.minor}.{v.micro} — {sys.executable}"


@verifier("Environnement virtuel actif",
          "active-le : « source .venv/bin/activate » (macOS) ou "
          "« .venv\\Scripts\\Activate.ps1 » (Windows PowerShell).")
def v_venv():
    if sys.prefix == sys.base_prefix:
        raise RuntimeError("Python du système utilisé, pas .venv")
    return Path(sys.prefix).name


@verifier("Bibliothèques installées",
          "lance « python -m pip install -r requirements.txt ».")
def v_paquets():
    ecarts = []
    for nom, attendu in PAQUETS.items():
        module = importlib.import_module(nom)
        if module.__version__ != attendu:
            ecarts.append(f"{nom} {module.__version__} ≠ {attendu}")
    if ecarts:
        raise RuntimeError("versions différentes : " + ", ".join(ecarts))
    return "versions conformes"


@verifier("Noyau Jupyter (ipykernel)",
          "lance « python -m pip install ipykernel », puis choisis "
          ".venv comme noyau dans VS Code.")
def v_ipykernel():
    module = importlib.import_module("ipykernel")
    return module.__version__


@verifier("Dossier du projet",
          "installe le projet : « python -m pip install -e . » depuis "
          "le dossier data_science_python_pas_a_pas.")
def v_projet():
    from smartmarket.chemins import RACINE
    return str(RACINE)


@verifier("Fichiers CSV présents",
          "télécharge à nouveau l'archive du livre, ou régénère les "
          "données : « python -m smartmarket.generer_donnees ».")
def v_csv():
    from smartmarket.chemins import (FICHIER_BRUT, FICHIER_PROPRE,
                                     FICHIER_SCORING)
    manquants = [p.name for p in (FICHIER_BRUT, FICHIER_PROPRE,
                                  FICHIER_SCORING) if not p.exists()]
    if manquants:
        raise FileNotFoundError(", ".join(manquants))
    return "3 fichiers"


@verifier("Empreinte du fichier brut",
          "ne modifie jamais data/raw ; si tu l'as ouvert et "
          "réenregistré avec Excel, régénère-le.")
def v_empreinte():
    from smartmarket.chemins import FICHIER_BRUT, FICHIER_MANIFESTE
    man = json.loads(FICHIER_MANIFESTE.read_text(encoding="utf-8"))
    attendu = man["fichiers"]["data/raw/smartmarket_clients.csv"]["sha256"]
    reel = hashlib.sha256(FICHIER_BRUT.read_bytes()).hexdigest()
    if reel != attendu:
        raise RuntimeError("le fichier brut a été modifié")
    return reel[:12] + "…"


@verifier("Lecture d'un CSV",
          "vérifie sep=';' et decimal=',' dans pd.read_csv.")
def v_lecture():
    import pandas as pd

    from smartmarket.chemins import CSV, FICHIER_PROPRE
    df = pd.read_csv(FICHIER_PROPRE, **CSV)
    if df.shape != (6000, 24):
        raise RuntimeError(f"dimensions inattendues {df.shape}")
    return f"{df.shape[0]} lignes × {df.shape[1]} colonnes"


@verifier("Écriture dans outputs/",
          "vérifie que le dossier n'est pas en lecture seule "
          "(OneDrive, dossier protégé).")
def v_ecriture():
    from smartmarket.chemins import SORTIES
    SORTIES.mkdir(exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=SORTIES, delete=True) as f:
        f.write(b"test")
    return str(SORTIES.name)


@verifier("Graphique (backend non interactif)",
          "réinstalle matplotlib : « python -m pip install "
          "--force-reinstall matplotlib==3.11.2 ».")
def v_graphique():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from smartmarket.chemins import FIGURES
    FIGURES.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(3, 2))
    ax.plot([0, 1, 2], [1, 3, 2])
    chemin = FIGURES / "verification_environnement.png"
    fig.savefig(chemin, dpi=72)
    plt.close(fig)
    return chemin.name


@verifier("Entraînement d'un modèle simple",
          "réinstalle scikit-learn : « python -m pip install "
          "scikit-learn==1.9.1 ».")
def v_modele():
    import numpy as np
    from sklearn.linear_model import LogisticRegression
    X = np.array([[0.0], [1.0], [2.0], [3.0]])
    y = np.array([0, 0, 1, 1])
    modele = LogisticRegression().fit(X, y)
    if list(modele.predict(X)) != [0, 0, 1, 1]:
        raise RuntimeError("prédictions inattendues")
    return "régression logistique"


def main():
    print("Vérification de l'environnement SmartMarket\n")
    for test in (v_python, v_venv, v_paquets, v_ipykernel, v_projet,
                 v_csv, v_empreinte, v_lecture, v_ecriture, v_graphique,
                 v_modele):
        test()
    echecs = [r for r in resultats if not r[0]]
    print()
    if echecs:
        print(f"{len(echecs)} vérification(s) en échec : corrige la "
              "première, puis relance ce script.")
        return 1
    print("Environnement SmartMarket prêt.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
