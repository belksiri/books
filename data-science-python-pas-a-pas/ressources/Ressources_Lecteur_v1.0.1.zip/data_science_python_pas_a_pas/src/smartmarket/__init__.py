"""Outils du projet SmartMarket.

Livre : « Data science avec Python, pas à pas », de Belk Siri.
Toutes les données SmartMarket sont fictives.
"""

__version__ = "1.0.1"
