"""Fixtures partagées : fichiers lus une seule fois par session."""

import json

import pandas as pd
import pytest

from smartmarket.chemins import (CSV, FICHIER_BRUT, FICHIER_MANIFESTE,
                                 FICHIER_PROPRE, FICHIER_SCORING)


def lire(chemin):
    return pd.read_csv(chemin, **CSV)


@pytest.fixture(scope="session")
def brut():
    return lire(FICHIER_BRUT)


@pytest.fixture(scope="session")
def propre():
    return lire(FICHIER_PROPRE)


@pytest.fixture(scope="session")
def scoring():
    return lire(FICHIER_SCORING)


@pytest.fixture(scope="session")
def manifeste():
    return json.loads(FICHIER_MANIFESTE.read_text(encoding="utf-8"))
