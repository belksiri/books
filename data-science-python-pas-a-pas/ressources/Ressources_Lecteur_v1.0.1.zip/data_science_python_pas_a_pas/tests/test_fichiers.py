"""Structure, dimensions, types et bornes des fichiers."""

import hashlib

import pandas as pd

from smartmarket.chemins import RACINE
from smartmarket.preparation import COLONNES_PROPRES


def test_dimensions(brut, propre, scoring):
    assert brut.shape == (6120, 19)
    assert propre.shape == (6000, 24)
    assert scoring.shape[0] == 800
    # Colonnes de l'export : celles d'origine « brut » du dictionnaire
    dico = pd.read_csv(RACINE / "data" / "reference"
                       / "dictionnaire_donnees.csv", sep=";")
    brutes = dico.loc[dico["origine"] == "brut", "colonne"].tolist()
    assert list(brut.columns) == brutes
    assert list(propre.columns) == COLONNES_PROPRES
    assert propre["client_id"].is_unique


def test_doublons_attendus(brut):
    assert brut.duplicated().sum() == 90
    ids_repetes = brut["client_id"].duplicated().sum()
    assert ids_repetes == 120  # 90 exacts + 30 quasi-doublons
    sans_exacts = brut.drop_duplicates()
    assert sans_exacts["client_id"].duplicated().sum() == 30


def test_scoring_sans_cibles(scoring):
    for col in ["depense_suivante", "parti_6m", "statut_compte"]:
        assert col not in scoring.columns
    assert scoring["client_id"].str[1:].astype(int).min() > 6000


def test_types_propres(propre):
    assert pd.to_datetime(propre["date_inscription"],
                          format="%Y-%m-%d").notna().all()
    for col in ["age", "depense_12m", "recence_jours", "part_promo",
                "satisfaction", "ouverture_emails", "depense_suivante"]:
        assert pd.api.types.is_numeric_dtype(propre[col]), col
    assert set(propre["abonnement"].unique()) <= {True, False}
    assert set(propre["parti_6m"].unique()) == {0, 1}


def test_bornes_plausibles(propre):
    p = propre
    assert p["age"].dropna().between(18, 100).all()
    assert p["satisfaction"].dropna().between(1, 5).all()
    assert p["part_promo"].dropna().between(0, 1).all()
    assert p["ouverture_emails"].dropna().between(0, 1).all()
    assert (p["depense_12m"] >= 0).all()
    assert (p["depense_suivante"] >= 0).all()
    assert p["delai_livraison"].dropna().le(30).all()
    ok = p["nb_retours_12m"].isna() | (
        p["nb_retours_12m"] <= p["nb_commandes_12m"])
    assert ok.all()


def test_defauts_presents_dans_le_brut(brut):
    # 18 aberrations, parfois recopiées dans un doublon
    assert brut.drop_duplicates()["age"].isin([0, 120, 999]).sum() >= 18
    assert brut["depense_12m"].str.contains("€").all()
    iso = brut["date_inscription"].str.match(r"\d{4}-\d{2}-\d{2}")
    assert 0.005 < iso.mean() < 0.03
    assert brut["region"].nunique() > 7
    assert brut["abonnement"].nunique() > 2
    assert brut["satisfaction"].isna().mean() > 0.2
    assert (brut["nb_retours_12m"] > brut["nb_commandes_12m"]).sum() > 0


def test_empreintes_conformes_au_manifeste(manifeste):
    for nom, info in manifeste["fichiers"].items():
        reel = hashlib.sha256((RACINE / nom).read_bytes()).hexdigest()
        assert reel == info["sha256"], nom
