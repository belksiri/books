"""Chemins robustes et diagnostic de l'environnement."""

import os
import subprocess
import sys

from smartmarket import chemins


def test_racine_trouvee_depuis_notebooks():
    racine = chemins.trouver_racine(chemins.RACINE / "notebooks")
    assert racine == chemins.RACINE
    assert (racine / "pyproject.toml").exists()


def test_diagnostic_reussi_depuis_un_autre_dossier(tmp_path):
    res = subprocess.run(
        [sys.executable, "-m", "smartmarket.verifier_environnement"],
        cwd=tmp_path, capture_output=True, text=True,
        env={**os.environ, "MPLBACKEND": "Agg"})
    assert res.returncode == 0, res.stdout
    assert "Environnement SmartMarket prêt." in res.stdout
