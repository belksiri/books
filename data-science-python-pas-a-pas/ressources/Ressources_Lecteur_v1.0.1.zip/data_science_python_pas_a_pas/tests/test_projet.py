"""Le projet final se relance de bout en bout et redonne les mêmes résultats."""

import json

import pytest

from smartmarket import modeles
from smartmarket.chemins import FIGURES, METRIQUES, MODELES, RAPPORTS
from smartmarket.pipeline import executer


@pytest.fixture(scope="module")
def bilan():
    return executer()


def test_fichiers_produits(bilan):
    for chemin in [MODELES / "modele_depense.joblib",
                   MODELES / "modele_depart.joblib",
                   MODELES / "segmentation.joblib",
                   METRIQUES / "projet.json",
                   RAPPORTS / "scores_clients.csv",
                   RAPPORTS / "synthese.md",
                   FIGURES / "concentration_valeur.png",
                   FIGURES / "depart_profils.png"]:
        assert chemin.exists(), chemin


def test_resultats_des_chapitres(bilan):
    """Mêmes nombres qu'aux chapitres 19, 22 et 24."""
    d, p, s = bilan["depense"], bilan["depart"], bilan["scoring"]
    assert round(d["mae_cv"]["KNN"]["moyenne"], 1) == 153.9
    assert round(d["mae_test_knn"], 1) == 154.2
    assert round(p["auc_cv"], 3) == 0.827
    assert p["seuil"] == 0.4
    assert s["n_prioritaires"] == 154
    assert set(bilan["profils"]) == {"Piliers", "Occasionnels",
                                     "Endormis",
                                     "Chasseurs de promotions"}


def test_references_battues(bilan):
    d = bilan["depense"]
    assert d["mae_test_knn"] < d["mae_test_mediane"] / 1.5
    assert bilan["depart"]["auc_test"] > 0.75


def test_json_lisible(bilan):
    relu = json.loads((METRIQUES / "projet.json").read_text(
        encoding="utf-8"))
    assert relu["scoring"]["n_clients"] == 800


def test_aucune_colonne_interdite_dans_les_modeles():
    variables = (modeles.EN_LOG + modeles.NUM_DEPART
                 + modeles.CAT_DEPART + modeles.COMPORTEMENT)
    assert not set(variables) & set(modeles.INTERDITES)
