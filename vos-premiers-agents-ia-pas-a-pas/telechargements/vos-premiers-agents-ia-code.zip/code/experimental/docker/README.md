# Docker: experimental resource / ressource expérimentale

**Not part of the book's main path. Never built, never started.**
**Hors du parcours principal du livre. Jamais construite, jamais lancée.**

Nothing here has been tested on any hosting provider. Only the install and start
steps were replayed without a container, on macOS.

## Français

Point de départ à vérifier vous-même, pas une recette. Docker doit être installé.
`production.env` est à créer vous-même (même forme que `.env`) ; `.gitignore`
l'exclut du dépôt. Depuis le dossier `code/` :

```bash
docker build -f experimental/docker/Dockerfile -t assistant-rivelune .
printf 'ASSISTANT_UI_PASSWORD=essai-local\n' > production.env
docker run --rm -p 127.0.0.1:8501:8501 --env-file production.env \
    -v assistant-outbox:/app/outbox -v assistant-logs:/app/logs \
    -v assistant-ledger:/app/live_results/real assistant-rivelune
```

Les trois volumes ne sont pas facultatifs : sans eux, le registre des dépenses et
le journal disparaissent à chaque redémarrage. Un seul conteneur à la fois.
Ce mode d'emploi ne fait aucun appel au modèle. Supprimez `production.env` ensuite.

À constater : (1) la construction réussit ; (2) `http://127.0.0.1:8501` ouvre la
page, et le parcours simulé va jusqu'au fichier ; (3) le compte `assistant` peut
écrire dans les trois volumes, point le plus incertain ; (4) après un nouveau
`docker run`, `outbox/` et les journaux sont toujours là ;
(5) `docker run --rm --entrypoint id assistant-rivelune` ne répond pas `root`.

## English

A starting point to check yourself, not a recipe. Docker must be installed. Create
`production.env` yourself (same form as `.env`); `.gitignore` excludes it. Run the
commands above from the `code/` folder.

The three volumes aren't optional: without them, the spending ledger and the log
disappear at each restart. Only one container at a time. These steps make no model
call. Delete `production.env` afterwards.

To observe: (1) the build succeeds; (2) `http://127.0.0.1:8501` opens the page and
the simulated path reaches the file; (3) the `assistant` account can write to the
three volumes, the most uncertain point; (4) after another `docker run`, `outbox/`
and the logs are still there; (5) `docker run --rm --entrypoint id assistant-rivelune`
doesn't answer `root`.

## Español

Un punto de partida que debes comprobar tú, no una receta. Docker debe estar
instalado. Crea tú `production.env` (misma forma que `.env`); `.gitignore` lo excluye.
Ejecuta los comandos anteriores desde la carpeta `code/`.

Los tres volúmenes no son opcionales: sin ellos, el registro de gastos y el de
acciones desaparecen en cada reinicio. Un solo contenedor a la vez. Estos pasos no
hacen ninguna llamada al modelo. Después, borra `production.env`.

A comprobar: (1) la construcción funciona; (2) `http://127.0.0.1:8501` abre la página
y el recorrido simulado llega hasta el archivo; (3) la cuenta `assistant` puede
escribir en los tres volúmenes, el punto más incierto; (4) tras otro `docker run`,
`outbox/` y los registros siguen ahí; (5) `docker run --rm --entrypoint id
assistant-rivelune` no responde `root`.

## Deutsch

Ein Ausgangspunkt, den Sie selbst prüfen müssen, kein Rezept. Docker muss installiert
sein. Erstellen Sie `production.env` selbst (gleiche Form wie `.env`); `.gitignore`
schließt sie aus. Führen Sie die Befehle oben im Ordner `code/` aus.

Die drei Volumes sind nicht optional: Ohne sie verschwinden das Ausgabenregister und
das Protokoll bei jedem Neustart. Nur ein Container zur gleichen Zeit. Diese Schritte
rufen das Modell nicht auf. Löschen Sie `production.env` danach.

Zu prüfen: (1) Der Build gelingt; (2) `http://127.0.0.1:8501` öffnet die Seite, und
der simulierte Ablauf erreicht die Datei; (3) das Konto `assistant` kann in die drei
Volumes schreiben, der unsicherste Punkt; (4) nach einem weiteren `docker run` sind
`outbox/` und die Protokolle noch da; (5) `docker run --rm --entrypoint id
assistant-rivelune` antwortet nicht `root`.
