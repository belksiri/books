"""Offline checks of the Anthropic adapter: real SDK types,
fake transport. This does NOT prove the API accepts the
request; only a live run can (see assistant-live)."""

import anthropic
from anthropic.types import Message

from assistant.llm_anthropic import AnthropicModel

RAW = {
    "id": "msg_test",
    "type": "message",
    "role": "assistant",
    "model": "claude-haiku-5-5",
    "stop_reason": "tool_use",
    "stop_sequence": None,
    "usage": {"input_tokens": 120, "output_tokens": 30},
    "content": [
        {"type": "text", "text": "Je cherche."},
        {
            "type": "tool_use",
            "id": "toolu_1",
            "name": "search_documents",
            "input": {"query": "caution"},
        },
    ],
}


class FakeMessages:
    def __init__(self):
        self.params = None

    def create(self, **params):
        self.params = params
        return Message.model_validate(RAW)


class FakeClient:
    def __init__(self):
        self.messages = FakeMessages()


def test_request_shape_and_reply_conversion():
    client = FakeClient()
    model = AnthropicModel("claude-haiku-5-5", client=client)
    tools = [{"name": "t", "input_schema": {}}]
    reply = model.complete(
        "sys", [{"role": "user", "content": "q"}], tools
    )
    sent = client.messages.params
    assert sent["model"] == "claude-haiku-5-5"
    assert sent["system"] == "sys" and sent["tools"] == tools
    assert "temperature" not in sent
    assert "output_config" not in sent
    assert reply.stop_reason == "tool_use"
    assert reply.text == "Je cherche."
    assert reply.tool_calls[0].input == {"query": "caution"}
    assert reply.usage.input_tokens == 120
    assert reply.content[1].type == "tool_use"  # SDK block kept


def test_effort_goes_into_output_config():
    client = FakeClient()
    model = AnthropicModel("m", effort="low", client=client)
    model.complete("s", [])
    assert client.messages.params["output_config"] == {
        "effort": "low"
    }


def test_sdk_version_is_the_pinned_one():
    assert anthropic.__version__ == "2.3.0"


def test_timeout_and_retries_reach_the_client(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    model = AnthropicModel("m", max_retries=0, timeout=30.0)
    assert model._client.max_retries == 0
    assert model._client.timeout == 30.0
