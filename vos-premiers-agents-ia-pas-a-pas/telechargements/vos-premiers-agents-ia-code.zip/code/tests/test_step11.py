"""Step 11. FakeModel only. Streamlit is optional: the tests of
the page itself are skipped when it is not installed, and they
run the page's script without a browser or a server:

    uv run --extra interface pytest tests/test_step11.py
"""

import json
import subprocess
import sys
from pathlib import Path

import pytest

from assistant import config, paid
from assistant.config import CODE_DIR, Settings
from assistant.llm import FakeModel, ModelError
from assistant.messages import MESSAGES, t
from assistant.policy import AccessDenied
from assistant.scenarios import BUREAU, deposit_scenario
from assistant.step07.gate import (
    ActionJournal,
    GateRefused,
    UnknownOutcome,
)
from assistant.step10.permissions import excess_tools
from assistant.step11 import service
from assistant.step11.demo import interface_demo
from assistant.step11.service import (
    REAL,
    SIMULATED,
    LiveRefused,
    SendSetup,
    approve_send,
    ask,
    check_password,
    prepare_send,
    run_mode,
)

FR = CODE_DIR / "demo_data" / "fr"
DAY = "2026-06-15"
SERVICE = Path(service.__file__)
APP = SERVICE.with_name("app.py")


def settings(allow_live=False, lang="fr", model=None):
    return Settings(model, lang, allow_live)


# ---- Answer and references ----
def test_answer_comes_with_checked_references():
    done = ask(deposit_scenario("fr"), "Q", FR, "fr", DAY, True)
    assert done.status == "done"
    assert "150 €" in done.answer
    assert [c.ref for c in done.checks] == [
        "cr-ag-2026-03#p03",
        "tarifs-2026#p04",
    ]
    assert done.problems == 0
    assert "150 €" in done.passages["cr-ag-2026-03#p03"]
    # The fourth check needs a person: never filled in here.
    assert all(c.supported is None for c in done.checks)


def test_invented_reference_is_shown_as_a_problem():
    forged = "Faux [tarifs-2026#p04] et [inconnu#p01]."
    model = FakeModel([FakeModel.says(forged)])
    done = ask(model, "Q", FR, "fr", DAY, False)
    assert done.problems == 2
    assert "inconnu#p01" not in done.passages


def test_tools_of_the_interface_only_read():
    model = deposit_scenario("fr")
    ask(model, "Q", FR, "fr", DAY, True)
    tools = [d["name"] for d in model.requests[0]["tools"]]
    assert tools and excess_tools(tools, "mission_step") == []


def test_model_failure_stops_cleanly():
    down = FakeModel([ModelError("timeout (simulated)", True)])
    done = ask(down, "Q", FR, "fr", DAY, False)
    assert (done.status, done.answer) == ("model_error", "")
    assert "timeout" in done.detail


# ---- The folder comes from a web page ----
def test_folder_stays_under_the_root(tmp_path):
    root = tmp_path / "docs"
    (root / "a").mkdir(parents=True)
    (root / "a" / "x.md").write_text("x")
    (root / "empty").mkdir()
    outside = tmp_path / "secret"
    outside.mkdir()
    (outside / "y.md").write_text("y")
    (root / "link").symlink_to(outside)
    assert service.open_folder(root, "a").name == "a"
    for name in ("../secret", str(outside), "link"):
        with pytest.raises(AccessDenied):
            service.open_folder(root, name)
    assert "empty" not in service.list_folders(root)
    with pytest.raises(AccessDenied):
        service.open_folder(root, "a/x.md")


# ---- Modes ----
@pytest.mark.parametrize("lang", ["fr", "en", "es", "de"])
def test_simulated_is_default_and_labelled(lang):
    assert service.available_modes(settings())[0] == SIMULATED
    done = run_mode(
        settings(lang=lang),
        SIMULATED,
        "autre chose",
        CODE_DIR / "demo_data" / lang,
        DAY,
    )
    assert done.simulated
    label = service.simulated_label(lang)
    assert label.upper().startswith("SIMUL")
    tag = t(lang, "ui_simulated_tag")
    assert service.first_draft(done, lang).startswith(
        f"[{tag}]"
    )


def test_page_shows_the_label_before_a_simulated_answer():
    text = APP.read_text("utf-8")
    assert "if done.simulated:" in text
    assert "simulated_label(lang)" in text


def test_simulated_mode_never_opens_the_paid_door(monkeypatch):
    def forbidden(*args):
        raise AssertionError("paid door opened")

    monkeypatch.setattr(paid, "open_model", forbidden)
    live = settings(allow_live=True)
    run_mode(live, SIMULATED, "Q", FR, DAY)


def test_real_mode_refused_when_off(monkeypatch):
    def forbidden(*args):
        raise AssertionError("no client may be built")

    monkeypatch.setattr(paid, "make_anthropic", forbidden)
    monkeypatch.setattr(paid, "open_model", forbidden)
    assert REAL not in service.available_modes(settings())
    with pytest.raises(LiveRefused):
        run_mode(settings(model="m"), REAL, "Q", FR, DAY)


def test_real_mode_refused_without_a_key(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("no client may be built")

    monkeypatch.setattr(paid, "make_anthropic", forbidden)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    live = settings(True, model="claude-haiku-5-5")
    assert REAL in service.available_modes(live)
    with pytest.raises(LiveRefused):
        run_mode(live, REAL, "Q", FR, DAY)


def test_real_mode_goes_through_the_paid_door(monkeypatch):
    seen = {}

    def door(the_settings, mission, max_calls):
        seen.update(mission=mission, max_calls=max_calls)
        return deposit_scenario("fr")

    monkeypatch.setattr(paid, "open_model", door)
    done = run_mode(settings(True), REAL, "Q", FR, DAY)
    assert seen["mission"].startswith("ui:")
    assert not done.simulated
    answer = service.first_draft(done, "fr")
    assert answer == done.answer  # no simulated mark


def test_unknown_mode_is_refused():
    with pytest.raises(ValueError):
        run_mode(settings(), "other", "Q", FR, DAY)


def test_the_page_builds_no_client_and_step11_one_door():
    for path in (APP, SERVICE):
        text = path.read_text("utf-8")
        assert "AnthropicModel" not in text
        assert "make_anthropic" not in text
        assert "import anthropic" not in text
    assert "open_model" not in APP.read_text("utf-8")


def test_service_does_not_need_streamlit():
    code = (
        "import sys, assistant.step11.service, "
        "assistant.step11.demo;"
        "sys.exit('streamlit' in sys.modules)"
    )
    done = subprocess.run([sys.executable, "-c", code])
    assert done.returncode == 0


# ---- Password ----
def test_password():
    assert check_password("sésame", "sésame")
    assert not check_password("wrong", "sésame")
    assert not check_password("", "sésame")


@pytest.mark.parametrize("expected", [None, ""])
def test_no_password_set_keeps_the_door_closed(expected):
    assert not check_password("", expected)
    assert not check_password("anything", expected)


def test_expected_password_comes_from_the_environment(
    monkeypatch,
):
    monkeypatch.delenv("ASSISTANT_UI_PASSWORD", raising=False)
    assert service.expected_password() is None
    monkeypatch.setenv("ASSISTANT_UI_PASSWORD", "x")
    assert service.expected_password() == "x"


# ---- Sending ----
@pytest.fixture
def setup(tmp_path) -> SendSetup:
    return SendSetup(
        {BUREAU},
        tmp_path / "outbox",
        tmp_path / "actions.jsonl",
    )


def files(setup: SendSetup) -> list[Path]:
    if not setup.outbox.exists():
        return []
    return list(setup.outbox.iterdir())


def test_preview_shows_the_whole_action(setup):
    shown = prepare_send(BUREAU, "Texte entier.", setup.allowed)
    assert shown.refusal is None
    assert BUREAU in shown.text
    assert "Texte entier." in shown.text
    assert files(setup) == []  # a preview writes nothing


def test_exact_text_is_written_after_approval(setup):
    text = "Le dépôt est de 150 €."
    shown = prepare_send(BUREAU, text, setup.allowed)
    path = approve_send(shown, BUREAU, text, "Camille", setup)
    assert path.parent == setup.outbox
    assert text in path.read_text("utf-8")
    events = ActionJournal(setup.journal).events()
    assert [e["event"] for e in events] == [
        "approved",
        "intent",
        "sent",
    ]
    assert text not in setup.journal.read_text("utf-8")


@pytest.mark.parametrize(
    "target, text",
    [
        (BUREAU, "Le dépôt est de 100 €."),
        (BUREAU, "Le dépôt est de 150 €. "),
        ("autre@example.org", "Le dépôt est de 150 €."),
    ],
)
def test_changed_action_needs_a_new_preview(
    setup, target, text
):
    shown = prepare_send(
        BUREAU, "Le dépôt est de 150 €.", setup.allowed
    )
    with pytest.raises(GateRefused):
        approve_send(shown, target, text, "Camille", setup)
    assert files(setup) == []


def test_second_click_sends_nothing_more(setup):
    shown = prepare_send(BUREAU, "Une fois.", setup.allowed)
    approve_send(shown, BUREAU, "Une fois.", "Camille", setup)
    with pytest.raises(GateRefused):
        approve_send(
            shown, BUREAU, "Une fois.", "Camille", setup
        )
    assert len(files(setup)) == 1


def test_gate_keeps_its_own_checks(setup):
    """A preview built outside the rules changes nothing."""
    outsider = "autre@example.org"
    shown = prepare_send(outsider, "Texte", {outsider})
    with pytest.raises(GateRefused, match="not allowed"):
        approve_send(shown, outsider, "Texte", "Camille", setup)
    hidden = "Texte​ caché"
    shown = prepare_send(BUREAU, hidden, {BUREAU})
    assert "hidden" in shown.refusal
    with pytest.raises(GateRefused, match="hidden"):
        approve_send(shown, BUREAU, hidden, "Camille", setup)
    assert files(setup) == []


@pytest.mark.parametrize(
    "who", ["", "   ", "x --> y", "a" * 61]
)
def test_a_name_is_required(setup, who):
    shown = prepare_send(BUREAU, "Texte", setup.allowed)
    with pytest.raises(GateRefused, match="name"):
        approve_send(shown, BUREAU, "Texte", who, setup)
    assert not setup.journal.exists()


def test_personal_data_warns_and_person_can_still_approve(
    setup,
):
    text = "Écrire à yanis.roux@example.org."
    shown = prepare_send(BUREAU, text, setup.allowed)
    assert shown.personal_data
    # The gate adds its warning before the same preview.
    assert approve_send(shown, BUREAU, text, "Camille", setup)


def test_too_large_is_refused_before_any_intent(setup):
    big = "x" * (service.MAX_SEND_BYTES + 1)
    shown = prepare_send(BUREAU, big, setup.allowed)
    assert shown.refusal == "content too large"
    with pytest.raises(GateRefused, match="too large"):
        approve_send(shown, BUREAU, big, "Camille", setup)
    assert ActionJournal(setup.journal).unknown() == []


def test_largest_text_allowed_fits_the_outbox(setup):
    text = "x" * service.MAX_SEND_BYTES
    shown = prepare_send(BUREAU, text, setup.allowed)
    assert shown.refusal is None
    assert approve_send(shown, BUREAU, text, "Camille", setup)
    assert ActionJournal(setup.journal).unknown() == []


def test_unknown_outcome_blocks_the_page_too(setup):
    ActionJournal(setup.journal).add("intent", "abc")
    shown = prepare_send(BUREAU, "Texte", setup.allowed)
    with pytest.raises(UnknownOutcome):
        approve_send(shown, BUREAU, "Texte", "Camille", setup)
    assert files(setup) == []


def test_only_the_gate_writes_a_sending():
    # No other way out: the service holds no writer of its own.
    assert "write_text" not in SERVICE.read_text("utf-8")
    assert ".write_new" not in SERVICE.read_text("utf-8")


def test_simulated_texts_stay_apart(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "CODE_DIR", tmp_path)
    monkeypatch.delenv(
        "ASSISTANT_ALLOWED_TARGETS", raising=False
    )
    plain = settings()
    fake = service.send_setup(plain, True)
    real = service.send_setup(plain, False)
    assert fake.allowed == {BUREAU}
    assert real.allowed == set()
    assert fake.outbox == real.outbox / "simulated"
    assert fake.journal != real.journal


# ---- Supervision ----
def test_run_log_holds_numbers_not_content(tmp_path):
    log = tmp_path / "interface.jsonl"
    question = "Question très privée ?"
    run_mode(settings(), SIMULATED, question, FR, DAY, log)
    text = log.read_text("utf-8")
    record = json.loads(text)
    assert record["mode"] == "simulated"
    assert record["status"] == "done"
    assert record["references"] == 2
    assert "privée" not in text
    assert "150" not in text


# ---- Messages and demo ----
def test_interface_messages_exist_in_all_languages():
    keys = {k for k in MESSAGES["fr"] if k.startswith("ui_")}
    assert keys
    for lang in MESSAGES:
        assert keys <= set(MESSAGES[lang])


@pytest.mark.parametrize("lang", ["fr", "en", "es", "de"])
def test_demo_is_labelled_and_fits_the_page(lang, capsys):
    assert interface_demo(settings(lang=lang)) == 0
    out = capsys.readouterr().out
    assert out.startswith("(" + t(lang, "ui_simulated")[:20])
    assert "outbox/" in out
    assert max(len(line) for line in out.splitlines()) <= 64


# ---- The page, run without browser or server ----
@pytest.fixture
def page(tmp_path, monkeypatch):
    """Its script, run in this process; files in tmp_path."""
    testing = pytest.importorskip("streamlit.testing.v1")
    monkeypatch.setattr(config, "CODE_DIR", tmp_path)
    monkeypatch.setenv("ASSISTANT_UI_PASSWORD", "sésame")
    monkeypatch.setenv(
        "ASSISTANT_DATA_ROOT", str(CODE_DIR / "demo_data")
    )
    monkeypatch.setenv("ASSISTANT_LANG", "fr")
    monkeypatch.delenv("ASSISTANT_ALLOW_LIVE", raising=False)
    return testing.AppTest.from_file(
        str(APP), default_timeout=30
    )


def enter(app):
    app.run()
    app.text_input(key="given").set_value("sésame")
    app.button(key="unlock").click().run()
    assert not app.exception
    return app


def pose(app):
    app.text_area(key="question").set_value("Autre question")
    app.button(key="ask").click().run()
    assert not app.exception
    return app


def test_page_closed_without_password(page, monkeypatch):
    monkeypatch.delenv("ASSISTANT_UI_PASSWORD")
    page.run()
    assert not page.exception
    assert t("fr", "ui_no_password") in page.error[0].value
    assert not page.text_input


def test_page_refuses_a_wrong_password(page):
    page.run()
    page.text_input(key="given").set_value("non")
    page.button(key="unlock").click().run()
    assert t("fr", "ui_wrong_password") in page.error[0].value
    assert not page.radio


def test_page_offers_only_simulated_when_live_is_off(page):
    enter(page)
    mode = page.radio(key="mode")
    assert mode.value == SIMULATED
    assert len(mode.options) == 1


def test_page_real_mode_is_second_choice(page, monkeypatch):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "1")
    enter(page)
    mode = page.radio(key="mode")
    assert mode.value == SIMULATED
    assert len(mode.options) == 2


def test_page_labels_the_simulated_answer(page):
    pose(enter(page))
    label = service.simulated_label("fr")
    assert label in [w.value for w in page.warning]
    assert "150 €" in page.code[0].value


def test_page_asks_the_model_once_only(page, monkeypatch):
    calls = []
    real_run = service.run_mode

    def counted(*args, **kwargs):
        calls.append(args)
        return real_run(*args, **kwargs)

    monkeypatch.setattr(service, "run_mode", counted)
    pose(enter(page))
    page.button(key="prepare").click().run()
    assert len(calls) == 1


def test_page_sends_only_what_was_previewed(page, tmp_path):
    pose(enter(page))
    page.text_input(key="who").set_value("Camille")
    page.button(key="prepare").click().run()
    outbox = tmp_path / "outbox" / "simulated"

    # Edited after the preview: the approval button goes away.
    edited = page.text_area(key="draft").value + " Ajout."
    page.text_area(key="draft").set_value(edited).run()
    assert t("fr", "ui_changed") in page.info[0].value
    assert "approve" not in [b.key for b in page.button]
    assert not outbox.exists()

    # A new preview, then the approval.
    page.button(key="prepare").click().run()
    page.button(key="approve").click().run()
    assert not page.exception
    written = list(outbox.iterdir())
    assert len(written) == 1
    assert "Ajout." in written[0].read_text("utf-8")
    assert list((tmp_path / "outbox").glob("*.md")) == []
