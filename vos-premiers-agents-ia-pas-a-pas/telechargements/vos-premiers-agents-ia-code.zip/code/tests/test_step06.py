"""Step 06: plan, mission state and resume, checks, review.

All with the simulated model: the model's decisions are
scripted; the code under test runs for real.
"""

import io
import json
from contextlib import redirect_stdout

import pytest
from anthropic.types import Message

from assistant.budget import GuardedModel, Ledger, SpendGuard
from assistant.config import CODE_DIR, LANGS
from assistant.corpus import Corpus
from assistant.llm import FakeModel, ModelReply, Usage
from assistant.llm_anthropic import AnthropicModel
from assistant.messages import t
from assistant.scenarios import (
    SYNTHESIS_TEXT,
    synthesis_plan,
    synthesis_session1,
    synthesis_session2,
)
from assistant.step06.mission import (
    MissionState,
    MissionStore,
    corpus_changes,
    run_mission,
)
from assistant.step06.plan import (
    PLAN_SCHEMA,
    Plan,
    PlanRefused,
    fixed_plan,
    propose_plan,
)
from assistant.step06.verify import (
    REVIEW_SCHEMA,
    assemble,
    review,
    review_input,
    run_checks,
)
from assistant.synthesis_cli import (
    open_corpus,
    run_synthesis,
    start_or_resume,
    synthesis_demo,
)


def corpus(lang="fr"):
    return Corpus.load(CODE_DIR / "demo_data" / lang, lang)


def plan_reply(steps):
    return FakeModel.json({"title": "Note", "steps": steps})


def step(i, goal="Établir un point", query="dépôt"):
    return {"id": f"s{i}", "goal": goal, "query": query}


# ---- the plan ----


def test_a_valid_plan_is_accepted_and_the_schema_is_sent():
    model = FakeModel([plan_reply([step(1), step(2)])])
    plan = propose_plan(model, "Question ?", "fr")
    assert [s.id for s in plan.steps] == ["s1", "s2"]
    assert model.requests[0]["schema"] == PLAN_SCHEMA
    assert model.requests[0]["tools"] == []


@pytest.mark.parametrize(
    "reply, where",
    [
        # Too ambitious: six steps, the code allows five.
        (plan_reply([step(i) for i in range(1, 7)]), "steps"),
        (plan_reply([step(1)]), "steps"),  # one step only
        (plan_reply([step(1), step(3)]), "step ids"),
        (plan_reply([step(1), step(2, query="")]), "query"),
        (FakeModel.says("Voici mon plan : …"), "json"),
        (FakeModel.truncated('{"title": "No'), "max_tokens"),
    ],
)
def test_an_invalid_plan_is_refused(reply, where):
    with pytest.raises(PlanRefused) as error:
        propose_plan(FakeModel([reply]), "Q ?", "fr")
    assert where in str(error.value).lower()


def _keys(schema):
    if isinstance(schema, dict):
        for key, value in schema.items():
            yield key
            yield from _keys(value)
    elif isinstance(schema, list):
        for value in schema:
            yield from _keys(value)


@pytest.mark.parametrize("schema", [PLAN_SCHEMA, REVIEW_SCHEMA])
def test_schemas_use_only_what_structured_outputs_accept(
    schema,
):
    """Bounds are refused by the API (docs/sources.md, T3):
    they live in the Pydantic classes instead."""
    unsupported = {
        "minimum",
        "maximum",
        "minLength",
        "maxLength",
        "maxItems",
    }
    assert not unsupported & set(_keys(schema))
    for obj in _objects(schema):
        assert obj["additionalProperties"] is False


def _objects(schema):
    if isinstance(schema, dict):
        if schema.get("type") == "object":
            yield schema
        for value in schema.values():
            yield from _objects(value)


@pytest.mark.parametrize("lang", LANGS)
def test_fixed_plan_is_always_the_same_three_steps(lang):
    plan = fixed_plan("Note", "dépôt", lang)
    assert [s.id for s in plan.steps] == ["s1", "s2", "s3"]
    assert {s.query for s in plan.steps} == {"dépôt"}


# ---- running, saving, resuming ----


def _new_state(lang="fr"):
    return MissionState(
        mission_id="t1",
        question=SYNTHESIS_TEXT[lang]["question"],
        lang=lang,
        today="2026-06-15",
        plan=Plan.model_validate(synthesis_plan(lang)),
    )


def _session1(tmp_path, lang="fr"):
    store = MissionStore(tmp_path / "missions")
    state = _new_state(lang)
    model = synthesis_session1(lang, corpus(lang))
    model._replies.pop(0)  # the plan is given, not proposed
    status = run_mission(model, state, corpus(lang), store)
    return store, status


def test_an_interrupted_mission_is_saved_after_each_step(
    tmp_path,
):
    store, status = _session1(tmp_path)
    assert status == "interrupted"
    saved = store.load("t1")
    statuses = {k: r.status for k, r in saved.results.items()}
    assert statuses == {
        "s1": "done",
        "s2": "done",
        "s3": "error",
    }
    # The failed attempt still cost tokens: they are kept.
    assert saved.results["s3"].input_tokens > 0
    assert [s.id for s in saved.todo()] == ["s3"]


def test_resume_runs_only_the_steps_not_done(tmp_path):
    store, _ = _session1(tmp_path)
    state = store.load("t1")
    model = synthesis_session2("fr", corpus())
    status = run_mission(model, state, corpus(), store)
    assert status == "done"
    # Two model calls: step 3 only (the review is not run).
    assert len(model.requests) == 2
    assert "s3" in model.requests[0]["messages"][0]["content"]
    # Trace of the failed attempt replaced by the new one.
    trace = store.load("t1").results["s3"].consulted
    assert "remboursement#p02" in trace


def test_a_saved_state_that_does_not_validate_is_refused(
    tmp_path,
):
    store, _ = _session1(tmp_path)
    path = store.path("t1")
    data = json.loads(path.read_text())
    data["plan"]["steps"] = []  # edited by hand, invalid
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError):
        store.load("t1")


# ---- checks and review ----


def _finished(tmp_path, lang="fr"):
    store, _ = _session1(tmp_path, lang)
    state = store.load("t1")
    run_mission(
        synthesis_session2(lang, corpus(lang)),
        state,
        corpus(lang),
        store,
    )
    return state


@pytest.mark.parametrize("lang", LANGS)
def test_demo_mission_passes_the_code_checks(tmp_path, lang):
    state = _finished(tmp_path, lang)
    checks = run_checks(state, corpus(lang))
    assert [(c.name, c.ok) for c in checks] == [
        ("steps_done", True),
        ("refs_in_sections", True),
        ("refs_valid", True),
        ("length", True),
    ]
    text = assemble(state)
    assert text.count("\n## ") == 4  # three steps + sources


def test_each_step_is_checked_against_its_own_trace(tmp_path):
    """s3 cites a passage read only during s2: refused."""
    state = _finished(tmp_path)
    result = state.result("s3")
    result.answer = result.answer.replace(
        "[remboursement#p05].", "[cr-ag-2026-03#p03]."
    )
    checks = {c.name: c for c in run_checks(state, corpus())}
    assert not checks["refs_valid"].ok
    assert "s3:cr-ag-2026-03#p03" in checks["refs_valid"].detail


def test_missing_refs_and_long_sections_are_reported(tmp_path):
    state = _finished(tmp_path)
    state.result("s1").answer = "Rien à citer."
    state.result("s2").answer += " mot" * 130
    checks = {c.name: c for c in run_checks(state, corpus())}
    assert checks["refs_in_sections"].detail == "s1"
    assert checks["length"].detail == "s2"


def test_code_checks_miss_a_claim_the_passage_does_not_back(
    tmp_path,
):
    """The demo's s3 misuses remboursement#p02 (refund
    requests, not the deposit): the reference exists, was
    read, the excerpt is exact. Only a reader can see it."""
    state = _finished(tmp_path)
    assert "[remboursement#p02]" in state.result("s3").answer
    assert all(c.ok for c in run_checks(state, corpus()))


def test_review_receives_full_passages_and_its_schema():
    state = _new_state()
    state.result("s1").answer = "150 € [cr-ag-2026-03#p03]."
    model = FakeModel([FakeModel.json({"issues": []})])
    opinion = review(model, state, corpus())
    assert opinion is not None and opinion.issues == []
    sent = model.requests[0]
    assert sent["schema"] == REVIEW_SCHEMA
    passage = corpus().passage("cr-ag-2026-03#p03").text
    assert passage in sent["messages"][0]["content"]
    assert review_input(state, corpus()).count("<passage") == 1


@pytest.mark.parametrize(
    "reply",
    [
        FakeModel.says("Tout va bien."),
        FakeModel.json({"issues": [{"step": "x9"}]}),
        FakeModel.truncated('{"issues": ['),
    ],
)
def test_an_unusable_review_gives_no_opinion(reply):
    assert (
        review(FakeModel([reply]), _new_state(), corpus())
        is None
    )


# ---- the demo and the paid paths ----


@pytest.mark.parametrize("lang", LANGS)
def test_demo_output_is_deterministic_and_fits(lang):
    outputs = []
    for _ in range(2):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            assert synthesis_demo(lang, corpus(lang)) == 0
        outputs.append(buffer.getvalue())
    assert outputs[0] == outputs[1]
    assert all(len(x) <= 64 for x in outputs[0].splitlines())
    lines = outputs[0].splitlines()
    header = next(
        i
        for i, x in enumerate(lines)
        if x.startswith(t(lang, "review_demo"))
    )
    assert lines[header + 1].startswith("  s3 ")


def test_guard_counts_structured_calls():
    ledger = Ledger()
    guard = SpendGuard(cap_usd=1.0, max_calls=5, ledger=ledger)
    fake = FakeModel([plan_reply([step(1), step(2)])])
    fake.name = "claude-haiku-5-5"
    model = GuardedModel(fake, guard)
    propose_plan(model, "Q ?", "fr")
    assert ledger.attempts == 1 and guard.calls == 1


def test_anthropic_request_carries_the_format():
    """Offline: shape of the request only, not acceptance."""
    raw = {
        "id": "msg_t",
        "type": "message",
        "role": "assistant",
        "model": "claude-haiku-5-5",
        "stop_reason": "end_turn",
        "stop_sequence": None,
        "usage": {"input_tokens": 10, "output_tokens": 5},
        "content": [{"type": "text", "text": '{"issues": []}'}],
    }

    class Messages:
        def create(self, **params):
            self.params = params
            return Message.model_validate(raw)

    class Client:
        messages = Messages()

    model = AnthropicModel(
        "claude-haiku-5-5", effort="medium", client=Client()
    )
    reply = model.complete_json("s", [], REVIEW_SCHEMA)
    sent = Client.messages.params
    assert sent["output_config"] == {
        "format": {
            "type": "json_schema",
            "schema": REVIEW_SCHEMA,
        },
        "effort": "medium",
    }
    assert "tools" not in sent
    assert reply.text == '{"issues": []}'


def test_paid_synthesis_is_off_by_default(monkeypatch, capsys):
    from assistant.cli import main

    monkeypatch.delenv("ASSISTANT_ALLOW_LIVE", raising=False)
    assert main(["synthesis", "--question", "Q ?"]) == 2
    assert "ASSISTANT_ALLOW_LIVE=1" in capsys.readouterr().out


# ---- T7 consequences ----


@pytest.mark.parametrize("call", ["plan", "review"])
def test_a_refusal_gives_no_plan_and_no_opinion(call):
    """A refusal is a 200, billed, and may not match the schema
    (T7): the code must look at stop_reason first."""
    refusal = ModelReply("refusal", "Non.", [], Usage(1, 1), [])
    model = FakeModel([refusal])
    if call == "plan":
        with pytest.raises(PlanRefused, match="refusal"):
            propose_plan(model, "Q ?", "fr")
    else:
        assert review(model, _new_state(), corpus()) is None


def test_enum_capitalization_is_tolerated(tmp_path):
    """T7: capitalization of enum values is not guaranteed."""
    from assistant.llm import ToolCall
    from assistant.memory import MemoryStore
    from assistant.step05.tools import build_toolbox_step05

    memory = MemoryStore(tmp_path, lambda _: True)
    box = build_toolbox_step05(corpus(), tmp_path, {}, memory)
    outcome = box.execute(
        ToolCall(
            "c1",
            "remember",
            {"kind": "Preference", "text": "Trois points."},
        )
    )
    assert not outcome.is_error
    assert memory.entries[0].kind == "preference"


# ---- replay and side effects ----


def test_steps_have_no_tool_that_changes_anything(tmp_path):
    """A replayed step must repeat no action."""
    store, _ = _session1(tmp_path)
    state = store.load("t1")
    model = synthesis_session2("fr", corpus())
    run_mission(model, state, corpus(), store)
    names = {t["name"] for t in model.requests[0]["tools"]}
    assert names == {
        "list_documents",
        "search_documents",
        "read_document",
    }
    assert not (tmp_path / "notes").exists()


def test_interruption_before_the_save_replays_the_step(
    tmp_path,
):
    """Stopped after a step, before its save: the step runs
    again, it costs tokens twice, and nothing else happens."""

    class Crashing(MissionStore):
        def save(self, state):
            if state.result("s1").status == "done":
                raise KeyboardInterrupt
            super().save(state)

    store = Crashing(tmp_path / "missions")
    state = _new_state()
    MissionStore.save(store, state)
    script = synthesis_session1("fr", corpus())
    script._replies.pop(0)
    with pytest.raises(KeyboardInterrupt):
        run_mission(script, state, corpus(), store)
    saved = MissionStore(tmp_path / "missions").load("t1")
    assert [s.id for s in saved.todo()] == ["s1", "s2", "s3"]


# ---- --dossier, independent of the interface language ----


def test_folder_and_interface_language_are_independent(
    tmp_path, capsys
):
    """German messages and prompts, French documents."""
    opened = open_corpus("de", None, "fr")
    assert opened[0].lang == "fr"
    assert opened[1].endswith("demo_data/fr")

    fake = FakeModel(
        synthesis_session1("de", opened[0])._replies[:-1]
        + synthesis_session2("de", opened[0])._replies
    )
    store = MissionStore(tmp_path / "missions")
    assert (
        run_synthesis(
            fake,
            store,
            opened,
            "Frage?",
            "de",
            "2026-06-15",
            "model",
            "t2",
        )
        == 0
    )
    out = capsys.readouterr().out
    assert "Auftrag abgeschlossen" in out
    task = fake.requests[1]["messages"][0]["content"]
    assert task.startswith("Auftrag:")
    state = store.load("t2")
    assert state.corpus_lang == "fr"
    assert all(c.ok for c in run_checks(state, opened[0]))
    assert (tmp_path / "missions" / "t2.md").exists()
    assert (tmp_path / "missions" / "t2-report.txt").exists()


def test_a_custom_folder_is_used(tmp_path):
    (tmp_path / "docs").mkdir()
    (tmp_path / "docs" / "note-a.md").write_text(
        "---\nid: note-a\ntitle: A\n---\n[p01] Texte libre.\n",
        "utf-8",
    )
    corpus_, folder = open_corpus(
        "fr", str(tmp_path / "docs"), None
    )
    assert corpus_.passage("note-a#p01").text == "Texte libre."
    assert folder == str((tmp_path / "docs").resolve())


@pytest.mark.parametrize("name", ["vide", "absent"])
def test_a_folder_without_documents_is_refused(
    tmp_path, capsys, name
):
    (tmp_path / "vide").mkdir()
    assert open_corpus("fr", str(tmp_path / name), None) is None
    assert t("fr", "no_docs") in capsys.readouterr().out


def test_a_mission_does_not_resume_on_another_folder(
    tmp_path, capsys
):
    store = MissionStore(tmp_path / "missions")
    state = _new_state()
    state.folder = "/un/dossier"
    store.save(state)
    again = start_or_resume(
        None, store, "t1", "Q", "fr", "d", "model", "/un/autre"
    )
    assert again is None
    assert t("fr", "other_folder") in capsys.readouterr().out


# ---- sending comes last, after the checks ----


def _send_run(tmp_path, replies, send_to, answers):
    from assistant.approval import OutboxSender
    from assistant.step07.gate import ActionJournal, SendGate

    opened = open_corpus("fr", None, None)
    asked = []

    def ask(preview):
        asked.append(preview)
        return answers.pop(0)

    gate = SendGate(
        {"bureau@rivelune.example.org"},
        ask,
        "camille",
        OutboxSender(tmp_path / "outbox"),
        ActionJournal(tmp_path / "actions.jsonl"),
    )
    code = run_synthesis(
        FakeModel(replies),
        MissionStore(tmp_path / "missions"),
        opened,
        "Q ?",
        "fr",
        "2026-06-15",
        "model",
        "t3",
        gate,
        send_to,
    )
    return code, asked


def _replies(c):
    return (
        synthesis_session1("fr", c)._replies[:-1]
        + synthesis_session2("fr", c)._replies
    )


def test_the_synthesis_is_sent_only_with_approval(tmp_path):
    code, asked = _send_run(
        tmp_path,
        _replies(corpus()),
        "bureau@rivelune.example.org",
        [True],
    )
    assert code == 0 and len(asked) == 1
    sent = next((tmp_path / "outbox").iterdir())
    final = (tmp_path / "missions" / "t3.md").read_text("utf-8")
    assert final in sent.read_text("utf-8")
    assert final in asked[0]  # the person saw the final text


def test_failed_checks_mean_no_sending_proposed(tmp_path):
    replies = _replies(corpus())
    replies[3] = FakeModel.says("Sans aucune référence.")
    code, asked = _send_run(
        tmp_path, replies, "bureau@rivelune.example.org", [True]
    )
    assert code == 5 and asked == []
    assert not (tmp_path / "outbox").exists()


# ---- resuming on documents that changed ----


def _folder(tmp_path, **docs):
    folder = tmp_path / "docs"
    folder.mkdir(exist_ok=True)
    for name, text in docs.items():
        (folder / f"{name}.md").write_text(
            f"---\nid: {name}\ntitle: T\n---\n[p01] {text}\n",
            "utf-8",
        )
    return folder


def test_same_documents_give_the_same_digests(tmp_path):
    folder = _folder(tmp_path, a="Un.", b="Deux.")
    first = Corpus.load(folder, "fr").digests()
    assert first == Corpus.load(folder, "fr").digests()
    assert corpus_changes(first, first) == []


@pytest.mark.parametrize(
    "change", ["modified", "added", "removed"]
)
def test_any_change_of_the_documents_is_detected(
    tmp_path, change
):
    folder = _folder(tmp_path, a="Un.", b="Deux.")
    before = Corpus.load(folder, "fr").digests()
    if change == "modified":
        _folder(tmp_path, a="Un, modifié.")
        expected = ["a"]
    elif change == "added":
        _folder(tmp_path, c="Trois.")
        expected = ["c"]
    else:
        (folder / "b.md").unlink()
        expected = ["b"]
    after = Corpus.load(folder, "fr").digests()
    assert corpus_changes(before, after) == expected


def test_a_changed_header_counts_as_a_change(tmp_path):
    folder = _folder(tmp_path, a="Un.")
    before = Corpus.load(folder, "fr").digests()
    (folder / "a.md").write_text(
        "---\nid: a\ntitle: T\nstatus: x\n---\n[p01] Un.\n",
        "utf-8",
    )
    after = Corpus.load(folder, "fr").digests()
    assert corpus_changes(before, after) == ["a"]


def test_no_resume_on_changed_documents(tmp_path, capsys):
    store = MissionStore(tmp_path / "missions")
    state = _new_state()
    state.doc_digests = {"a": "1", "b": "2"}
    store.save(state)
    again = start_or_resume(
        None,
        store,
        "t1",
        "Q",
        "fr",
        "d",
        "model",
        "",
        digests={"a": "1", "b": "changed"},
    )
    assert again is None
    out = capsys.readouterr().out
    assert t("fr", "corpus_changed") in out and " b" in out
    # The saved mission is left as it was.
    assert store.load("t1").doc_digests == {"a": "1", "b": "2"}


def test_restart_discards_the_saved_mission(tmp_path, capsys):
    store = MissionStore(tmp_path / "missions")
    state = _new_state()
    state.doc_digests = {"a": "1"}
    state.result("s1").status = "done"
    store.save(state)
    fresh = start_or_resume(
        FakeModel([FakeModel.json(synthesis_plan("fr"))]),
        store,
        "t1",
        "Q",
        "fr",
        "d",
        "model",
        "",
        digests={"a": "2"},
        restart=True,
    )
    assert fresh.result("s1").status == "pending"
    assert store.load("t1").doc_digests == {"a": "2"}


def test_a_replay_has_no_effect_but_can_answer_differently(
    tmp_path,
):
    """No external effect, yet not reproducible."""
    store, _ = _session1(tmp_path)
    state = store.load("t1")
    first = FakeModel(
        [FakeModel.says("Réponse A [remboursement#p05].")]
    )
    run_mission(first, state, corpus(), store)
    answer_a = state.result("s3").answer
    state.result("s3").status = "error"  # replayed once more
    second = FakeModel(
        [FakeModel.says("Réponse B [remboursement#p05].")]
    )
    run_mission(second, state, corpus(), store)
    assert answer_a != state.result("s3").answer
    assert (
        store.load("t1")
        .result("s3")
        .answer.startswith("Réponse B")
    )


def test_review_sees_date_and_status_of_each_passage():
    """Found on a real run: without them, the reviewer called
    a correct "approved" or "draft" unsupported."""
    state = _new_state()
    state.result("s1").answer = "150 € [cr-ag-2026-03#p03]."
    text = review_input(state, corpus())
    assert 'date="2026-03-21"' in text
    assert 'status="approuvé"' in text
