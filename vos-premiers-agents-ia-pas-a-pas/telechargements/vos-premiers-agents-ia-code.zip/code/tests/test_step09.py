"""The comparison, on scripted models: these tests check the
rules of the experiment. They say nothing on which is better."""

import csv
import json
import shutil
from pathlib import Path

import pytest

from assistant.budget import Ledger
from assistant.config import CODE_DIR
from assistant.corpus import Corpus
from assistant.llm import FakeModel, ModelError
from assistant.protocol import max_per_call
from assistant.step09 import compare
from assistant.step09.compare import (
    RunLimits,
    limit_reached,
    single_agent,
    team,
)
from assistant.step09.evaluate import (
    EXPERIMENT,
    Results,
    RoundRefused,
    check_limits,
    check_round,
    fingerprint,
    load_config,
    report,
    round_max_usd,
    round_runs,
    round_states,
    run_order,
    run_round,
)
from assistant.step09.frozen import (
    FrozenCorpusChanged,
    changes,
    freeze,
    load_frozen,
)
from assistant.step09.grading import (
    CRITERIA,
    new_batch,
    read_grades,
)
from assistant.step09.score import auto_score, summary
from assistant.step09.simulated import SCRIPTS
from assistant.step09.tasks import load_tasks

TODAY = "2026-06-15"
MAX_CALLS = RunLimits().max_calls
GRID = json.loads(
    (EXPERIMENT / "grading-grid.json").read_text("utf-8")
)
RECORDED_CONFIG = load_config()
# Rules start from the initial limits; the change recorded
# after tuning has its own test.
CONFIG = {
    **RECORDED_CONFIG,
    "limits": {
        "max_calls": 10,
        "max_tokens": 60000,
        "max_seconds": 300,
    },
    "limit_changes": [],
}


@pytest.fixture
def tasks():
    return load_tasks(EXPERIMENT / "tasks.json")


@pytest.fixture
def frozen():
    return load_frozen(EXPERIMENT / "corpus", "fr")


@pytest.fixture
def lab(tmp_path):
    """A private copy of the experiment."""
    target = tmp_path / "lab"
    shutil.copytree(EXPERIMENT, target)
    return target


def task_by_id(tasks, name):
    return next(t for t in tasks if t.id == name)


def maker(corpus, overrides=None):
    def make(task, arch):
        if overrides and (task.id, arch) in overrides:
            model = overrides[(task.id, arch)]()
        else:
            model = SCRIPTS[arch](task, corpus)
        model.name = "claude-haiku-5-5"
        return model

    return make


# ---- The tasks and the frozen documents ----


def test_splits_are_fixed_and_separate(tasks):
    tuning = [t for t in tasks if t.split == "tuning"]
    final = [t for t in tasks if t.split == "final"]
    assert (len(tuning), len(final)) == (4, 8)
    assert not {t.question for t in tuning} & {
        t.question for t in final
    }
    for group in (tuning, final):
        categories = {t.category for t in group}
        assert {
            "fact",
            "contradiction",
            "absent",
            "injection",
        } <= (categories)


def test_final_questions_are_not_in_the_protocol_or_demos(
    tasks,
):
    from assistant.protocol import TASKS

    earlier = {t["q"] for t in TASKS}
    assert not earlier & {t.question for t in tasks}


def test_expected_answers_rest_on_the_documents(tasks, frozen):
    computed = {"f4-ebike-day": "21"}
    for task in tasks:
        texts = []
        for group in task.expected_refs:
            for ref in group:
                passage = frozen.passage(ref)
                assert passage is not None, ref
                texts.append(passage.text)
        for group in task.must_state:
            for word in group:
                if computed.get(task.id) == word:
                    continue
                assert any(word in text for text in texts), word
        assert task.key_points
        if task.absent:
            assert not task.expected_refs
            assert not task.must_state


def test_frozen_copy_matches_the_source_at_freezing():
    source = Corpus.load(CODE_DIR / "demo_data" / "fr", "fr")
    copy = Corpus.load(EXPERIMENT / "corpus", "fr")
    assert source.digests() == copy.digests()


def test_freeze_never_overwrites(tmp_path):
    source = CODE_DIR / "demo_data" / "fr"
    freeze(source, tmp_path / "c")
    with pytest.raises(FileExistsError):
        freeze(source, tmp_path / "c")


@pytest.mark.parametrize("change", ["edit", "add", "remove"])
def test_any_change_in_the_frozen_copy_is_refused(
    tmp_path, change
):
    folder = tmp_path / "c"
    freeze(CODE_DIR / "demo_data" / "fr", folder)
    assert changes(folder) == []
    target = folder / "statuts.md"
    if change == "edit":
        target.write_text(
            target.read_text("utf-8") + " x", "utf-8"
        )
    elif change == "add":
        (folder / "new.md").write_text("x", "utf-8")
    else:
        target.unlink()
    with pytest.raises(FrozenCorpusChanged):
        load_frozen(folder, "fr")


def test_change_during_a_round_stops_it(lab, tmp_path, frozen):
    """Checked before each run, not only at the start."""
    calls = []

    def make(task, arch):
        if calls:
            path = lab / "corpus" / "statuts.md"
            path.write_text("changed", "utf-8")
        calls.append(task.id)
        model = SCRIPTS[arch](task, frozen)
        model.name = "claude-haiku-5-5"
        return model

    with pytest.raises(FrozenCorpusChanged):
        run_round(
            "tuning",
            make,
            "simulated",
            lab,
            tmp_path / "o",
            Ledger(),
        )


# ---- Same rules for both ----


def test_both_read_the_same_limits(monkeypatch):
    limits = RunLimits(4, 1000, 9.0)
    assert limits.loop().max_turns == 4
    assert compare._budget(limits).max_calls == 4
    assert compare._budget(limits).max_tokens == 1000
    assert limits_of_config() == RunLimits()


def limits_of_config():
    from assistant.step09.evaluate import limits_of

    return limits_of(CONFIG)


def endless():
    return FakeModel(
        [
            FakeModel.calls(
                ("search_documents", {"query": "vélo"})
            )
            for _ in range(40)
        ]
    )


@pytest.mark.parametrize("runner", [single_agent, team])
def test_call_limit_is_the_same_for_both(runner, frozen):
    model = endless()
    out = runner(model, "Question", frozen, TODAY)
    assert len(model.requests) <= MAX_CALLS
    assert out.kind == "incomplete"
    assert not out.answer


def verdict(n, ok, reason="raison"):
    return {"claim": n, "supported": ok, "reason": reason}


def team_replies(task, corpus, *after):
    script = SCRIPTS["team"](task, corpus)._replies
    # Reads, then submit_brief, then the writer's draft.
    return FakeModel([*script[:-1], *after])


def test_team_revises_once_then_keeps_objections(tasks, frozen):
    task = task_by_id(tasks, "f1-delay")
    ref = task.expected_refs[0][0]
    no = FakeModel.calls(
        ("submit_review", {"verdicts": [verdict(1, False)]})
    )
    again = FakeModel.calls(
        (
            "submit_review",
            {"verdicts": [verdict(1, False, "encore")]},
        )
    )
    new = FakeModel.json(
        {"claims": [{"text": "Nouveau 14", "refs": [ref]}]}
    )
    model = team_replies(task, frozen, no, new, again)
    out = team(model, task.question, frozen, TODAY)
    assert out.revisions == 1
    assert out.kind == "complete"
    assert out.status == "done_with_objections"
    assert "Nouveau 14" in out.answer
    assert "Réserves du vérificateur" not in out.answer
    assert "encore" in out.full_output
    assert out.calls_by_role["writer"] == 2


def test_refused_revision_keeps_the_reviewed_draft(
    tasks, frozen
):
    task = task_by_id(tasks, "f1-delay")
    no = FakeModel.calls(
        ("submit_review", {"verdicts": [verdict(1, False)]})
    )
    bad = FakeModel.json(
        {"claims": [{"text": "x", "refs": []}]}
    )
    model = team_replies(task, frozen, no, bad)
    out = team(model, task.question, frozen, TODAY)
    assert out.kind == "complete"
    assert "revision refused" in out.status
    assert "Réponse simulée 14" in out.answer


def test_limit_during_revision_keeps_the_reviewed_draft(
    tasks, frozen
):
    task = task_by_id(tasks, "f1-delay")
    no = FakeModel.calls(
        ("submit_review", {"verdicts": [verdict(1, False)]})
    )
    failure = ModelError("connection lost", True)
    model = team_replies(task, frozen, no, failure)
    out = team(model, task.question, frozen, TODAY)
    assert out.kind == "complete"
    assert "revision stopped" in out.status
    assert out.objections


def test_team_can_say_that_nothing_was_found(tasks, frozen):
    task = task_by_id(tasks, "f6-phone")
    out = team(
        SCRIPTS["team"](task, frozen),
        task.question,
        frozen,
        TODAY,
    )
    assert out.kind == "complete" and out.status == "no_answer"
    assert "ne permettent pas" in out.answer


@pytest.mark.parametrize(
    "stop,kind",
    [
        (FakeModel.truncated("Co"), "incomplete"),
        (
            ModelError("500 (simulated)", True),
            "api_error",
        ),
    ],
)
def test_outcome_kinds(stop, kind, tasks, frozen):
    task = task_by_id(tasks, "f1-delay")
    out = single_agent(
        FakeModel([stop]), task.question, frozen, TODAY
    )
    assert out.kind == kind and not out.answer


def test_refusal_is_its_own_kind(frozen):
    refusal = FakeModel.says("Non.")
    refusal.stop_reason = "refusal"
    for runner in (single_agent, team):
        out = runner(
            FakeModel([refusal]), "Question", frozen, TODAY
        )
        assert out.kind == "refusal"


def test_refused_draft_delivers_nothing(tasks, frozen):
    task = task_by_id(tasks, "f1-delay")
    script = SCRIPTS["team"](task, frozen)._replies
    bad = FakeModel.json(
        {"claims": [{"text": "x", "refs": []}]}
    )
    out = team(
        FakeModel([*script[:-2], bad]),
        task.question,
        frozen,
        TODAY,
    )
    assert out.kind == "incomplete" and not out.answer
    assert out.status.startswith("draft_refused")


def test_same_checker_reads_both_answers(tasks, frozen):
    for task in tasks:
        for name, runner in compare.RUNNERS.items():
            out = runner(
                SCRIPTS[name](task, frozen),
                task.question,
                frozen,
                TODAY,
            )
            score = auto_score(
                task, out.answer, frozen, out.consulted
            )
            assert out.kind == "complete", (task.id, name)
            for key in (
                "refs_exist",
                "refs_consulted",
                "excerpts_found",
                "expected_refs",
                "must_state",
                "must_not_state",
            ):
                assert score[key], (task.id, name, key)


def test_forbidden_and_missing_strings_are_detected(
    tasks, frozen
):
    task = task_by_id(tasks, "f7-rumour")
    score = auto_score(
        task, "Écrivez à yanis.roux@example.org", frozen, {}
    )
    assert not score["must_not_state"]
    assert not score["must_state"]
    assert not score["expected_refs"]
    # 150 is not found inside 1500.
    score = auto_score(task, "1500 €", frozen, {})
    assert not score["must_state"]


# ---- The rules of the rounds ----


def test_order_is_reproducible_and_covers_both(tasks):
    first = run_order(tasks, "final", 1)
    assert first == run_order(tasks, "final", 1)
    assert first != run_order(tasks, "final", 2)
    assert len(first) == 16
    pairs = {(t.id, a) for t, a in first}
    assert len(pairs) == 16


def test_budget_of_the_experiment_fits_the_hypothesis(tasks):
    """Blocks A, B, C at their maximum, then one tuning round
    and one final round at theirs: a planning figure only."""
    from assistant.protocol import CAP_USD, block_max_usd

    blocks = sum(block_max_usd(b) for b in "ABC")
    rounds = round_max_usd(
        round_runs(tasks, "tuning")
    ) + round_max_usd(round_runs(tasks, "final"))
    assert round_runs(tasks, "tuning") == 8
    assert round_runs(tasks, "final") == 16
    assert rounds == pytest.approx(
        24 * MAX_CALLS * max_per_call("claude-haiku-5-5")
    )
    assert blocks + rounds <= CAP_USD


def rows_of(split, n=1, fp="f"):
    return {
        "split": split,
        "round": n,
        "fingerprint": fp,
    }


def results_with(tmp_path, *rows):
    results = Results(tmp_path / "r.jsonl")
    results.rows = list(rows)
    return results


def test_final_needs_tuning_first(tmp_path, tasks):
    with pytest.raises(
        RoundRefused, match="tuning round first"
    ):
        check_round(
            "final",
            results_with(tmp_path),
            tasks,
            0,
            "f",
            CONFIG,
        )


def test_no_tuning_after_a_final_run(tmp_path, tasks):
    results = results_with(
        tmp_path, rows_of("tuning"), rows_of("final")
    )
    with pytest.raises(RoundRefused, match="no more tuning"):
        check_round("tuning", results, tasks, 0, "f", CONFIG)


def test_final_is_locked_on_its_fingerprint(tmp_path, tasks):
    results = results_with(
        tmp_path,
        rows_of("tuning", fp="x"),
        rows_of("final", fp="f"),
    )
    assert (
        check_round("final", results, tasks, 0, "f", CONFIG)
        == 2
    )
    with pytest.raises(RoundRefused, match="changed"):
        check_round("final", results, tasks, 0, "other", CONFIG)


def test_tuning_may_change_things(tmp_path, tasks):
    results = results_with(tmp_path, rows_of("tuning", fp="x"))
    assert (
        check_round("tuning", results, tasks, 0, "y", CONFIG)
        == 2
    )
    assert (
        check_round("final", results, tasks, 0, "y", CONFIG)
        == 1
    )


def test_round_limits(tmp_path, tasks):
    tuning = results_with(
        tmp_path, rows_of("tuning", 1), rows_of("tuning", 2)
    )
    with pytest.raises(RoundRefused, match="used up"):
        check_round("tuning", tuning, tasks, 0, "f", CONFIG)


def test_planned_rounds_are_a_ceiling(tmp_path, tasks):
    assert CONFIG["final_rounds_planned"] == 3
    finals = [rows_of("final", n) for n in (1, 2, 3)]
    full = results_with(tmp_path, rows_of("tuning"), *finals)
    with pytest.raises(RoundRefused, match="planned"):
        check_round("final", full, tasks, 0, "f", CONFIG)


def test_number_of_rounds_is_locked_with_the_fingerprint(lab):
    first = fingerprint(lab)
    path = lab / "config.json"
    config = json.loads(path.read_text("utf-8"))
    config["final_rounds_planned"] = 2
    path.write_text(json.dumps(config), "utf-8")
    assert fingerprint(lab) != first


def test_round_needs_its_maximal_cost_under_the_limit(
    tmp_path, tasks
):
    results = results_with(tmp_path, rows_of("tuning"))
    final = round_max_usd(16)
    assert check_round(
        "final", results, tasks, 2 - final, "f", CONFIG
    )
    with pytest.raises(RoundRefused, match="does not fit"):
        check_round(
            "final",
            results,
            tasks,
            2 - final + 0.01,
            "f",
            CONFIG,
        )
    # The limit given for the run applies, not only 2.00 USD.
    with pytest.raises(RoundRefused, match="does not fit"):
        check_round(
            "final", results, tasks, 0, "f", CONFIG, 0.5
        )


def changed(limits, changes):
    return {
        **CONFIG,
        "limits": limits,
        "limit_changes": changes,
    }


def test_limits_change_only_after_tuning_with_a_reason():
    new = {
        "max_calls": 12,
        "max_tokens": 60000,
        "max_seconds": 300,
    }
    note = {"justification": "le workflow atteint le plafond"}
    check_limits(CONFIG, False)
    with pytest.raises(RoundRefused, match="after a tuning"):
        check_limits(changed(new, [note]), False)
    with pytest.raises(RoundRefused, match="justification"):
        check_limits(changed(new, []), True)
    with pytest.raises(RoundRefused, match="justification"):
        check_limits(
            changed(new, [{"justification": " "}]), True
        )
    check_limits(changed(new, [note]), True)


@pytest.mark.parametrize(
    "status,name",
    [
        ("max_turns", "calls"),
        ("team budget reached", "calls_or_tokens"),
        ("token_budget", "tokens"),
        ("max_seconds", "seconds"),
        ("done", None),
    ],
)
def test_limit_names(status, name):
    assert limit_reached(status) == name


def test_fingerprint_follows_prompts_tasks_documents(lab):
    first = fingerprint(lab)
    path = lab / "tasks.json"
    path.write_text(path.read_text("utf-8") + " ", "utf-8")
    assert fingerprint(lab) != first


# ---- Results kept ----


def full_round(
    lab, folder, frozen, split="tuning", overrides=None
):
    ledger = Ledger(folder / "ledger.jsonl")
    return run_round(
        split,
        maker(frozen, overrides),
        "simulated",
        lab,
        folder,
        ledger,
    )


def test_results_are_appended_never_replaced(
    lab, tmp_path, frozen
):
    folder = tmp_path / "o"
    full_round(lab, folder, frozen)
    count = len(Results(folder / "runs.jsonl").rows)
    assert count == 8
    full_round(lab, folder, frozen, "final")
    full_round(lab, folder, frozen, "final")
    rows = Results(folder / "runs.jsonl").rows
    assert len(rows) == 8 + 16 + 16
    assert {r["source"] for r in rows} == {"simulated"}


def test_api_failure_gets_one_new_attempt_both_kept(
    lab, tmp_path, frozen, tasks
):
    task = task_by_id(tasks, "t1-luggage")

    def failing():
        return FakeModel([ModelError("500 (simulated)", True)])

    folder = tmp_path / "o"
    full_round(
        lab,
        folder,
        frozen,
        overrides={(task.id, "agent"): failing},
    )
    rows = [
        r
        for r in Results(folder / "runs.jsonl").rows
        if r["task"] == task.id and r["architecture"] == "agent"
    ]
    assert [r["attempt"] for r in rows] == [1, 2]
    assert all(r["kind"] == "api_error" for r in rows)
    assert all(r["charged_usd"] > 0 for r in rows)
    stats = summary(rows, {}, tasks)
    assert stats["runs"] == 1 and stats["attempts"] == 2
    # No answer counts 0; it does not vanish.
    assert stats["no_answer"] == 1 and stats["graded"] == 0
    assert stats["points"]["exactitude"] == (0, 2)


def test_limit_failure_is_not_retried(
    lab, tmp_path, frozen, tasks
):
    task = task_by_id(tasks, "t1-luggage")
    folder = tmp_path / "o"
    full_round(
        lab,
        folder,
        frozen,
        overrides={(task.id, "team"): endless},
    )
    rows = [
        r
        for r in Results(folder / "runs.jsonl").rows
        if r["task"] == task.id and r["architecture"] == "team"
    ]
    assert len(rows) == 1 and rows[0]["kind"] == "incomplete"


def partial_round(lab, folder, frozen):
    full_round(lab, folder, frozen)
    ledger = Ledger(folder / "ledger.jsonl")

    def expensive(task, arch):
        ledger.add({"charged_usd": 0.5})
        return maker(frozen)(task, arch)

    return run_round(
        "final", expensive, "simulated", lab, folder, ledger
    )


def test_cap_mid_round_keeps_the_missing_runs_visible(
    lab, tmp_path, frozen, tasks
):
    folder = tmp_path / "o"
    out = partial_round(lab, folder, frozen)
    rows = Results(folder / "runs.jsonl").rows
    final = [r for r in rows if r["split"] == "final"]
    assert out["stopped"]
    assert len({r["slot"] for r in final}) == 16
    assert any(r["kind"] == "not_run" for r in final)
    complete, partial = round_states(final, 16)
    assert (complete, partial) == ([], [1])


def test_partial_round_is_never_shown_as_complete(
    lab, tmp_path, frozen, tasks
):
    folder = tmp_path / "o"
    partial_round(lab, folder, frozen)
    rows = Results(folder / "runs.jsonl").rows
    text = report(rows, {}, tasks, CONFIG, "en")
    final = " ".join(
        text[text.index("Evaluation tasks") :].split()
    )
    assert "0 complete, 1 partial" in final
    assert "PARTIAL" in final
    assert "incomplete comparisons" in final
    # Outside the counts: no block of figures for this round.
    assert "single agent:" not in final


def fill(sheet, value="2", grader="B. Siri"):
    with open(sheet, encoding="utf-8", newline="") as f:
        data = list(csv.DictReader(f))
    for line in data:
        for name in CRITERIA:
            if line[name] != "n/a":
                line[name] = value
        line["grader"] = grader
    with open(sheet, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0]))
        writer.writeheader()
        writer.writerows(data)


def batch(lab, tmp_path, frozen, tasks, split="tuning"):
    folder = tmp_path / "o"
    full_round(lab, folder, frozen)
    rows = Results(folder / "runs.jsonl").rows
    sheet = new_batch(
        rows, tasks, GRID, folder / "grading", split
    )
    return folder, rows, sheet


def test_sheet_hides_architecture_cost_and_mixes(
    lab, tmp_path, frozen, tasks
):
    folder, rows, sheet = batch(lab, tmp_path, frozen, tasks)
    for path in (sheet, folder / "grading" / "forms-1.md"):
        text = path.read_text("utf-8").lower()
        for word in (
            "architecture",
            "workflow",
            "usd",
            "tokens",
            "calls",
            "seconds",
            "charged",
        ):
            assert word not in text, word
    assert (
        "exactitude,sources,contradictions,absence"
        in (sheet.read_text("utf-8").splitlines()[0])
    )
    with open(sheet, encoding="utf-8", newline="") as f:
        ids = [line["answer_id"] for line in csv.DictReader(f)]
    # The id tells nothing: it is not derived from the run.
    assert len(set(ids)) == 8
    assert all(len(i) == 8 for i in ids)


def test_criteria_follow_the_task(tasks):
    for task in tasks:
        assert "exactitude" in task.criteria
        assert ("absence" in task.criteria) == task.absent
        assert ("sources" in task.criteria) != task.absent
        if task.category == "contradiction":
            assert "contradictions" in task.criteria


def team_with_objection(tasks, frozen):
    task = task_by_id(tasks, "f1-delay")
    no = FakeModel.calls(
        (
            "submit_review",
            {"verdicts": [verdict(1, False, "douteux")]},
        )
    )
    bad = FakeModel.json(
        {"claims": [{"text": "x", "refs": []}]}
    )
    return task, lambda: team_replies(task, frozen, no, bad)


def test_two_views_of_the_same_run(
    lab, tmp_path, frozen, tasks
):
    """Blind forms: the common final answer. Archive: all that
    the user would see, reservations included."""
    task, script = team_with_objection(tasks, frozen)
    folder = tmp_path / "o"
    full_round(
        lab,
        folder,
        frozen,
        "tuning",
    )
    full_round(
        lab,
        folder,
        frozen,
        "final",
        overrides={(task.id, "team"): script},
    )
    rows = Results(folder / "runs.jsonl").rows
    row = next(
        r
        for r in rows
        if r["task"] == task.id and r["architecture"] == "team"
    )
    assert "Réserves du vérificateur" not in row["answer"]
    assert "douteux" in row["full_output"]
    assert row["objections"]
    grading = folder / "grading"
    sheet = new_batch(rows, tasks, GRID, grading, "final")
    assert "douteux" not in sheet.read_text("utf-8")
    assert "Réserves" not in (grading / "forms-1.md").read_text(
        "utf-8"
    )
    apart = (grading / "reservations-1.csv").read_text("utf-8")
    assert "douteux" in apart and "useful_0_1_2" in apart


def test_no_grade_without_a_person(
    lab, tmp_path, frozen, tasks
):
    """Automatic checks all pass; there is still no grade."""
    folder, rows, sheet = batch(lab, tmp_path, frozen, tasks)
    assert read_grades(folder / "grading") == {}
    assert all(r["auto"]["must_state"] for r in rows)
    text = " ".join(
        report(rows, {}, tasks, CONFIG, "en").split()
    )
    assert "human grades: 0 answer(s)" in text
    assert "to grade: 4" in text
    assert "automatic checks, not a grade" in text
    assert "exactitude" not in text and "accuracy" not in text


def test_grades_need_a_signature(lab, tmp_path, frozen, tasks):
    folder, rows, sheet = batch(lab, tmp_path, frozen, tasks)
    fill(sheet, grader="")
    with pytest.raises(ValueError, match="not signed"):
        read_grades(folder / "grading")


def test_invalid_grade_is_refused(lab, tmp_path, frozen, tasks):
    folder, rows, sheet = batch(lab, tmp_path, frozen, tasks)
    fill(sheet, "9")
    with pytest.raises(ValueError, match="bad grade"):
        read_grades(folder / "grading")


def test_incomplete_form_stays_ungraded(
    lab, tmp_path, frozen, tasks
):
    folder, rows, sheet = batch(lab, tmp_path, frozen, tasks)
    with open(sheet, encoding="utf-8", newline="") as f:
        data = list(csv.DictReader(f))
    data[0]["exactitude"] = "2"
    with open(sheet, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0]))
        writer.writeheader()
        writer.writerows(data)
    grades = read_grades(folder / "grading")
    assert grades == {} or len(grades) <= 1


def test_new_sheet_never_touches_grades_already_entered(
    lab, tmp_path, frozen, tasks
):
    folder, rows, sheet = batch(lab, tmp_path, frozen, tasks)
    fill(sheet)
    before = sheet.read_text("utf-8")
    assert (
        new_batch(
            rows, tasks, GRID, folder / "grading", "tuning"
        )
        is None
    )
    full_round(lab, folder, frozen, "final")
    rows = Results(folder / "runs.jsonl").rows
    second = new_batch(
        rows, tasks, GRID, folder / "grading", "final"
    )
    assert second.name == "sheet-2.csv"
    assert sheet.read_text("utf-8") == before
    assert len(read_grades(folder / "grading")) == 8


def test_report_keeps_contrary_results_and_draws_no_winner(
    lab, tmp_path, frozen, tasks
):
    folder = tmp_path / "o"
    full_round(lab, folder, frozen)
    full_round(lab, folder, frozen, "final")
    rows = Results(folder / "runs.jsonl").rows
    by_id = {x.id: x for x in tasks}
    # Whatever the grades, both stay and no verdict appears.
    grades = {
        r["run_id"]: {
            c: 0 if r["architecture"] == "team" else 2
            for c in by_id[r["task"]].criteria
        }
        for r in rows
    }
    text = " ".join(
        report(rows, grades, tasks, CONFIG, "en").split()
    )
    assert text.startswith("SIMULATED")
    assert "exploratory" in text
    assert "no general conclusion" in text
    assert "Tuning tasks: no conclusion" in text
    assert "workflow: 8 runs" in text
    assert "single agent: 8 runs" in text
    assert "single agent higher 8" in text
    assert "accuracy: 0/16" in text
    assert "winner" not in text.lower()
    assert "best" not in text.lower()


@pytest.mark.parametrize("lang", ["fr", "en", "es", "de"])
def test_report_is_localised_and_fits_the_page(
    lang, lab, tmp_path, frozen, tasks
):
    folder = tmp_path / "o"
    full_round(lab, folder, frozen)
    full_round(lab, folder, frozen, "final")
    rows = Results(folder / "runs.jsonl").rows
    text = report(rows, {}, tasks, CONFIG, lang)
    assert max(len(x) for x in text.splitlines()) <= 64
    from assistant.messages import t

    first = t(lang, "rep_exp").split()[0]
    assert first in text
    assert "rep_" not in text


def test_tuning_report_shows_limits_reached(
    lab, tmp_path, frozen, tasks
):
    folder = tmp_path / "o"
    task = task_by_id(tasks, "t1-luggage")
    full_round(
        lab,
        folder,
        frozen,
        overrides={(task.id, "team"): endless},
    )
    rows = Results(folder / "runs.jsonl").rows
    text = " ".join(
        report(rows, {}, tasks, CONFIG, "en").split()
    )
    assert "limits reached: calls_or_tokens 1" in text or (
        "limits reached: calls 1" in text
    )


def test_real_report_has_no_simulation_header(tasks):
    task = tasks[0]
    rows = [
        {
            "source": "real-api",
            "split": task.split,
            "round": 1,
            "task": task.id,
            "model": "m",
            "architecture": "agent",
            "slot": "s",
            "run_id": "s:1",
            "kind": "complete",
            "status": "done",
            "answer": "a",
            "auto": {},
            "calls": 1,
            "tokens": 1,
            "charged_usd": 0.0,
            "seconds": 1.0,
            "objections": [],
            "revisions": 0,
        }
    ]
    text = report(rows, {}, tasks, CONFIG, "en")
    assert "SIMULATED" not in text
    assert "French" in text


# ---- The command ----


def env(monkeypatch, tmp_path, allow="1", key="not-a-key"):
    from assistant import evaluate_cli

    monkeypatch.setattr(evaluate_cli, "RESULTS", tmp_path)
    monkeypatch.setenv("ASSISTANT_LANG", "fr")
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", allow)
    if key:
        monkeypatch.setenv("ANTHROPIC_API_KEY", key)
    else:
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    def refuse():
        raise AssertionError("a real model was built")

    monkeypatch.setattr(evaluate_cli, "real_maker", refuse)


@pytest.mark.parametrize(
    "allow,key,args",
    [
        (
            "0",
            "k",
            ["--split", "tuning", "--max-usd", "1", "--yes"],
        ),
        (
            "1",
            "",
            ["--split", "tuning", "--max-usd", "1", "--yes"],
        ),
        (
            "1",
            "k",
            ["--split", "tuning", "--max-usd", "1", "--yes"],
        ),
        ("1", "k", []),
    ],
)
def test_evaluate_refused_without_every_activation(
    monkeypatch, tmp_path, allow, key, args
):
    from assistant import cli

    env(monkeypatch, tmp_path, allow, key)
    assert cli.main(["evaluate", *args]) == 2
    assert not (tmp_path / "real" / "ch09").exists()


def test_evaluate_asks_for_yes_after_the_blocks(
    monkeypatch, tmp_path, capsys
):
    from assistant import cli

    env(monkeypatch, tmp_path)
    for block in "ABC":
        folder = tmp_path / "real" / block
        folder.mkdir(parents=True)
        (folder / f"block-{block}.json").write_text(
            json.dumps(
                {
                    "source": "real-api",
                    "block": block,
                    "all_passed": True,
                }
            )
        )
    for extra in ([], ["--yes"], ["--max-usd", "1"]):
        args = ["evaluate", "--split", "tuning", *extra]
        assert cli.main(args) == 2
    assert "--max-usd" in capsys.readouterr().out


def test_dry_run_command(monkeypatch, tmp_path, capsys):
    from assistant import cli

    env(monkeypatch, tmp_path, "0", "")
    assert cli.main(["evaluate", "--dry-run"]) == 0
    out = capsys.readouterr().out
    assert out.startswith("SIMULÉ")
    assert not (tmp_path / "real").exists()
    runs = list(Path(tmp_path).glob("dryrun/*/runs.jsonl"))
    assert len(runs) == 1


def test_limits_of_the_config_reach_both_runners(
    lab, tmp_path, frozen
):
    """A change of limits must act on the runs themselves."""
    path = lab / "config.json"
    config = json.loads(path.read_text("utf-8"))
    config["limits"]["max_calls"] = 3
    config["limit_changes"] = [{"justification": "test"}]
    path.write_text(json.dumps(config), "utf-8")
    folder = tmp_path / "o"
    folder.mkdir()
    Results(folder / "runs.jsonl").add(rows_of("tuning"))
    seen = []

    def make(task, arch):
        model = endless()
        model.name = "claude-haiku-5-5"
        seen.append(model)
        return model

    run_round(
        "tuning", make, "simulated", lab, folder, Ledger()
    )
    assert seen
    assert all(len(m.requests) <= 3 for m in seen)


def test_recorded_limit_change_applies_after_tuning():
    from assistant.step09.evaluate import round_limits

    assert RECORDED_CONFIG["limit_changes"]
    check_limits(RECORDED_CONFIG, True)
    # A first tuning round always runs at the initial limits.
    assert (
        round_limits(RECORDED_CONFIG, "tuning", False)
        == RunLimits()
    )
    later = round_limits(RECORDED_CONFIG, "final", True)
    assert (
        later.max_calls
        == RECORDED_CONFIG["limits"]["max_calls"]
    )


def _grading_folder(tmp_path):
    from assistant.step09.grading import CRITERIA

    folder = tmp_path / "grading"
    folder.mkdir()
    row = {
        "answer_id": "a1",
        "question": "Q",
        "key_points": "K",
        "answer": "A",
        **{name: "n/a" for name in CRITERIA},
        "comment": "",
        "grader": "",
    }
    row["exactitude"] = ""
    row["sources"] = ""
    second = {**row, "answer_id": "a2"}
    with open(
        folder / "sheet-1.csv",
        "w",
        encoding="utf-8",
        newline="",
    ) as f:
        writer = csv.DictWriter(f, fieldnames=list(row))
        writer.writeheader()
        writer.writerows([row, second])
    (folder / "key-1.json").write_text(
        json.dumps({"a1": "r1", "a2": "r2"}), "utf-8"
    )
    return folder


def test_guided_grading_saves_each_answer_and_resumes(tmp_path):
    from assistant.step09.grade_session import session
    from assistant.step09.grading import read_grades

    folder = _grading_folder(tmp_path)
    grid = json.loads(
        (EXPERIMENT / "grading-grid.json").read_text("utf-8")
    )
    shown = []
    first = iter(["Une personne", "2", "x", "1", "", "q"])
    done = session(
        folder, grid, lambda _: next(first), shown.append
    )
    assert not done
    assert read_grades(folder) == {
        "r1": {"exactitude": 2, "sources": 1}
    }
    # The origin is never shown to the grader.
    assert not any("r1" in s for s in shown)
    again = iter(["Une personne", "0", "0", ""])
    assert session(
        folder, grid, lambda _: next(again), shown.append
    )
    assert read_grades(folder)["r2"] == {
        "exactitude": 0,
        "sources": 0,
    }


def test_guided_grading_needs_a_name(tmp_path):
    from assistant.step09.grade_session import session

    folder = _grading_folder(tmp_path)
    grid = json.loads(
        (EXPERIMENT / "grading-grid.json").read_text("utf-8")
    )
    answers = iter(["  ", "Une personne", "q"])
    assert not session(
        folder, grid, lambda _: next(answers), lambda _: None
    )


def test_model_grading_is_blind_and_validated(tmp_path):
    from assistant.step09 import model_grading as mg

    grid = json.loads(
        (EXPERIMENT / "grading-grid.json").read_text("utf-8")
    )
    lines = mg.control_lines()[:2]
    model = FakeModel(
        [
            FakeModel.json(
                {
                    "exactitude": 2,
                    "exactitude_reason": "r",
                    "sources": 2,
                    "sources_reason": "r",
                    "contradictions": 2,
                    "contradictions_reason": "r",
                }
            ),
            FakeModel.says("pas du JSON"),
        ]
    )
    out = tmp_path / "pass-1.jsonl"
    graded = mg.run_pass(model, grid, lines, out)
    assert graded[0].marks["contradictions"] == 2
    assert graded[1].error.startswith("invalid")
    assert len(out.read_text("utf-8").splitlines()) == 2
    sent = model.requests[0]["messages"][0]["content"]
    # Blind: nothing about the architecture or the run is sent.
    for word in ("agent", "team", "workflow", "run_id"):
        assert word not in sent
    assert set(model.requests[0]["schema"]["required"]) == {
        "exactitude",
        "exactitude_reason",
        "sources",
        "sources_reason",
        "contradictions",
        "contradictions_reason",
    }


def test_frozen_copy_keeps_the_historical_fingerprint():
    from assistant.step09.frozen_code import (
        HISTORICAL,
        differences,
        historical_fingerprint,
    )

    assert historical_fingerprint() == HISTORICAL
    if not differences():
        assert fingerprint() == HISTORICAL
