from pathlib import Path

import pytest

from assistant.corpus import Corpus

DATA = Path(__file__).resolve().parents[1] / "demo_data"


@pytest.fixture(params=["fr", "de", "en", "es"])
def corpus(request) -> Corpus:
    return Corpus.load(DATA / request.param, request.param)


@pytest.fixture
def corpus_fr() -> Corpus:
    return Corpus.load(DATA / "fr", "fr")


@pytest.fixture(autouse=True)
def no_paid_call(monkeypatch):
    """Safety net: no test may ever reach the real API."""
    monkeypatch.setenv("ASSISTANT_NO_DOTENV", "1")
    # Same language for every reader, whatever their terminal
    # exports: a test that needs another one sets it itself.
    monkeypatch.setenv("ASSISTANT_LANG", "fr")
    import anthropic

    def refuse(*args, **kwargs):
        raise RuntimeError("network call attempted in a test")

    monkeypatch.setattr(
        anthropic.resources.messages.Messages, "create", refuse
    )
