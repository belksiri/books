import pytest

from assistant.llm import ToolCall
from assistant.step04.tools import (
    MAX_RESULT_CHARS,
    build_toolbox,
    simple_search,
)


@pytest.fixture
def box(corpus_fr, tmp_path):
    consulted: dict[str, str] = {}
    notes = tmp_path / "notes"
    return (
        build_toolbox(corpus_fr, notes, consulted),
        consulted,
        notes,
    )


def call(tool, **args):
    return ToolCall("id1", tool, args)


def test_search_marks_passages_as_consulted(box):
    toolbox, consulted, _ = box
    out = toolbox.execute(
        call("search_documents", query="dépôt de garantie")
    )
    assert not out.is_error
    assert "[cr-ag-2026-03#p03]" in out.content
    assert "cr-ag-2026-03#p03" in consulted


def test_unknown_document_is_an_error_for_the_model(box):
    toolbox, consulted, _ = box
    out = toolbox.execute(
        call("read_document", doc_id="tarif-2026")
    )
    assert out.is_error
    assert "list_documents" in out.content
    assert not consulted


@pytest.mark.parametrize(
    "args",
    [
        {"doc_id": "../secret"},
        {"doc_id": "/etc/passwd"},
        {"doc_id": "Statuts"},
        {"doc_id": "statuts", "extra": 1},
        {},
    ],
)
def test_invalid_read_inputs_are_refused(box, args):
    toolbox, _, _ = box
    out = toolbox.execute(ToolCall("id", "read_document", args))
    assert out.is_error
    assert out.content.startswith("Invalid input")


@pytest.mark.parametrize(
    "args",
    [
        {"query": "x"},
        {"query": "caution", "max_results": 50},
        {"query": "caution", "max_results": "5"},
    ],
)
def test_search_bounds_are_enforced(box, args):
    toolbox, _, _ = box
    out = toolbox.execute(
        ToolCall("id", "search_documents", args)
    )
    assert out.is_error


def test_unknown_tool(box):
    toolbox, _, _ = box
    out = toolbox.execute(call("delete_everything"))
    assert out.is_error and "Unknown tool" in out.content


def test_save_note_writes_only_new_files(box):
    toolbox, _, notes = box
    ok = toolbox.execute(
        call("save_note", name="resume.md", content="Bonjour")
    )
    assert not ok.is_error
    again = toolbox.execute(
        call("save_note", name="resume.md", content="Autre")
    )
    assert again.is_error
    assert (notes / "resume.md").read_text() == "Bonjour"


def test_save_note_cannot_leave_the_workspace(box):
    toolbox, _, _ = box
    out = toolbox.execute(
        call("save_note", name="../../evil.md", content="x")
    )
    assert out.is_error


def test_long_results_are_truncated(box, monkeypatch):
    toolbox, _, _ = box
    tool = toolbox._tools["list_documents"]
    monkeypatch.setattr(
        toolbox,
        "_tools",
        {
            "list_documents": tool.__class__(
                tool.name,
                tool.description,
                tool.schema,
                tool.params,
                lambda _: "x" * 10_000,
            )
        },
    )
    out = toolbox.execute(call("list_documents"))
    assert len(out.content) < MAX_RESULT_CHARS + 20
    assert out.content.endswith("[truncated]")


def test_schema_and_params_agree(box):
    """What the model sees matches what the code enforces."""
    toolbox, _, _ = box
    for tool in toolbox._tools.values():
        schema = tool.schema
        fields = tool.params.model_fields
        assert set(schema["properties"]) == set(fields)
        required = {
            n for n, f in fields.items() if f.is_required()
        }
        assert set(schema.get("required", [])) == required
        assert schema["additionalProperties"] is False


def test_simple_search_ignores_stopwords(corpus_fr):
    hits = simple_search(corpus_fr, "le la les de", 5)
    assert hits == []


def test_simple_search_misses_synonyms(corpus_fr):
    """Lexical search: "caution" never finds "dépôt"."""
    refs = {
        p.ref for p in simple_search(corpus_fr, "caution", 10)
    }
    assert refs == {"faq-adherents#p02"}
