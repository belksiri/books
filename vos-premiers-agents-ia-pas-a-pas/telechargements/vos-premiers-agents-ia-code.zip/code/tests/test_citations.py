from assistant.step05.citations import (
    check_citations,
    excerpt_in,
)


def full(corpus, *refs):
    """Passages received whole by the model."""
    return {r: corpus.passage(r).text for r in refs}


def test_excerpt_exact_and_with_ellipsis():
    text = "Le dépôt reste fixé à 150 € jusqu'à l’avis."
    assert excerpt_in("reste fixé à 150 €", text)
    assert excerpt_in("Le dépôt … jusqu'à l'avis", text)
    assert not excerpt_in("fixé à 200 €", text)
    assert not excerpt_in("jusqu'à … Le dépôt", text)


def test_four_checks_are_separate(corpus_fr):
    answer = (
        "Voir [cr-ag-2026-03#p03] et [statuts#p09].\n"
        "Sources\n"
        "- [cr-ag-2026-03#p03] « reste fixé à 150 € »\n"
        "- [tarifs-2026#p04] « Dépôt de garantie : 150 € »\n"
    )
    consulted = full(
        corpus_fr, "cr-ag-2026-03#p03", "tarifs-2026#p04"
    )
    checks = {
        c.ref: c
        for c in check_citations(answer, corpus_fr, consulted)
    }
    good = checks["cr-ag-2026-03#p03"]
    assert (good.exists, good.consulted, good.excerpt) == (
        True,
        True,
        True,
    )
    ghost = checks["statuts#p09"]
    assert not ghost.exists and not ghost.consulted
    wrong = checks["tarifs-2026#p04"]
    assert wrong.exists and wrong.consulted
    assert wrong.excerpt is False  # quote altered: 150 vs 200
    assert all(c.supported is None for c in checks.values())


def test_cited_but_never_consulted(corpus_fr):
    answer = "- [statuts#p01] « La coopérative Rivelune »"
    [check] = check_citations(answer, corpus_fr, {})
    assert check.exists and check.excerpt
    assert not check.consulted


def test_german_quotes(corpus):
    if corpus.lang != "de":
        return
    answer = "- [securite-velos#p03] „hinteren Gepäckträger“"
    [check] = check_citations(
        answer, corpus, full(corpus, "securite-velos#p03")
    )
    assert check.excerpt
