import pytest

from assistant.approval import (
    ApprovalRequired,
    OutboxSender,
    ProposedAction,
    request_approval,
)


def action(content="Synthèse validée."):
    return ProposedAction(
        "send_summary", "bureau@example.org", content
    )


def test_approved_action_is_written(tmp_path):
    shown = []
    proposed = action()
    approval = request_approval(
        proposed, lambda text: shown.append(text) or True, "Ana"
    )
    path = OutboxSender(tmp_path).send(
        proposed, approval, "envoi-1.md"
    )
    assert "Synthèse validée." in path.read_text()
    assert "Synthèse validée." in shown[0]  # full content shown


def test_refusal_means_nothing_is_written(tmp_path):
    proposed = action()
    approval = request_approval(
        proposed, lambda _: False, "Ana"
    )
    with pytest.raises(ApprovalRequired):
        OutboxSender(tmp_path).send(proposed, approval, "e.md")
    assert not list(tmp_path.iterdir())


def test_change_after_approval_needs_new_approval(tmp_path):
    approval = request_approval(action(), lambda _: True, "Ana")
    edited = action("Synthèse validée. PS : un ajout.")
    with pytest.raises(ApprovalRequired, match="changed"):
        OutboxSender(tmp_path).send(edited, approval, "e.md")


def test_target_change_also_invalidates(tmp_path):
    approval = request_approval(action(), lambda _: True, "Ana")
    moved = ProposedAction(
        "send_summary", "autre@example.org", "Synthèse validée."
    )
    with pytest.raises(ApprovalRequired):
        OutboxSender(tmp_path).send(moved, approval, "e.md")


def test_approval_is_single_use(tmp_path):
    proposed = action()
    approval = request_approval(proposed, lambda _: True, "Ana")
    sender = OutboxSender(tmp_path)
    sender.send(proposed, approval, "e1.md")
    with pytest.raises(ApprovalRequired, match="already"):
        sender.send(proposed, approval, "e2.md")
