"""Step 03: the loop, its stops and its log, without any key."""

from assistant.config import CODE_DIR
from assistant.llm import FakeModel, ModelReply, Usage
from assistant.runstate import Limits, RunState
from assistant.step03.__main__ import main
from assistant.step03.agent import CONTINUE, run
from assistant.step03.document import system_with_document

DOCUMENT = CODE_DIR / "demo_data" / "fr" / "remboursement.md"


# [snippet:first-tests]
def test_final_answer_ends_the_loop():
    model = FakeModel([FakeModel.says("Hello.")])
    result = run(model, "instructions", "Question?")
    assert result.status == "done"
    assert result.answer == "Hello."
    assert result.state.turns == 1
    assert result.state.events == ["turn 1: end_turn"]


def test_turn_limit_stops_an_endless_model():
    endless = [FakeModel.truncated("bla ") for _ in range(9)]
    model = FakeModel(endless)
    result = run(model, "s", "q", Limits(max_turns=3))
    assert result.status == "max_turns"
    assert len(model.requests) == 3  # not one more
    assert result.answer == "bla bla bla "  # partial, and named


# [/snippet]


# [snippet:clock-test]
def test_time_limit_uses_a_clock_we_control():
    ticks = iter([0.0, 0.0, 200.0])  # 200 s after the 1st call
    state = RunState(
        Limits(max_seconds=120), clock=lambda: next(ticks)
    )
    model = FakeModel([FakeModel.truncated("Start")])
    result = run(model, "s", "q", state=state)
    assert result.status == "max_seconds"
    assert state.turns == 1  # the call itself was not cut


# [/snippet]


def test_token_budget_is_checked_between_calls():
    costly = ModelReply(
        "max_tokens", "x", [], Usage(80, 40), []
    )
    model = FakeModel([costly, FakeModel.says("fin")])
    result = run(model, "s", "q", Limits(max_tokens=100))
    assert result.status == "token_budget"
    assert result.state.usage.total == 120  # one call too many
    assert len(model.requests) == 1


def test_truncated_reply_asks_for_the_rest_in_the_history():
    model = FakeModel(
        [
            FakeModel.truncated("Oui, à "),
            FakeModel.says("40 %."),
        ]
    )
    result = run(model, "s", "q")
    assert result.status == "done"
    assert result.answer == "Oui, à 40 %."
    first, second = model.requests
    assert [m["role"] for m in first["messages"]] == ["user"]
    assert [m["role"] for m in second["messages"]] == [
        "user",
        "assistant",
        "user",
    ]
    assert second["messages"][-1]["content"] == CONTINUE
    assert result.state.events == [
        "turn 1: max_tokens",
        "turn 2: end_turn",
    ]


def test_any_other_stop_reason_is_named_not_hidden():
    other = ModelReply("refusal", "", [], Usage(1, 1), [])
    result = run(FakeModel([other]), "s", "q")
    assert result.status == "stopped:refusal"


def test_whole_document_goes_with_every_call():
    system = system_with_document(DOCUMENT)
    assert DOCUMENT.read_text("utf-8") in system
    model = FakeModel(
        [FakeModel.truncated("a"), FakeModel.says("b")]
    )
    run(model, system, "q")
    assert all(r["system"] == system for r in model.requests)


def test_demo_says_it_is_simulated(capsys):
    main()
    out = capsys.readouterr().out
    assert out.startswith("SIMULÉ")
    assert "statut : max_turns" in out
    assert all(len(line) <= 64 for line in out.splitlines())
