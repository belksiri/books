"""The first call, with a scripted model: no key, no network.

These tests check what the program does and displays. They say
nothing about a real reply from the service.
"""

import pytest

from assistant import paid
from assistant.budget import BudgetStop, GuardedModel, Ledger
from assistant.llm import FakeModel, ModelError, Usage
from assistant.step02 import first_call
from assistant.step02.first_call import main, show_reply

HAIKU = "claude-haiku-5-5"
SONNET = "claude-sonnet-5-5"


def scripted(text="Réponse écrite à la main."):
    reply = FakeModel.says(text)
    reply.usage = Usage(1000, 500)
    return reply


def test_show_reply_prints_answer_tokens_and_cost(capsys):
    model = FakeModel([scripted()])
    reply = model.complete("system", [])
    show_reply(reply, HAIKU)
    out = capsys.readouterr().out
    assert "Réponse écrite à la main." in out
    assert "end_turn" in out
    assert "1000/500" in out
    # 1000 x 0.10 / 1M + 500 x 0.50 / 1M
    assert "0.000350 USD" in out


def test_show_reply_uses_the_tier_of_the_request(capsys):
    reply = FakeModel.says("x")
    reply.usage = Usage(200_000, 0)
    show_reply(reply, HAIKU)
    # Above 100 000 input tokens: 0.50 per million.
    assert "0.100000 USD" in capsys.readouterr().out


def test_show_reply_without_a_price_guesses_nothing(capsys):
    reply = FakeModel([scripted()]).complete("system", [])
    show_reply(reply, "fake-model")
    out = capsys.readouterr().out
    assert "USD" not in out
    assert "coût estimé" in out


def test_show_reply_shows_a_truncated_answer(capsys):
    reply = FakeModel.truncated("Début de rép")
    reply.usage = Usage(10, 4096)
    show_reply(reply, HAIKU)
    assert "max_tokens" in capsys.readouterr().out


def test_show_reply_follows_the_language(capsys):
    reply = FakeModel([scripted()]).complete("system", [])
    show_reply(reply, HAIKU, "en")
    assert "estimated cost" in capsys.readouterr().out


def test_refused_while_the_switch_is_off(monkeypatch, capsys):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "0")
    monkeypatch.setenv("AGENT_MODEL", HAIKU)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-key")
    monkeypatch.setenv("ASSISTANT_LANG", "fr")

    def never(*args, **kwargs):
        raise AssertionError("the model must not be built")

    monkeypatch.setattr(paid, "make_anthropic", never)
    assert main(["Une question ?"]) == 1
    assert "ASSISTANT_ALLOW_LIVE=1" in capsys.readouterr().out


def test_goes_through_open_model(monkeypatch, capsys):
    model = FakeModel([scripted()])
    model.name = HAIKU
    seen = []

    def fake_open(settings, mission, max_calls):
        seen.append((mission, max_calls))
        return model

    monkeypatch.setattr(first_call, "open_model", fake_open)
    assert main(["Une question ?"]) == 0
    key = paid.mission_key("first", "Une question ?")
    assert seen == [(key, 1)]
    request = model.requests[0]
    assert request["system"] == first_call.SYSTEM
    assert request["tools"] == []
    assert request["messages"] == [
        {"role": "user", "content": "Une question ?"}
    ]
    assert "0.000350 USD" in capsys.readouterr().out


def test_usage_error_needs_exactly_one_question(capsys):
    assert main([]) == 2
    assert main(["a", "b"]) == 2
    assert "usage" in capsys.readouterr().out


def test_a_failed_call_is_reported(monkeypatch, capsys):
    failure = ModelError("simulated 401", retryable=False)
    model = FakeModel([failure])
    monkeypatch.setattr(
        first_call, "open_model", lambda *args: model
    )
    assert main(["Une question ?"]) == 1
    assert "simulated 401" in capsys.readouterr().out


def default_guard(tmp_path, monkeypatch, name):
    for var in (
        "ASSISTANT_MAX_CALL_USD",
        "ASSISTANT_MAX_USD",
        "ASSISTANT_MAX_DAY_USD",
    ):
        monkeypatch.delenv(var, raising=False)
    model = FakeModel([scripted()])
    model.name = name
    policy = paid.policy_from_env(Ledger(tmp_path / "l.jsonl"))
    return GuardedModel(model, policy.guard("first:x", 1))


def test_default_limit_accepts_haiku(tmp_path, monkeypatch):
    model = default_guard(tmp_path, monkeypatch, HAIKU)
    messages = [{"role": "user", "content": "Bonjour ?"}]
    reply = model.complete(first_call.SYSTEM, messages)
    assert reply.text


def test_default_limit_refuses_sonnet(tmp_path, monkeypatch):
    """4 096 output tokens at 10 $ per million: over 0.01 $."""
    model = default_guard(tmp_path, monkeypatch, SONNET)
    messages = [{"role": "user", "content": "Bonjour ?"}]
    with pytest.raises(BudgetStop, match="limit per call"):
        model.complete(first_call.SYSTEM, messages)
    assert model.model.requests == []
