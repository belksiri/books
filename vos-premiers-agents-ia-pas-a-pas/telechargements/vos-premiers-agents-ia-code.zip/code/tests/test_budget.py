import pytest

from assistant import protocol
from assistant.budget import (
    BudgetStop,
    GuardedModel,
    Ledger,
    SpendGuard,
    input_bound,
)
from assistant.llm import FakeModel, ModelError, Usage
from assistant.pricing import prices, request_cost

HAIKU = "claude-haiku-5-5"
SONNET = "claude-sonnet-5-5"


def scripted(name, n, usage):
    model = FakeModel([FakeModel.says("x") for _ in range(n)])
    for reply in model._replies:
        reply.usage = usage
    model.name = name
    return model


def test_stops_before_a_call_that_could_pass_the_cap():
    usage = Usage(2_000, 1_000)
    fake = scripted(SONNET, 50, usage)
    guard = SpendGuard(cap_usd=0.30, max_calls=100)
    model = GuardedModel(fake, guard)
    calls = 0
    with pytest.raises(BudgetStop):
        while True:
            model.complete(
                "s", [{"role": "user", "content": "q"}]
            )
            calls += 1
    # The refused call never reached the model.
    assert len(fake.requests) == calls == guard.calls
    assert guard.spent_usd <= 0.30
    # And the guard did not stop too early: one more worst case
    # would have passed the cap.
    worst = request_cost(
        SONNET,
        Usage(
            input_bound(
                "s",
                [{"role": "user", "content": "q"}],
                None,
                model.prior_output,
            ),
            fake.max_tokens,
        ),
    )
    assert guard.spent_usd + worst > 0.30


def test_call_cap():
    fake = scripted(HAIKU, 5, Usage(10, 10))
    guard = SpendGuard(cap_usd=10, max_calls=2)
    model = GuardedModel(fake, guard)
    model.complete("s", [])
    model.complete("s", [])
    with pytest.raises(BudgetStop, match="call cap"):
        model.complete("s", [])
    assert len(fake.requests) == 2


def test_earlier_output_counts_in_the_next_input_bound():
    """Hidden thinking stays in context: count it."""
    fake = scripted(HAIKU, 2, Usage(100, 3_000))
    model = GuardedModel(fake, SpendGuard(10, 10))
    before = input_bound("s", [], None, model.prior_output)
    model.complete("s", [])
    after = input_bound("s", [], None, model.prior_output)
    assert after - before == 3_000


def test_input_limit_per_call():
    big = [{"role": "user", "content": "x" * 40_000}]
    guard = SpendGuard(10, 10, max_input_tokens=30_000)
    model = GuardedModel(scripted(HAIKU, 1, Usage(1, 1)), guard)
    with pytest.raises(BudgetStop, match="input tokens"):
        model.complete("s", big)


def test_broken_bound_stops_everything():
    # A reply billed far above any worst case.
    fake = scripted(SONNET, 1, Usage(10_000_000, 1))
    model = GuardedModel(fake, SpendGuard(1_000, 10))
    with pytest.raises(BudgetStop, match="bound broken"):
        model.complete("s", [])


def test_haiku_long_prompt_tier():
    assert prices(HAIKU, 100_000) == (0.10, 0.50)
    assert prices(HAIKU, 100_001) == (0.50, 2.50)


def test_failed_attempt_is_counted_at_worst_case():
    class Failing:
        name, max_tokens = SONNET, 4096

        def complete(self, *args):
            raise ModelError("timeout", retryable=True)

    ledger = Ledger()
    guard = SpendGuard(cap_usd=1.0, max_calls=5, ledger=ledger)
    model = GuardedModel(Failing(), guard)
    for _ in range(2):  # a manual retry is a second attempt
        with pytest.raises(ModelError):
            model.complete("s", [])
    assert ledger.attempts == 2 and guard.calls == 2
    assert all(
        r["status"].startswith("failed") for r in ledger.records
    )
    assert ledger.charged_usd == pytest.approx(
        sum(r["worst_usd"] for r in ledger.records)
    )
    assert ledger.charged_usd > 0


def test_ledger_survives_restart(tmp_path):
    path = tmp_path / "ledger.jsonl"
    guard = SpendGuard(1.0, 5, ledger=Ledger(path))
    GuardedModel(
        scripted(HAIKU, 1, Usage(100, 100)), guard
    ).complete("s", [])
    again = Ledger(path)
    assert again.attempts == 1
    assert again.charged_usd == pytest.approx(
        request_cost(HAIKU, Usage(100, 100))
    )


def test_refused_approval_sends_nothing(tmp_path):
    out = protocol.check_approval(
        "texte", tmp_path, lambda _: False
    )
    assert out == {"approved": False}
    assert not tmp_path.exists() or not any(tmp_path.iterdir())
