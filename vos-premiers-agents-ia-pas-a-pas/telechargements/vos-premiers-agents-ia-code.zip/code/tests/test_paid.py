"""Budget protections on every command that can reach the API.

The model is replaced by a script: these tests check the program
and its ledger, not the service nor an invoice.
"""

import json
import re
from pathlib import Path

import pytest

from assistant import cli, paid
from assistant.budget import (
    BudgetStop,
    CapReached,
    GuardedModel,
    Ledger,
    SpendGuard,
)
from assistant.llm import FakeModel, ModelError, Usage
from assistant.step07.retry import RetryingModel
from assistant.step10.budgets import BudgetPolicy

SRC = Path(__file__).parents[1] / "src" / "assistant"
HAIKU = "claude-haiku-5-5"


def priced(replies):
    model = FakeModel(replies)
    model.name = HAIKU
    for reply in model._replies:
        if not isinstance(reply, Exception):
            reply.usage = Usage(1000, 100)
    return model


@pytest.fixture
def api(monkeypatch, tmp_path):
    """All barriers open, the service replaced by a script."""
    monkeypatch.setattr(paid, "REAL_DIR", tmp_path)
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "1")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-key")
    monkeypatch.setenv("AGENT_MODEL", HAIKU)
    monkeypatch.setenv("ASSISTANT_LANG", "fr")
    built = []

    def make(name, **options):
        model = priced([FakeModel.says("Réponse.")])
        built.append(model)
        return model

    monkeypatch.setattr(paid, "make_anthropic", make)
    return tmp_path, built


def ledger_of(folder):
    return Ledger(folder / "ledger.jsonl")


def test_only_one_door_builds_the_real_model():
    """Static check: nothing else can skip the guard."""
    found = []
    for path in SRC.rglob("*.py"):
        if path.name in ("llm_anthropic.py", "paid.py"):
            continue
        if re.search(
            r"\bAnthropicModel\(", path.read_text("utf-8")
        ):
            found.append(path.name)
    assert found == []
    text = (SRC / "paid.py").read_text("utf-8")
    assert "max_retries=0" in text


def test_ask_goes_through_the_ledger(api):
    folder, built = api
    assert cli.main(["ask", "Une question ?"]) == 0
    assert ledger_of(folder).attempts == 1
    assert built


def test_limits_persist_between_two_runs(api, monkeypatch):
    """Starting again gives no new room."""
    folder, built = api
    monkeypatch.setenv("ASSISTANT_MAX_USD", "0.004")
    assert cli.main(["ask", "Même question ?"]) == 0
    spent = ledger_of(folder).charged_usd
    # Same mission, new run: room is what was left, too little.
    monkeypatch.setenv("ASSISTANT_MAX_USD", str(spent + 0.0001))
    assert cli.main(["ask", "Même question ?"]) == 3
    assert ledger_of(folder).attempts == 1


def test_day_limit_covers_other_missions(api, monkeypatch):
    folder, _ = api
    assert cli.main(["ask", "Première ?"]) == 0
    spent = ledger_of(folder).charged_usd
    monkeypatch.setenv(
        "ASSISTANT_MAX_DAY_USD", str(spent + 0.0001)
    )
    assert cli.main(["ask", "Autre mission ?"]) == 3
    assert ledger_of(folder).attempts == 1


def test_per_call_limit(api, monkeypatch):
    folder, _ = api
    monkeypatch.setenv("ASSISTANT_MAX_CALL_USD", "0.0001")
    assert cli.main(["ask", "Question ?"]) == 3
    assert ledger_of(folder).attempts == 0


def test_team_and_synthesis_use_the_same_door(api, monkeypatch):
    folder, built = api
    # Keep the reader's workspace/missions/ untouched.
    from assistant import synthesis_cli

    store = synthesis_cli.MissionStore(folder / "missions")
    monkeypatch.setattr(
        synthesis_cli, "MissionStore", lambda _: store
    )
    code = cli.main(["team", "--question", "Dépôt ?"])
    assert built and code == 4  # the script gives no brief
    assert ledger_of(folder).attempts == 1
    count = len(built)
    code = cli.main(
        [
            "synthesis",
            "--question",
            "Dépôt ?",
            "--plan",
            "fixed",
        ]
    )
    assert len(built) == count + 1
    assert ledger_of(folder).attempts >= 2
    assert code in (0, 3, 4)


@pytest.mark.parametrize(
    "args",
    [
        ["ask", "Q"],
        ["team", "--question", "Q"],
        ["synthesis", "--question", "Q"],
    ],
)
def test_refused_when_off_or_without_price(
    args, api, monkeypatch
):
    folder, built = api
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "0")
    assert cli.main(args) == 2
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "1")
    monkeypatch.setenv("AGENT_MODEL", "claude-unknown")
    assert cli.main(args) in (2, 3)
    assert built == []
    assert ledger_of(folder).attempts == 0


def guard(ledger, cap=1.0, calls=9):
    return SpendGuard(cap, calls, ledger=ledger, phase="m")


def test_retries_are_each_counted_once():
    ledger = Ledger()
    fake = priced(
        [
            ModelError("500", True),
            ModelError("500", True),
            FakeModel.says("ok"),
        ]
    )
    g = guard(ledger)
    model = RetryingModel(
        GuardedModel(fake, g), sleep=lambda _: None
    )
    assert model.complete("s", []).text == "ok"
    assert ledger.attempts == 3 and g.calls == 3
    failed, ok = ledger.records[:2], ledger.records[2]
    assert all(
        r["charged_usd"] == r["worst_usd"] for r in failed
    )
    assert ok["charged_usd"] == ok["cost_usd"] < ok["worst_usd"]
    assert ledger.charged_usd == pytest.approx(
        sum(r["charged_usd"] for r in ledger.records)
    )


def test_two_guards_cannot_be_stacked():
    g = guard(Ledger())
    with pytest.raises(ValueError, match="already guarded"):
        GuardedModel(GuardedModel(priced([]), g), g)


def test_unknown_price_stops_before_the_call():
    fake = FakeModel([FakeModel.says("x")])
    fake.name = "claude-unknown"
    ledger = Ledger()
    with pytest.raises(BudgetStop, match="no price"):
        GuardedModel(fake, guard(ledger)).complete("s", [])
    assert fake.requests == [] and ledger.attempts == 0


def test_interrupted_call_stays_at_its_maximum():
    """Ctrl-C during the call: no usage, cost unknown."""

    class Interrupted:
        name, max_tokens = HAIKU, 4096

        def complete(self, *args):
            raise KeyboardInterrupt

    ledger = Ledger()
    with pytest.raises(KeyboardInterrupt):
        GuardedModel(Interrupted(), guard(ledger)).complete(
            "s", []
        )
    record = ledger.records[0]
    assert record["status"] == "failed: KeyboardInterrupt"
    assert record["charged_usd"] == record["worst_usd"] > 0


def test_killed_program_cannot_escape_the_cap(tmp_path):
    """Killed during the call: only the first line is on disk,
    and it counts at the maximum for the next run."""
    path = tmp_path / "ledger.jsonl"

    class Killed(Exception):
        pass

    g = guard(Ledger(path))
    g.start(HAIKU, 0.005)
    again = Ledger(path)
    assert again.attempts == 1
    assert again.charged_usd == pytest.approx(0.005)
    policy = BudgetPolicy(1.0, 0.005, 1.0, again)
    assert policy.room("m") == 0
    model = GuardedModel(
        priced([FakeModel.says("x")]), policy.guard("m", 5)
    )
    with pytest.raises(CapReached):
        model.complete("s", [])


def test_reply_without_usage_stays_at_its_maximum(tmp_path):
    fake = priced([FakeModel.says("x")])
    fake._replies[0].usage = None

    class NoUsage:
        name, max_tokens = HAIKU, 4096

        def complete(self, *args):
            return fake._replies[0]

    path = tmp_path / "ledger.jsonl"
    with pytest.raises(AttributeError):
        GuardedModel(NoUsage(), guard(Ledger(path))).complete(
            "s", []
        )
    record = Ledger(path).records[0]
    assert record["status"] == "started"
    assert record["charged_usd"] == record["worst_usd"] > 0


def test_settling_is_not_counted_twice(tmp_path):
    path = tmp_path / "ledger.jsonl"
    g = guard(Ledger(path))
    GuardedModel(priced([FakeModel.says("x")]), g).complete(
        "s", []
    )
    lines = [
        json.loads(x) for x in path.read_text().splitlines()
    ]
    assert [x["status"] for x in lines] == ["started", "ok"]
    again = Ledger(path)
    assert again.attempts == 1
    assert again.charged_usd == pytest.approx(
        lines[1]["charged_usd"]
    )


def test_two_programs_see_each_other(tmp_path):
    path = tmp_path / "ledger.jsonl"
    first, second = Ledger(path), Ledger(path)
    g = guard(second, cap=0.005)
    GuardedModel(
        priced([FakeModel.says("x")]), guard(first)
    ).complete("s", [])
    assert g.spent_usd == pytest.approx(first.charged_usd)


def test_corrupt_ledger_stops_instead_of_counting_zero(
    tmp_path,
):
    path = tmp_path / "ledger.jsonl"
    path.write_text("not json\n")
    with pytest.raises(json.JSONDecodeError):
        Ledger(path)


def test_mission_prefix_groups_the_cases_of_a_block():
    ledger = Ledger()
    ledger.add(
        {"phase": "A:plain", "charged_usd": 0.1, "status": "ok"}
    )
    ledger.add(
        {"phase": "A:tools", "charged_usd": 0.1, "status": "ok"}
    )
    ledger.add(
        {"phase": "AB", "charged_usd": 0.5, "status": "ok"}
    )
    policy = BudgetPolicy(1.0, 1.0, 5.0, ledger)
    assert policy.spent_on("A") == pytest.approx(0.2)
