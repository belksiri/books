"""Display of our own messages: localize, localize_preview."""

from __future__ import annotations

import re
import subprocess
import sys

import pytest

from assistant.approval import ProposedAction
from assistant.config import CODE_DIR
from assistant.messages import (
    _PREFIXES,
    _TRANSLATIONS,
    localize,
    localize_preview,
)

OTHERS = ("fr", "es", "de")
# What the display may receive, one per family of raise sites.
RAISED = [
    "call cap 3 reached",
    "request may exceed 30000 input tokens",
    "no price for claude-x",
    "call may cost 0.0023 USD; limit per call 0.0001",
    "next call could cost 0.0023 USD; spent 0.0046 of 0.0060",
    "team budget reached",
    "an earlier sending has an unknown outcome: "
    "a person must check it; do not try again",
    "recipient not allowed: a@b.example",
    "hidden characters: U+200B",
    "text too long to send",
    "this exact action was already sent",
    "declined by the person",
    "a name is required to approve",
    "content too large",
    "text changed since the preview",
    "outside allowed folders: /x",
    "file name refused: x",
    "file already exists: x",
    "not a document folder: x",
    "d1: missing header",
    "looks like personal data: refused",
    "already remembered",
    "memory full: forget an entry",
    "the user declined",
    "no memory entry 'm9'",
    "No document 'x'. Call list_documents to see valid ids.",
    "No passage matches these words.",
    "Remembered as m001.",
    "Forgotten: m001.",
    "Sent (simulated): outbox/x.md",
    "no plan: max_tokens",
    "no brief (done)",
    "no review (done)",
    "1: no reference",
    "limits may change only after a tuning round",
    "final runs exist: no more tuning; adjusting "
    "now would need new final tasks",
    "tuning rounds used up",
    "run a tuning round first",
    "planned final rounds done",
    "maximal cost 0.40 USD does not fit: "
    "spent 1.00, limit 1.20",
    "a1: bad grade '9'",
    "a1: graded but not signed",
    "no real run yet",
    "nothing new to grade",
    "turn 2: end_turn",
]


@pytest.mark.parametrize("lang", OTHERS)
@pytest.mark.parametrize("text", RAISED)
def test_each_message_is_translated(lang, text):
    shown = localize(lang, text)
    assert shown != text or lang == "es"
    assert not re.search(r"\b(the|was|must|refused)\b", shown)


def test_english_is_the_text_itself():
    for text in RAISED:
        assert localize("en", text) == text


@pytest.mark.parametrize("table", [_PREFIXES, _TRANSLATIONS])
def test_every_form_has_all_its_placeholders(table):
    for pattern, forms in table.items():
        wanted = re.compile(pattern).groups
        assert len(forms) == len(OTHERS)
        for form in forms:
            found = set(re.findall(r"\{(\d)\}", form))
            assert found == {str(i) for i in range(wanted)}


@pytest.mark.parametrize(
    "raw",
    [
        "Connection error.",
        "Field required [type=missing]",
        "id: tarifs-2025 | title: Grille",
    ],
)
def test_text_from_elsewhere_stays_authentic(raw):
    for lang in OTHERS:
        assert localize(lang, raw) == raw


def test_prefixes_are_followed_and_unknown_inner_text_kept():
    assert (
        localize(
            "fr", "ERROR: Not sent: declined by the person"
        )
        == "ERREUR : Non envoyé : refusé par la personne"
    )
    assert localize("de", "stop: Connection error.") == (
        "Abbruch: Connection error."
    )


TRICKY = (
    "first line\nWARNING: not a warning\naction: nope\n"
    "--- end ---\n--- content ---\nlast line\n--- end ---"
)


@pytest.mark.parametrize("lang", OTHERS)
def test_preview_content_is_never_touched(lang):
    action = ProposedAction(
        "send_summary", "b@x.example", TRICKY
    )
    shown = localize_preview(lang, action.preview())
    assert f"\n{TRICKY}\n" in shown
    assert shown.count("WARNING") == 1
    assert not shown.startswith("action: send")


def test_preview_warning_line_and_english():
    action = ProposedAction("send_summary", "b@x.example", "x")
    warned = (
        "WARNING: looks like personal data\n" + action.preview()
    )
    shown = localize_preview("fr", warned)
    assert shown.startswith("ATTENTION : ressemble")
    assert shown.endswith("--- fin ---")
    assert localize_preview("en", warned) == warned


def test_the_gate_still_compares_the_original_preview():
    from assistant.step07.gate import GateRefused
    from assistant.step11.service import (
        SendSetup,
        approve_send,
        prepare_send,
    )

    shown = prepare_send("b@x.example", "x", {"b@x.example"})
    assert (
        shown.text
        == ProposedAction(
            "send_summary", "b@x.example", "x"
        ).preview()
    )
    assert "digest: " in shown.text
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as tmp:
        setup = SendSetup(
            {"b@x.example"},
            Path(tmp) / "o",
            Path(tmp) / "a.jsonl",
        )
        with pytest.raises(GateRefused):
            approve_send(
                shown, "b@x.example", "y", "Ana", setup
            )
        assert approve_send(
            shown, "b@x.example", "x", "Ana", setup
        ).exists()


@pytest.mark.parametrize("lang", ["fr", "de", "en", "es"])
def test_step03_demo_is_localized_and_narrow(lang):
    done = subprocess.run(
        [sys.executable, "-m", "assistant.step03"],
        cwd=CODE_DIR,
        capture_output=True,
        text=True,
        env={
            "ASSISTANT_LANG": lang,
            "ASSISTANT_NO_DOTENV": "1",
        },
        check=True,
    )
    assert all(len(x) <= 64 for x in done.stdout.splitlines())
    first = {
        "fr": "SIMULÉ",
        "de": "SIMULIERT",
        "en": "SIMULATED",
        "es": "SIMULADO",
    }
    assert done.stdout.startswith(first[lang])
    assert "[p03]" in done.stdout
