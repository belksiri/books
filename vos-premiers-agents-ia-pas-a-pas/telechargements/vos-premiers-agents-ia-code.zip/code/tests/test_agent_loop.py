from assistant.llm import FakeModel
from assistant.runstate import Limits
from assistant.scenarios import deposit_scenario
from assistant.step03 import agent as step03
from assistant.step04.agent import ToolRunState, new_state, run
from assistant.step04.tools import build_toolbox
from assistant.step05.citations import check_citations


def make(corpus, tmp_path, limits=None):
    state = new_state(limits)
    box = build_toolbox(corpus, tmp_path, state.consulted)
    return state, box


def test_deposit_scenario_end_to_end(corpus, tmp_path):
    model = deposit_scenario(corpus.lang)
    state, box = make(corpus, tmp_path)
    result = run(model, "system", "question", box, state)
    assert result.status == "done"
    assert state.turns == 5 and state.tool_calls == 5
    assert any("ERROR" in e for e in state.events)
    checks = check_citations(
        result.answer, corpus, state.consulted
    )
    assert [c.ref for c in checks] == [
        "cr-ag-2026-03#p03",
        "tarifs-2026#p04",
    ]
    for c in checks:
        assert c.exists and c.consulted and c.excerpt
        assert c.supported is None  # needs judgment


def test_tool_results_return_in_one_message(corpus, tmp_path):
    model = deposit_scenario(corpus.lang)
    state, box = make(corpus, tmp_path)
    run(model, "s", "q", box, state)
    second_turn = model.requests[2]["messages"]
    last = second_turn[-1]
    assert last["role"] == "user"
    assert [b["type"] for b in last["content"]] == [
        "tool_result",
        "tool_result",
    ]


def test_error_result_is_flagged(corpus, tmp_path):
    model = deposit_scenario(corpus.lang)
    state, box = make(corpus, tmp_path)
    run(model, "s", "q", box, state)
    blocks = model.requests[3]["messages"][-1]["content"]
    assert blocks[0]["is_error"] is True


def test_turn_limit_stops_a_looping_model(corpus, tmp_path):
    looping = FakeModel(
        [
            FakeModel.calls(("list_documents", {}))
            for _ in range(20)
        ]
    )
    state, box = make(corpus, tmp_path, Limits(max_turns=3))
    result = run(looping, "s", "q", box, state)
    assert result.status == "max_turns"
    assert state.turns == 3


def test_time_limit(corpus, tmp_path):
    ticks = iter([0.0, 0.0, 200.0, 200.0])
    state = ToolRunState(
        Limits(max_seconds=120), clock=lambda: next(ticks)
    )
    box = build_toolbox(corpus, tmp_path, state.consulted)
    model = FakeModel(
        [
            FakeModel.calls(("list_documents", {})),
            FakeModel.says("fin"),
        ]
    )
    result = run(model, "s", "q", box, state)
    assert result.status == "max_seconds"


def test_token_budget(corpus, tmp_path):
    model = FakeModel(
        [
            FakeModel.calls(("list_documents", {})),
            FakeModel.says("fin"),
        ]
    )
    state, box = make(corpus, tmp_path, Limits(max_tokens=10))
    result = run(model, "s", "q", box, state)
    assert result.status == "token_budget"


def test_truncated_answer_is_not_reported_done(
    corpus, tmp_path
):
    model = FakeModel([FakeModel.truncated("Le dépôt est de")])
    state, box = make(corpus, tmp_path)
    result = run(model, "s", "q", box, state)
    assert result.status == "stopped:max_tokens"


def test_step03_still_works():
    model = FakeModel(
        [
            FakeModel.truncated("Bonjour, "),
            FakeModel.says("voici la suite."),
        ]
    )
    result = step03.run(model, "s", "q")
    assert result.status == "done"
    assert result.answer == "Bonjour, voici la suite."
    assert model.requests[1]["messages"][-1]["content"] == (
        step03.CONTINUE
    )


def test_tool_call_limit_checked_before_each_tool(
    corpus, tmp_path
):
    model = FakeModel(
        [
            FakeModel.calls(
                ("list_documents", {}),
                ("list_documents", {}),
                ("list_documents", {}),
            ),
            FakeModel.says("fin"),
        ]
    )
    state, box = make(
        corpus, tmp_path, Limits(max_tool_calls=2)
    )
    result = run(model, "s", "q", box, state)
    assert result.status == "max_tool_calls"
    assert state.tool_calls == 2  # the third never ran
    assert len(model.requests) == 1  # no further model call


def test_time_limit_checked_before_tools(corpus, tmp_path):
    # start, loop head, then the model call "took" 500 s
    ticks = iter([0.0, 0.0, 500.0, 500.0])
    state = ToolRunState(
        Limits(max_seconds=120), clock=lambda: next(ticks)
    )
    box = build_toolbox(corpus, tmp_path, state.consulted)
    model = FakeModel([FakeModel.calls(("list_documents", {}))])
    result = run(model, "s", "q", box, state)
    assert result.status == "max_seconds"
    assert state.tool_calls == 0
    # The model call itself was NOT interrupted: it completed.
    assert state.turns == 1


def test_token_budget_can_be_overshot_by_one_call(
    corpus, tmp_path
):
    """The budget is checked between calls: the call that
    crosses it still runs to the end."""
    model = FakeModel(
        [
            FakeModel.calls(("list_documents", {})),
            FakeModel.says("fin"),
        ]
    )
    state, box = make(corpus, tmp_path, Limits(max_tokens=10))
    run(model, "s", "q", box, state)
    assert state.usage.total > 10
    assert state.turns == 1
