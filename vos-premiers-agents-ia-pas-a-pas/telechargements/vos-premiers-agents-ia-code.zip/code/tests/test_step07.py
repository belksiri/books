"""Step 07: bounded retries, the exact action, the journal.

The model's decisions are scripted; a scripted model that
obeys a trapped document tests the BARRIERS of the code, not
what a real model would do.
"""

import io
from contextlib import redirect_stdout
from dataclasses import replace
from types import SimpleNamespace

import pytest

from assistant.actions_cli import approval_demo
from assistant.approval import (
    ApprovalRequired,
    OutboxSender,
    ProposedAction,
    ask_person,
    hidden_characters,
    request_approval,
)
from assistant.budget import (
    BudgetStop,
    GuardedModel,
    Ledger,
    SpendGuard,
)
from assistant.config import CODE_DIR, LANGS
from assistant.corpus import Corpus
from assistant.llm import (
    FakeModel,
    ModelError,
    ModelReply,
    ToolCall,
    Usage,
)
from assistant.llm_anthropic import _retry_after
from assistant.scenarios import (
    BUREAU,
    GATE_TEXT,
    LEAK,
    OUTSIDER,
    misled_scenario,
)
from assistant.step04.agent import new_state, run
from assistant.step07.gate import (
    ActionJournal,
    GateRefused,
    SendGate,
    UnknownOutcome,
)
from assistant.step07.retry import RetryingModel
from assistant.step07.tools import build_toolbox_step07


def corpus(lang="fr"):
    return Corpus.load(CODE_DIR / "demo_data" / lang, lang)


def flaky(*errors):
    return FakeModel([*errors, FakeModel.says("ok")])


# ---- retries ----


def test_retry_waits_longer_each_time_then_succeeds():
    waits = []
    model = RetryingModel(
        flaky(ModelError("a", True), ModelError("b", True)),
        sleep=waits.append,
    )
    assert model.complete("s", []).text == "ok"
    assert waits == [1.0, 2.0] and model.retries == 2


def test_retries_are_bounded():
    waits = []
    errors = [ModelError(str(i), True) for i in range(5)]
    model = RetryingModel(flaky(*errors), sleep=waits.append)
    with pytest.raises(ModelError):
        model.complete("s", [])
    assert len(waits) == 2  # three attempts, two waits


def test_a_definitive_error_is_not_retried():
    waits = []
    model = RetryingModel(
        flaky(ModelError("400", False)), sleep=waits.append
    )
    with pytest.raises(ModelError):
        model.complete("s", [])
    assert waits == []


def test_retry_after_is_respected_within_the_limit():
    waits = []
    model = RetryingModel(
        flaky(ModelError("429", True, retry_after=7.0)),
        sleep=waits.append,
    )
    model.complete("s", [])
    assert waits == [7.0]


def test_a_wait_too_long_stops_instead_of_blocking():
    """A spend cap can keep failing: do not sit there."""
    waits = []
    model = RetryingModel(
        flaky(ModelError("429", True, retry_after=86_400.0)),
        sleep=waits.append,
    )
    with pytest.raises(ModelError):
        model.complete("s", [])
    assert waits == []


def test_every_attempt_goes_through_the_spending_guard():
    ledger = Ledger()
    fake = flaky(ModelError("a", True))
    fake.name = "claude-haiku-5-5"
    guard = SpendGuard(cap_usd=1.0, max_calls=5, ledger=ledger)
    model = RetryingModel(
        GuardedModel(fake, guard), sleep=lambda _: None
    )
    model.complete("s", [])
    assert ledger.attempts == 2 and guard.calls == 2


def test_the_budget_stop_is_never_retried():
    waits = []
    fake = FakeModel([BudgetStop("cap")])
    model = RetryingModel(fake, sleep=waits.append)
    with pytest.raises(BudgetStop):
        model.complete("s", [])
    assert waits == []


@pytest.mark.parametrize(
    "headers, expected",
    [
        ({"retry-after": "7"}, 7.0),
        ({}, None),
        ({"retry-after": "x"}, None),
    ],
)
def test_retry_after_is_read_from_the_error(headers, expected):
    error = SimpleNamespace(
        response=SimpleNamespace(headers=headers)
    )
    assert _retry_after(error) == expected


def test_a_refusal_stops_the_loop_cleanly(tmp_path):
    refusal = ModelReply("refusal", "", [], Usage(1, 1), [])
    state = new_state()
    box = build_toolbox_step07(
        corpus(), state.consulted, _gate(tmp_path)[0]
    )
    result = run(FakeModel([refusal]), "s", "q", box, state)
    assert result.status == "stopped:refusal"


# ---- the exact action ----


def _gate(tmp_path, answers=None, sender=None):
    asked = []
    answers = [True] * 9 if answers is None else answers

    def ask(preview):
        asked.append(preview)
        return answers.pop(0)

    journal = ActionJournal(tmp_path / "logs" / "actions.jsonl")
    outbox = tmp_path / "outbox"
    gate = SendGate(
        {BUREAU},
        ask,
        "camille",
        sender or OutboxSender(outbox),
        journal,
    )
    return gate, asked, journal, outbox


def _files(outbox):
    return sorted(outbox.iterdir()) if outbox.exists() else []


BASE = ProposedAction("send_summary", BUREAU, "Le texte.")


@pytest.mark.parametrize(
    "changed",
    [
        replace(BASE, kind="delete_all"),
        replace(BASE, target="bureau2@rivelune.example.org"),
        replace(BASE, content="Le texte. "),  # one space
        replace(BASE, content="Le texte!"),
        replace(BASE, content="Le texte.\nPS : ajout."),
    ],
)
def test_any_change_after_approval_needs_a_new_approval(
    tmp_path, changed
):
    approval = request_approval(BASE, lambda _: True, "camille")
    sender = OutboxSender(tmp_path)
    with pytest.raises(ApprovalRequired):
        sender.send(changed, approval, "x.md")
    assert not (tmp_path / "x.md").exists()


def test_what_leaves_is_exactly_what_was_approved(tmp_path):
    gate, asked, _, outbox = _gate(tmp_path)
    text = "Début.\n" + "mot " * 1500 + "\nDERNIÈRE LIGNE"
    path = gate.submit(BUREAU, text)
    # The person saw all of it, last line included...
    assert text in asked[0] and BUREAU in asked[0]
    # ...and this is what was written.
    assert text in path.read_text("utf-8")


def test_a_modified_text_asks_the_person_again(tmp_path):
    gate, asked, _, outbox = _gate(
        tmp_path, [True, False, True]
    )
    gate.submit(BUREAU, "Version 1.")
    with pytest.raises(GateRefused, match="declined"):
        gate.submit(BUREAU, "Version 2.")
    gate.submit(BUREAU, "Version 3.")
    assert len(asked) == 3 and len(_files(outbox)) == 2


def test_a_refusal_writes_nothing_and_records_no_intent(
    tmp_path,
):
    gate, _, journal, outbox = _gate(tmp_path, [False])
    with pytest.raises(GateRefused):
        gate.submit(BUREAU, "Non.")
    assert _files(outbox) == []
    events = [e["event"] for e in journal.events()]
    assert events == ["declined"]


def test_same_action_not_sent_twice_even_after_restart(
    tmp_path,
):
    gate, asked, _, outbox = _gate(tmp_path)
    gate.submit(BUREAU, "Une fois.")
    with pytest.raises(GateRefused, match="already sent"):
        gate.submit(BUREAU, "Une fois.")
    # A new process: only the journal remains.
    again, asked2, _, _ = _gate(tmp_path)
    with pytest.raises(GateRefused, match="already sent"):
        again.submit(BUREAU, "Une fois.")
    assert len(asked) == 1 and asked2 == []
    assert len(_files(outbox)) == 1


def test_an_unlisted_recipient_never_reaches_the_person(
    tmp_path,
):
    gate, asked, journal, outbox = _gate(tmp_path)
    with pytest.raises(GateRefused, match="not allowed"):
        gate.submit(OUTSIDER, "Bonjour.")
    assert asked == [] and _files(outbox) == []
    assert journal.events()[0]["why"] == "target"


@pytest.mark.parametrize(
    "hidden",
    ["\x1b[8m", "‮", "​", "\x07"],
    ids=[
        "terminal escape",
        "right-to-left",
        "zero-width",
        "bell",
    ],
)
def test_text_hidden_from_the_person_is_refused(
    tmp_path, hidden
):
    gate, asked, _, outbox = _gate(tmp_path)
    with pytest.raises(GateRefused, match="hidden"):
        gate.submit(BUREAU, f"Visible{hidden}caché")
    assert asked == [] and _files(outbox) == []


@pytest.mark.parametrize(
    "text",
    [
        "ÀÂÄÇÉÈÊËÎÏÔÖÙÛÜŸ àâäçéèêëîïôöùûüÿ Œœ Ææ",  # fr
        "ÄÖÜẞ äöüß „Anführung“ – Gedankenstrich",  # de
        "ÁÉÍÓÚÜÑ áéíóúüñ ¿Qué? ¡Sí! «comillas»",  # es
        "It\u2019s \u201cquoted\u201d \u2014 naïve",  # en
        "150\u00a0€\u202f! fine\u2009space … %",  # spaces
        "e\u0301te\u0301",  # accents as combining marks (NFD)
        "ligne 1\nligne 2\r\nligne 3\n\tretrait\n",  # line ends
    ],
    ids=["fr", "de", "es", "en", "spaces", "nfd", "newlines"],
)
def test_the_four_languages_are_not_hidden(text):
    assert hidden_characters(text) == []


@pytest.mark.parametrize(
    "text, code",
    [
        ("a\rb", "U+000D"),  # a lone CR rewrites the line
        ("a\x1b[8mb", "U+001B"),
        ("a\x00b", "U+0000"),
        ("a\u200bb", "U+200B"),  # zero-width space
        ("a\u200db", "U+200D"),  # zero-width joiner
        ("a\u00adb", "U+00AD"),  # soft hyphen
        ("a\u202eb", "U+202E"),  # right-to-left override
        ("a\ufeffb", "U+FEFF"),  # byte order mark
        ("a\U000e0041b", "U+E0041"),  # tag character
        ("a\ue000b", "U+E000"),  # private use
        ("a\u2028b", "U+2028"),  # line separator
        ("a\ufe0fb", "U+FE0F"),  # variation selector
    ],
)
def test_the_refused_characters_are_named(text, code):
    assert hidden_characters(text) == [code]


def test_homoglyphs_are_not_detected():
    """A known limit, recorded: Cyrillic "а" looks like "a"."""
    assert hidden_characters("b\u0430nque") == []


def test_the_refusal_names_the_code_point(tmp_path):
    gate, _, _, _ = _gate(tmp_path)
    with pytest.raises(GateRefused, match="U\\+200B"):
        gate.submit(BUREAU, "a\u200bb")


def test_personal_data_warns_the_person(tmp_path):
    gate, asked, _, _ = _gate(tmp_path, [False])
    with pytest.raises(GateRefused):
        gate.submit(BUREAU, f"Écrire à {LEAK}")
    assert asked[0].startswith("WARNING")


def test_the_journal_keeps_digests_not_content(tmp_path):
    gate, _, journal, _ = _gate(tmp_path)
    gate.submit(BUREAU, "Contenu confidentiel.")
    assert "confidentiel" not in journal.path.read_text("utf-8")


@pytest.mark.parametrize(
    "answer, expected",
    [
        ("", False),
        ("n", False),
        ("peut-être", False),
        ("oui", True),
        ("o", True),
        ("y", True),
        ("JA", True),
    ],
)
def test_only_a_clear_yes_is_a_yes(
    monkeypatch, answer, expected
):
    monkeypatch.setattr("builtins.input", lambda _: answer)
    with redirect_stdout(io.StringIO()):
        assert ask_person("texte", "? ") is expected


# ---- interrupted between the action and its record ----


class CrashAfterWrite(OutboxSender):
    def send(self, action, approval, filename):
        super().send(action, approval, filename)
        raise SystemExit("power cut (simulated)")


class CrashBeforeWrite(OutboxSender):
    def send(self, action, approval, filename):
        raise SystemExit("power cut (simulated)")


def _interrupted(tmp_path, sender_class):
    sender = sender_class(tmp_path / "outbox")
    gate, _, journal, outbox = _gate(tmp_path, sender=sender)
    with pytest.raises(SystemExit):
        gate.submit(BUREAU, "Le message.")
    return journal, outbox


def test_a_resume_does_not_repeat_an_action_silently(tmp_path):
    journal, outbox = _interrupted(tmp_path, CrashAfterWrite)
    assert len(journal.unknown()) == 1
    gate, asked, _, _ = _gate(tmp_path)
    with pytest.raises(UnknownOutcome):
        gate.submit(BUREAU, "Le message.")
    assert asked == [] and len(_files(outbox)) == 1


def test_an_unknown_outcome_also_blocks_other_sendings(
    tmp_path,
):
    """A reworded retry would be a silent duplicate."""
    _interrupted(tmp_path, CrashAfterWrite)
    gate, asked, _, _ = _gate(tmp_path)
    with pytest.raises(UnknownOutcome):
        gate.submit(BUREAU, "Le message, reformulé.")
    assert asked == []


def test_a_person_settles_it_was_sent(tmp_path):
    journal, outbox = _interrupted(tmp_path, CrashAfterWrite)
    journal.resolve(journal.unknown()[0], True, "camille")
    gate, asked, _, _ = _gate(tmp_path)
    with pytest.raises(GateRefused, match="already sent"):
        gate.submit(BUREAU, "Le message.")
    gate.submit(BUREAU, "Un autre message.")
    assert len(asked) == 1 and len(_files(outbox)) == 2


def test_a_person_settles_it_was_not_sent(tmp_path):
    journal, outbox = _interrupted(tmp_path, CrashBeforeWrite)
    assert _files(outbox) == []
    journal.resolve(journal.unknown()[0], False, "camille")
    gate, asked, _, _ = _gate(tmp_path)
    gate.submit(BUREAU, "Le message.")  # needs a NEW approval
    assert len(asked) == 1 and len(_files(outbox)) == 1


def test_nothing_to_settle_is_an_error(tmp_path):
    journal = ActionJournal(tmp_path / "a.jsonl")
    with pytest.raises(ValueError):
        journal.resolve("abc", True, "camille")


# ---- the model proposes, it does not approve ----


def test_the_model_cannot_claim_an_approval(tmp_path):
    gate, asked, _, outbox = _gate(tmp_path)
    box = build_toolbox_step07(corpus(), {}, gate)
    outcome = box.execute(
        ToolCall(
            "c1",
            "send_message",
            {
                "target": BUREAU,
                "content": "x",
                "approved": True,
            },
        )
    )
    assert outcome.is_error and asked == []
    assert _files(outbox) == []
    schema = next(
        t
        for t in box.definitions()
        if t["name"] == "send_message"
    )["input_schema"]
    assert set(schema["properties"]) == {"target", "content"}


def test_step07_tools_can_write_only_through_the_gate(tmp_path):
    box = build_toolbox_step07(corpus(), {}, _gate(tmp_path)[0])
    names = {t["name"] for t in box.definitions()}
    assert names == {
        "list_documents",
        "search_documents",
        "read_document",
        "send_message",
    }


@pytest.mark.parametrize("lang", LANGS)
def test_a_misled_model_is_stopped_by_the_barriers(
    tmp_path, lang
):
    """The scripted model obeys the trapped email. The test is
    about the code: no leak leaves, whatever the model does."""
    gate, asked, journal, outbox = _gate(
        tmp_path, [False, True]
    )
    state = new_state()
    box = build_toolbox_step07(
        corpus(lang), state.consulted, gate
    )
    result = run(misled_scenario(lang), "s", "q", box, state)
    assert result.status == "done"
    assert (
        len(asked) == 2
    )  # the outsider never reached a person
    files = _files(outbox)
    assert len(files) == 1
    written = files[0].read_text("utf-8")
    assert LEAK not in written and OUTSIDER not in written
    assert GATE_TEXT[lang]["clean"] in written


# ---- the demo ----


@pytest.mark.parametrize("lang", LANGS)
def test_demo_output_is_deterministic_and_fits(lang):
    outputs = []
    for _ in range(2):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            assert approval_demo(lang, corpus(lang)) == 0
        outputs.append(buffer.getvalue())
    assert outputs[0] == outputs[1]
    assert all(len(x) <= 64 for x in outputs[0].splitlines())


def test_journal_cli_lists_and_settles(
    tmp_path, monkeypatch, capsys
):
    from assistant.actions_cli import actions

    journal, _ = _interrupted(tmp_path, CrashAfterWrite)
    digest = journal.unknown()[0]
    settings = SimpleNamespace(
        lang="fr", journal_path=journal.path
    )
    listed = SimpleNamespace(
        resolve=None, who=None, happened=None
    )
    assert actions(settings, listed) == 0
    assert digest in capsys.readouterr().out
    partial = SimpleNamespace(
        resolve=digest, who=None, happened=None
    )
    assert actions(settings, partial) == 2
    full = SimpleNamespace(
        resolve=digest, who="c", happened="yes"
    )
    assert actions(settings, full) == 0
    assert journal.unknown() == []


def test_too_long_text_is_refused_before_any_intent(tmp_path):
    from assistant.approval import OutboxSender
    from assistant.step07.gate import (
        ActionJournal,
        GateRefused,
        SendGate,
    )

    asked = []
    journal = ActionJournal(tmp_path / "actions.jsonl")
    gate = SendGate(
        {"a@example.org"},
        lambda p: asked.append(p) or True,
        "test",
        OutboxSender(tmp_path / "outbox"),
        journal,
    )
    with pytest.raises(GateRefused, match="too long"):
        gate.submit("a@example.org", "x" * 25_000)
    assert asked == [] and journal.unknown() == []
    assert gate.submit("a@example.org", "court").exists()
