"""Step 08: contracts, roles, orchestrator, shared limits.

Scripted model: the code runs for real, the decisions and the
verdicts are written by hand. No comparison with a single agent
here: that measure belongs to chapter 9.
"""

import io
from contextlib import redirect_stdout

import pytest

from assistant.config import CODE_DIR, LANGS
from assistant.corpus import Corpus
from assistant.llm import (
    FakeModel,
    ModelError,
    ModelReply,
    Usage,
)
from assistant.messages import t
from assistant.scenarios import (
    P03,
    P04,
    TEAM_TEXT,
    team_full_run,
    team_lost_reference,
)
from assistant.step08.contracts import (
    BRIEF_SCHEMA,
    DRAFT_SCHEMA,
    REVIEW_SCHEMA,
    Brief,
    Claim,
    Draft,
    Evidence,
)
from assistant.step08.orchestrator import (
    TeamBudget,
    assemble_answer,
    draft_problems,
    lost_refs,
    run_team,
)
from assistant.step08.roles import (
    RoleFailure,
    evidence_problems,
    research,
    verifier_input,
    verify,
    write,
    writer_input,
)
from assistant.team_cli import team_demo


def corpus(lang="fr"):
    return Corpus.load(CODE_DIR / "demo_data" / lang, lang)


def brief():
    return Brief(
        evidence=[
            Evidence(ref=P03, quote="150 €", note="approuvé"),
            Evidence(
                ref=P04, quote="200 €", note="NOTE-PROJET"
            ),
        ],
        gaps=[],
    )


def team(script, lang="fr", budget=None):
    return run_team(
        script(lang, corpus(lang)),
        "Question ?",
        corpus(lang),
        lang,
        "2026-06-15",
        budget,
    )


# ---- the whole team ----


@pytest.mark.parametrize("lang", LANGS)
def test_full_run_goes_through_the_three_roles(lang):
    result, budget = team(team_full_run, lang)
    # The verifier objects to the third claim: it is visible.
    assert result.status == "done_with_objections"
    assert budget.calls == {
        "researcher": 3,
        "writer": 1,
        "verifier": 2,
    }
    route = [(x.sender, x.receiver) for x in result.log]
    assert route == [
        ("orchestrator", "researcher"),
        ("researcher", "writer"),
        ("writer", "verifier"),
        ("verifier", "orchestrator"),
    ]
    assert [v.supported for v in result.review.verdicts] == [
        True,
        True,
        False,
    ]


@pytest.mark.parametrize("lang", LANGS)
def test_a_lost_reference_stops_before_the_verifier(lang):
    result, budget = team(team_lost_reference, lang)
    assert result.status == "draft_refused"
    assert result.problems == ["2: no reference"]
    assert result.lost_refs == [P04]
    assert "verifier" not in budget.calls  # no call wasted


def test_the_answer_is_assembled_by_the_code():
    result, _ = team(team_full_run)
    lines = assemble_answer(result)
    assert lines[0].endswith(f"[{P03}]")
    assert any(line.startswith(f"[{P04}] ") for line in lines)


# ---- researcher: stops on a brief, or at its limits ----


def _submit(*evidence):
    return FakeModel.calls(
        (
            "submit_brief",
            {"evidence": list(evidence), "gaps": []},
        )
    )


def test_researcher_stops_after_an_accepted_brief():
    c = corpus()
    text = c.passage(P03).text
    model = FakeModel(
        [
            FakeModel.calls(
                ("read_document", {"doc_id": "cr-ag-2026-03"})
            ),
            _submit({"ref": P03, "quote": text, "note": "n"}),
        ]
    )
    found, trace = research(model, "Q", c, "fr", "d")
    assert found.evidence[0].ref == P03 and P03 in trace
    assert model._replies == []  # no extra call after the end


@pytest.mark.parametrize(
    "ref, read, expected",
    [
        ("absent-doc#p01", False, "no such passage"),
        (P03, False, "did not read"),
    ],
)
def test_researcher_hands_over_only_what_it_read(
    ref, read, expected
):
    item = Evidence(ref=ref, quote="x", note="n")
    consulted = {P03: "texte"} if read else {}
    problems = evidence_problems(
        Brief(evidence=[item], gaps=[]), corpus(), consulted
    )
    assert expected in problems[0]


def test_an_invented_quote_is_refused_and_can_be_corrected():
    c = corpus()
    text = c.passage(P03).text
    model = FakeModel(
        [
            FakeModel.calls(
                ("read_document", {"doc_id": "cr-ag-2026-03"})
            ),
            _submit(
                {"ref": P03, "quote": "inventé", "note": "n"}
            ),
            _submit({"ref": P03, "quote": text, "note": "n"}),
        ]
    )
    found, _ = research(model, "Q", c, "fr", "d")
    assert found.evidence[0].quote == text
    feedback = model.requests[2]["messages"][-1]["content"][0]
    assert feedback["is_error"] is True
    assert "quote not in passage" in feedback["content"]


def test_researcher_without_a_brief_fails_clearly():
    model = FakeModel([FakeModel.says("Je ne sais pas.")])
    with pytest.raises(
        RoleFailure, match="researcher: no brief"
    ):
        research(model, "Q", corpus(), "fr", "d")


def test_researcher_tools_change_nothing():
    model = FakeModel([FakeModel.says("x")])
    with pytest.raises(RoleFailure):
        research(model, "Q", corpus(), "fr", "d")
    names = {x["name"] for x in model.requests[0]["tools"]}
    assert names == {
        "list_documents",
        "search_documents",
        "read_document",
        "submit_brief",
    }


# ---- writer: one call, no tools, only the brief ----


def test_writer_sees_only_the_question_and_the_brief():
    model = FakeModel(
        [
            FakeModel.json(
                {"claims": [{"text": "x", "refs": [P03]}]}
            )
        ]
    )
    write(model, "Question ?", brief(), "fr")
    sent = model.requests[0]
    assert (
        sent["tools"] == [] and sent["schema"] == DRAFT_SCHEMA
    )
    assert len(sent["messages"]) == 1  # no shared history
    assert sent["messages"][0]["content"] == writer_input(
        "Question ?", brief()
    )
    passage = corpus().passage(P03).text
    assert passage not in sent["messages"][0]["content"]


@pytest.mark.parametrize(
    "reply",
    [
        FakeModel.says("Pas du JSON."),
        FakeModel.truncated('{"claims": ['),
        ModelReply("refusal", "Non.", [], Usage(1, 1), []),
    ],
)
def test_writer_failure_is_named(reply):
    with pytest.raises(RoleFailure) as error:
        write(FakeModel([reply]), "Q", brief(), "fr")
    assert error.value.role == "writer"


# ---- what passes between writer and verifier ----


def _draft(*claims):
    return Draft(
        claims=[Claim(text=x, refs=list(r)) for x, r in claims]
    )


def test_a_reference_not_in_the_brief_is_refused():
    draft = _draft(("a", ["autre-doc#p01"]))
    assert draft_problems(draft, brief()) == [
        "1: not in brief: autre-doc#p01"
    ]


def test_a_claim_without_a_reference_is_refused():
    assert draft_problems(_draft(("a", [])), brief()) == [
        "1: no reference"
    ]


def test_an_unused_reference_is_reported_not_refused():
    draft = _draft(("a", [P03]))
    assert draft_problems(draft, brief()) == []
    assert lost_refs(draft, brief()) == [P04]


# ---- verifier: its own view of the sources ----


def test_verifier_reads_the_sources_not_the_other_notes():
    text = verifier_input("Q", _draft(("a", [P03])), corpus())
    assert corpus().passage(P03).text in text
    assert "NOTE-PROJET" not in text and "approuvé" not in text


def _verdicts(*numbers):
    return FakeModel.calls(
        (
            "submit_review",
            {
                "verdicts": [
                    {
                        "claim": n,
                        "supported": True,
                        "reason": "r",
                    }
                    for n in numbers
                ]
            },
        )
    )


def test_verifier_must_judge_each_claim_exactly_once():
    draft = _draft(("a", [P03]), ("b", [P03]))
    model = FakeModel(
        [_verdicts(1), _verdicts(1, 1), _verdicts(1, 2)]
    )
    review = verify(model, "Q", draft, corpus(), "fr", "d")
    assert [v.claim for v in review.verdicts] == [1, 2]
    assert len(model.requests) == 3


def test_verifier_without_a_review_fails_clearly():
    model = FakeModel([FakeModel.says("Tout va bien.")])
    with pytest.raises(
        RoleFailure, match="verifier: no review"
    ):
        verify(
            model,
            "Q",
            _draft(("a", [P03])),
            corpus(),
            "fr",
            "d",
        )


# ---- shared limits, failures ----


def test_the_budget_is_shared_between_the_roles():
    result, budget = team(
        team_full_run, budget=TeamBudget(max_calls=4)
    )
    assert result.status == "stopped"
    assert "team budget" in result.problems[0]
    assert (
        sum(budget.calls.values()) == 4
    )  # none beyond the limit


def test_tokens_are_counted_per_role_and_limited():
    result, budget = team(
        team_full_run, budget=TeamBudget(max_tokens=1)
    )
    assert result.status == "stopped"
    assert list(budget.calls) == ["researcher"]


def test_a_network_failure_stops_the_team_cleanly():
    model = FakeModel([ModelError("connection lost", True)])
    result, _ = run_team(model, "Q", corpus(), "fr", "d")
    assert result.status == "stopped"
    assert result.brief is None


def test_a_failed_role_is_named_in_the_status():
    model = FakeModel([FakeModel.says("Rien.")])
    result, _ = run_team(model, "Q", corpus(), "fr", "d")
    assert result.status == "failed:researcher"


# ---- schemas, demo, paid path ----


@pytest.mark.parametrize(
    "schema", [BRIEF_SCHEMA, DRAFT_SCHEMA, REVIEW_SCHEMA]
)
def test_schemas_have_no_refused_bounds(schema):
    text = str(schema)
    for word in (
        "minLength",
        "maxLength",
        "maxItems",
        "minimum",
    ):
        assert word not in text


@pytest.mark.parametrize("lang", LANGS)
def test_demo_output_is_deterministic_and_fits(lang):
    outputs = []
    for _ in range(2):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            assert team_demo(lang, corpus(lang)) == 0
        outputs.append(buffer.getvalue())
    assert outputs[0] == outputs[1]
    assert all(len(x) <= 64 for x in outputs[0].splitlines())
    assert t(lang, "verdicts_demo") in outputs[0]
    assert TEAM_TEXT[lang]["no3"] in outputs[0]


def test_paid_team_is_off_by_default(monkeypatch, capsys):
    from assistant.cli import main

    monkeypatch.delenv("ASSISTANT_ALLOW_LIVE", raising=False)
    assert main(["team", "--question", "Q ?"]) == 2
    assert "ASSISTANT_ALLOW_LIVE=1" in capsys.readouterr().out


def test_nothing_found_is_a_valid_result(corpus_fr):
    """No writer, no verifier: no further call."""
    model = FakeModel(
        [
            FakeModel.calls(
                ("search_documents", {"query": "téléphone"})
            ),
            FakeModel.calls(
                (
                    "submit_brief",
                    {
                        "evidence": [],
                        "gaps": ["Pas de numéro."],
                    },
                )
            ),
        ]
    )
    result, budget = run_team(
        model, "Quel numéro ?", corpus_fr, "fr", "2026-06-15"
    )
    assert result.status == "no_answer"
    assert result.problems == ["Pas de numéro."]
    assert result.draft.claims == []
    assert budget.calls == {"researcher": 2}


def test_writer_may_answer_that_the_brief_is_not_enough(
    corpus_fr,
):
    from assistant.scenarios import _researcher_turns

    model = FakeModel(
        [
            *_researcher_turns("fr", corpus_fr),
            FakeModel.json({"claims": []}),
        ]
    )
    result, budget = run_team(
        model, "Question", corpus_fr, "fr", "2026-06-15"
    )
    assert result.status == "no_answer"
    assert "verifier" not in budget.calls
