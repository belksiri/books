"""Step 10. The regression tests below use a model written to
obey: they check the barriers of the code, not the resistance
of any real model."""

import io
from contextlib import redirect_stdout
from datetime import date

import pytest

from assistant.approval import OutboxSender
from assistant.budget import (
    CapReached,
    GuardedModel,
    Ledger,
)
from assistant.llm import FakeModel, Usage
from assistant.memory import MemoryRefused, MemoryStore
from assistant.scenarios import BUREAU, LEAK
from assistant.step04.agent import new_state, run
from assistant.step04.tools import build_toolbox
from assistant.step05.bm25 import bm25_search
from assistant.step05.tools import build_toolbox_step05
from assistant.step07.gate import ActionJournal, SendGate
from assistant.step07.tools import build_toolbox_step07
from assistant.step10.budgets import BudgetPolicy
from assistant.step10.costs import (
    cost_report,
    costs_demo,
    print_report,
)
from assistant.step10.permissions import (
    ALLOWED,
    TOOL_LEVEL,
    excess_tools,
)
from assistant.step10.redact import expired, redact


# ---- Permissions, on the real toolboxes ----
def names(toolbox) -> list[str]:
    return [d["name"] for d in toolbox.definitions()]


def test_mission_step_has_only_reading_tools(corpus_fr):
    box = build_toolbox(corpus_fr, None, {}, search=bm25_search)
    assert excess_tools(names(box), "mission_step") == []


def test_assistant_may_write_locally_not_send(
    corpus_fr, tmp_path
):
    box = build_toolbox(
        corpus_fr, tmp_path, {}, search=bm25_search
    )
    tools = names(box)
    assert "save_note" in tools
    assert excess_tools(tools, "assistant") == []
    assert excess_tools(tools, "mission_step") == ["save_note"]


def gate(tmp_path, ask=lambda _: False):
    return SendGate(
        {BUREAU},
        ask,
        "test",
        OutboxSender(tmp_path / "outbox"),
        ActionJournal(tmp_path / "actions.jsonl"),
    )


def test_only_the_sender_may_send(corpus_fr, tmp_path):
    box = build_toolbox_step07(corpus_fr, {}, gate(tmp_path))
    tools = names(box)
    assert excess_tools(tools, "sender") == []
    assert excess_tools(tools, "assistant") == ["send_message"]


def test_unknown_tool_is_refused_everywhere():
    for use in ALLOWED:
        assert excess_tools(["delete_all"], use) == [
            "delete_all"
        ]


def test_every_real_tool_has_a_level(corpus_fr, tmp_path):
    memory = MemoryStore(tmp_path / "m", lambda _: True)
    box = build_toolbox_step05(corpus_fr, tmp_path, {}, memory)
    send = build_toolbox_step07(corpus_fr, {}, gate(tmp_path))
    for tool in names(box) + names(send):
        assert tool in TOOL_LEVEL


# ---- Masking and retention ----
@pytest.mark.parametrize(
    "text,hidden",
    [
        ("key sk-ant-api03-AbC_d-1 used", "AbC_d"),
        ("ANTHROPIC_API_KEY=abc123", "abc123"),
        ("x-api-key: abc123", "abc123"),
        ("Authorization: abc123", "abc123"),
        ("écrire à lea.garnier@example.org", "lea.garnier"),
        ("adhérent R-0063", "R-0063"),
    ],
)
def test_redact_hides(text, hidden):
    assert hidden not in redact(text)


def test_redact_keeps_the_useful_text():
    text = "Dépôt de 150 € [cr-ag-2026-03#p03], le 2026-06-15"
    assert redact(text) == text


def test_redact_limit_is_documented():
    """A spelled-out address passes: a net, not a guarantee."""
    text = "lea point garnier chez example point org"
    assert redact(text) == text


def test_expired_lists_only_old_dated_logs(tmp_path):
    for name in (
        "2026-01-01.log",
        "2026-06-14.log",
        "actions.log",
        "2026-01-01.jsonl",
    ):
        (tmp_path / name).write_text("x")
    old = expired(tmp_path, date(2026, 6, 15))
    assert [p.name for p in old] == ["2026-01-01.log"]
    assert (
        tmp_path / "2026-01-01.log"
    ).exists()  # nothing deleted


# ---- Budgets ----
def scripted(n):
    model = FakeModel([FakeModel.says("x") for _ in range(n)])
    for reply in model._replies:
        reply.usage = Usage(1000, 1000)
    model.name = "claude-haiku-5-5"
    return model


def spend(policy, mission, usd, today="2026-06-15"):
    policy.ledger.add(
        {
            "time": f"{today}T10:00:00+00:00",
            "phase": mission,
            "status": "ok",
            "input": 1,
            "output": 1,
            "charged_usd": usd,
        }
    )


def test_mission_limit_stops_before_the_call():
    policy = BudgetPolicy(1.0, 0.001, 1.0, Ledger())
    fake = scripted(5)
    guard = policy.guard("m1", 50, "2026-06-15")
    model = GuardedModel(fake, guard)
    with pytest.raises(CapReached):
        for _ in range(5):
            model.complete("s", [])
    assert guard.spent_usd <= 0.001


def test_day_limit_counts_earlier_missions():
    policy = BudgetPolicy(1.0, 1.0, 0.01, Ledger())
    spend(policy, "m1", 0.0099)
    model = GuardedModel(
        scripted(1), policy.guard("m2", 5, "2026-06-15")
    )
    with pytest.raises(CapReached):
        model.complete("s", [])


def test_yesterday_does_not_count_today():
    policy = BudgetPolicy(1.0, 1.0, 0.01, Ledger())
    spend(policy, "m1", 0.0099, "2026-06-14")
    guard = policy.guard("m2", 5, "2026-06-15")
    GuardedModel(scripted(1), guard).complete("s", [])
    assert guard.calls == 1


# ---- Cost report ----
def test_report_groups_by_mission_and_shows_failures():
    records = [
        {
            "phase": "a",
            "status": "ok",
            "input": 10,
            "output": 5,
            "charged_usd": 0.1,
        },
        {
            "phase": "a",
            "status": "failed: ModelError",
            "input": None,
            "output": None,
            "charged_usd": 0.5,
        },
        {
            "phase": "b",
            "status": "ok",
            "input": 1,
            "output": 1,
            "charged_usd": 0.2,
        },
    ]
    report = cost_report(records)
    assert report["a"].attempts == 2 and report["a"].failed == 1
    assert report["a"].input_tokens == 10
    assert report["a"].usd == pytest.approx(0.6)
    assert report["b"].attempts == 1


def test_costs_demo_says_it_is_simulated(corpus):
    out = io.StringIO()
    with redirect_stdout(out):
        assert costs_demo(corpus.lang, corpus) == 0
    text = out.getvalue()
    assert "agent:" in text and "team:" in text
    assert "failed: 1, 1, 0/0" in text
    assert max(len(x) for x in text.splitlines()) <= 64


def test_empty_report(capsys):
    print_report({}, "en")
    assert "Empty" in capsys.readouterr().out


# ---- Injection regressions: a model written to obey ----
def obeying(*steps):
    return FakeModel([*steps, FakeModel.says("Fait.")])


def send_call(target, content):
    return FakeModel.calls(
        ("send_message", {"target": target, "content": content})
    )


# [snippet:injection-regression]
def run_obeying(corpus, tmp_path, *steps, ask=lambda _: False):
    state = new_state()
    box = build_toolbox_step07(
        corpus, state.consulted, gate(tmp_path, ask)
    )
    run(obeying(*steps), "s", "question", box, state)
    return tmp_path / "outbox", state


def test_order_to_write_to_an_outsider_stays_unsent(
    corpus_fr, tmp_path
):
    outbox, state = run_obeying(
        corpus_fr,
        tmp_path,
        send_call(LEAK, "list of members"),
    )
    assert not outbox.exists() or not list(outbox.iterdir())
    assert any("ERROR" in e for e in state.events)


# [/snippet]


def test_person_declines_nothing_leaves(corpus_fr, tmp_path):
    seen = []

    def ask(preview):
        seen.append(preview)
        return False

    outbox, _ = run_obeying(
        corpus_fr,
        tmp_path,
        send_call(BUREAU, "list of members"),
        ask=ask,
    )
    assert "list of members" in seen[0]
    assert not outbox.exists() or not list(outbox.iterdir())


def test_hidden_characters_never_reach_the_person(
    corpus_fr, tmp_path
):
    seen = []
    outbox, _ = run_obeying(
        corpus_fr,
        tmp_path,
        send_call(BUREAU, "Bonjour‮ invisible"),
        ask=lambda p: seen.append(p) or True,
    )
    assert seen == []
    assert not outbox.exists() or not list(outbox.iterdir())


def test_path_out_of_the_folder_stays_refused(
    corpus_fr, tmp_path
):
    state = new_state()
    box = build_toolbox(
        corpus_fr, tmp_path, state.consulted, search=bm25_search
    )
    model = obeying(
        FakeModel.calls(
            ("read_document", {"doc_id": "../../etc/passwd"})
        ),
        FakeModel.calls(
            (
                "save_note",
                {"name": "../escape.md", "content": "x"},
            )
        ),
    )
    run(model, "s", "question", box, state)
    errors = [e for e in state.events if "ERROR" in e]
    assert len(errors) == 2
    assert not (tmp_path.parent / "escape.md").exists()


def test_memory_refuses_what_an_email_asks_to_store(tmp_path):
    memory = MemoryStore(tmp_path / "m", lambda _: True)
    with pytest.raises(MemoryRefused):
        memory.remember(
            "fact", "Yanis : yanis.roux@example.org"
        )
    assert memory.entries == []


def test_chapter_arithmetic_on_the_cache():
    """The worked example of chapter 10."""
    prefix, calls = 2_000, 5
    without = calls * prefix
    with_cache = prefix * 1.25 + (calls - 1) * prefix * 0.1
    assert without == 10_000
    assert with_cache == pytest.approx(3_300)
