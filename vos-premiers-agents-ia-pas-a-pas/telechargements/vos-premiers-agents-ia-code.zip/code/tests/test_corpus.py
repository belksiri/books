from pathlib import Path

import pytest

from assistant.config import LANGS
from assistant.corpus import Corpus, CorpusError, parse_document
from tests.conftest import DATA


def test_documents_load(corpus):
    assert len(corpus.documents) == 10
    assert corpus.passage("cr-ag-2026-03#p03") is not None


def test_same_passage_ids_in_every_language():
    ids = {}
    for lang in LANGS:
        folder = DATA / lang
        if folder.exists() and any(folder.glob("*.md")):
            corpus = Corpus.load(folder, lang)
            ids[lang] = {p.ref for p in corpus.all_passages()}
    assert set(ids) == set(LANGS)
    for lang, refs in ids.items():
        assert refs == ids["fr"], lang


def test_header_must_match_file_name():
    raw = "---\nid: other\n---\n[p01] Text."
    try:
        parse_document("statuts", raw)
    except CorpusError:
        return
    raise AssertionError("expected CorpusError")


def test_demo_emails_use_reserved_domain(corpus):
    import re

    for passage in corpus.all_passages():
        for mail in re.findall(r"[\w.]+@[\w.]+", passage.text):
            assert mail.endswith("@example.org"), mail


SYNONYMS = {  # FAQ word -> official word, per language
    "fr": ("caution", "faq-adherents#p02"),
    "de": ("Kaution", "faq-adherents#p02"),
    "en": ("bond", "faq-adherents#p02"),
    "es": ("fianza", "faq-adherents#p02"),
}


def test_faq_synonym_trap_exists_in_every_language(corpus):
    """The FAQ word finds only the outdated FAQ (chapter 4)."""
    from assistant.step04.tools import simple_search

    word, ref = SYNONYMS[corpus.lang]
    found = {p.ref for p in simple_search(corpus, word, 10)}
    assert found == {ref}


def test_titles_and_status_translated(corpus):
    for doc in corpus.documents:
        assert doc.title and doc.meta.get("status")
        assert doc.meta["date"][:2] == "20"


def test_no_invisible_spaces_in_source_code():
    """Printed listings must not hide special spaces."""
    from pathlib import Path

    src = Path(__file__).resolve().parents[1] / "src"
    for path in src.rglob("*.py"):
        text = path.read_text("utf-8")
        assert not any(c in text for c in "  ​"), path


@pytest.mark.parametrize("lang", ["fr", "de", "en", "es"])
def test_no_real_looking_contact_data(lang):
    """Simple patterns; see docs/inventaire-rivelune.md."""
    import re

    folder = Path(__file__).parents[1] / "demo_data" / lang
    text = "\n".join(
        path.read_text("utf-8") for path in folder.glob("*.md")
    )
    assert not re.search(r"https?://|www\.", text)
    assert not re.search(
        r"\b[A-Z]{2}\d{2}(?:\s?\d{4}){2,}", text
    )
    assert not re.search(
        r"(?<!\d)(?:\+|0)\d(?:[ .-]?\d){8,}", text
    )
    assert not re.search(
        r"\b\d{3} ?\d{3} ?\d{3}(?: ?\d{5})?\b", text
    )
    domains = set(re.findall(r"@([\w.-]+)", text))
    assert domains <= {"example.org"}
