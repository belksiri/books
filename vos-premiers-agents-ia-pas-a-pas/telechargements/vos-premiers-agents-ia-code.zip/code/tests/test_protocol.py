"""The trial protocol, on scripted models only: these tests
check the program, not a model, a server or a bill."""

import json

import pytest

from assistant import live, protocol
from assistant.budget import Ledger
from assistant.dryrun import make_fake
from assistant.llm import FakeModel
from assistant.protocol import (
    BLOCKS,
    block_allowed,
    block_calls,
    block_max_usd,
    session,
)

RUN = ["run", "--max-usd", "2", "--yes", "--block"]


def maker(corpus, tasks=None, overrides=None):
    def make(name, case, **options):
        if overrides and case in overrides:
            model = overrides[case]
            model.name = name
            return model
        return make_fake(name, case, corpus, tasks, **options)

    return make


def run_block(block, tmp, corpus, ledger=None, ask=None, **kw):
    tasks = kw.pop("tasks", None)
    path = session(
        block,
        maker(corpus, tasks, kw.pop("overrides", None)),
        "simulated",
        ask or (lambda _: True),
        tmp,
        ledger or Ledger(),
        tasks,
        **kw,
    )
    return json.loads(path.read_text("utf-8"))


def case(data, name):
    return next(r for r in data["cases"] if r["case"] == name)


def test_bounds_match_the_published_protocol():
    assert block_calls("A") == 19
    assert block_calls("B") == 7
    assert block_calls("C") == 104
    assert block_calls("D") == 13
    assert block_max_usd("A") == pytest.approx(0.0959, abs=1e-3)
    assert block_max_usd("B") == pytest.approx(0.0353, abs=1e-3)
    assert block_max_usd("C") == pytest.approx(0.525, abs=1e-3)
    assert block_max_usd("D") == pytest.approx(1.31, abs=0.01)


@pytest.mark.parametrize("block", ["A", "B", "C"])
def test_every_block_runs_and_is_labelled(
    block, tmp_path, corpus_fr
):
    data = run_block(block, tmp_path, corpus_fr)
    assert data["source"] == "simulated"
    assert data["all_passed"], data["cases"]
    names = [c.id for c in BLOCKS[block]["cases"]]
    assert [r["case"] for r in data["cases"]] == names
    limits = {c.id: c.max_calls for c in BLOCKS[block]["cases"]}
    for row in data["cases"]:
        assert row["calls"] <= limits[row["case"]]
    assert data["spend"]["attempts_this_block"] <= block_calls(
        block
    )


def test_block_a_stops_at_the_first_failure(
    tmp_path, corpus_fr
):
    bad = FakeModel([FakeModel.says("not a plan")])
    data = run_block(
        "A", tmp_path, corpus_fr, overrides={"plan": bad}
    )
    assert case(data, "plan")["pass"] is False
    for later in ("review", "send"):
        assert "skipped_because" in case(data, later)
    assert data["stopped"] == "failure in plan"
    assert data["all_passed"] is False


def test_block_b_reports_an_unexpected_success(
    tmp_path, corpus_fr
):
    """If the server accepts what the docs say it refuses, the
    result says so; nothing is rewritten to look as expected."""
    ok = FakeModel([FakeModel.json({"a": "abc"})])
    data = run_block(
        "B", tmp_path, corpus_fr, overrides={"schema": ok}
    )
    row = case(data, "schema")
    assert row["pass"] is False
    assert row["observed"] == {"stop_reason": "end_turn"}
    assert case(data, "cut")["pass"] is True  # B continues


def test_bad_key_is_not_retried(tmp_path, corpus_fr):
    data = run_block("B", tmp_path, corpus_fr)
    assert case(data, "bad_key")["attempts"] == 1


def test_failed_attempt_is_charged(tmp_path, corpus_fr):
    ledger = Ledger()
    run_block("B", tmp_path, corpus_fr, ledger=ledger)
    failed = [
        r
        for r in ledger.records
        if r["status"].startswith("failed")
    ]
    assert len(failed) == 3
    assert all(
        r["charged_usd"] == r["worst_usd"] for r in failed
    )


def test_case_limit_is_enforced(tmp_path, corpus_fr):
    endless = FakeModel(
        [
            FakeModel.calls(
                ("search_documents", {"query": "vélo"})
            )
            for _ in range(30)
        ]
    )
    data = run_block(
        "C", tmp_path, corpus_fr, overrides={"team": endless}
    )
    row = case(data, "team")
    assert row["pass"] is False
    assert row["calls"] <= protocol.TEAM_CALLS
    assert data["stopped"] is None  # only the cap stops a block


def test_cap_stops_the_remaining_cases(tmp_path, corpus_fr):
    data = run_block("C", tmp_path, corpus_fr, cap_usd=0.004)
    assert data["stopped"].startswith("cap reached")
    assert any("skipped_because" in r for r in data["cases"])
    assert data["spend"]["charged_all_usd"] <= 0.004


def test_cap_is_cumulative_across_blocks(tmp_path, corpus_fr):
    path = tmp_path / "ledger.jsonl"
    first = run_block("A", tmp_path, corpus_fr, Ledger(path))
    second = run_block("B", tmp_path, corpus_fr, Ledger(path))
    assert (
        second["spend"]["charged_all_usd"]
        > first["spend"]["charged_all_usd"]
    )


def test_injection_fails_if_the_model_tries_to_send(
    tmp_path, corpus_fr
):
    from assistant.scenarios import LEAK

    obeying = FakeModel(
        [
            FakeModel.calls(
                (
                    "send_message",
                    {"target": LEAK, "content": "liste"},
                )
            ),
            FakeModel.says("Fait."),
        ]
    )
    data = run_block(
        "C",
        tmp_path,
        corpus_fr,
        overrides={"send_injection": obeying},
    )
    row = case(data, "send_injection")
    assert row["local_files"] == []
    assert row["person_asked"] == 0  # stopped by the list


def test_order_of_blocks(tmp_path, corpus_fr):
    real = tmp_path / "real"
    assert block_allowed("A", real)[0]
    for block in ("B", "C", "D"):
        assert not block_allowed(block, real)[0]

    def write(block, source="real-api", passed=True):
        folder = real / f"{block}-{source}"
        folder.mkdir(parents=True)
        (folder / f"block-{block}.json").write_text(
            json.dumps(
                {
                    "source": source,
                    "block": block,
                    "all_passed": passed,
                }
            )
        )

    write("A", "simulated")  # a simulated run unlocks nothing
    assert not block_allowed("B", real)[0]
    write("A", passed=False)
    assert not block_allowed("B", real)[0]
    assert not block_allowed("A", real)[0]  # no silent repeat
    assert block_allowed("A", real, again=True)[0]


def real_env(monkeypatch, tmp_path, allow="1", key="not-a-key"):
    monkeypatch.setattr(live, "RESULTS", tmp_path)
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", allow)
    if key:
        monkeypatch.setenv("ANTHROPIC_API_KEY", key)
    else:
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)


def forbid_real(monkeypatch):
    def refuse(*args, **kwargs):
        raise AssertionError("a real model was built")

    monkeypatch.setattr(live, "make_real", refuse)


@pytest.mark.parametrize(
    "allow,key,args",
    [
        (
            "0",
            "not-a-key",
            ["--block", "A", "--max-usd", "1", "--yes"],
        ),
        ("1", "", ["--block", "A", "--max-usd", "1", "--yes"]),
        ("1", "not-a-key", ["--block", "A", "--max-usd", "1"]),
        ("1", "not-a-key", ["--block", "A", "--yes"]),
        ("1", "not-a-key", ["--max-usd", "1", "--yes"]),
        (
            "1",
            "not-a-key",
            ["--block", "B", "--max-usd", "1", "--yes"],
        ),
    ],
)
def test_paid_run_refused_without_every_activation(
    monkeypatch, tmp_path, allow, key, args
):
    real_env(monkeypatch, tmp_path, allow, key)
    forbid_real(monkeypatch)
    assert live.main(["run", *args]) == 2
    assert not (tmp_path / "real" / "ledger.jsonl").exists()


def test_paid_runs_are_off_by_default(monkeypatch):
    monkeypatch.delenv("ASSISTANT_ALLOW_LIVE", raising=False)
    from assistant.config import load_settings

    assert load_settings().allow_live is False


def test_dryrun_needs_no_key_and_touches_no_real_ledger(
    monkeypatch, tmp_path, capsys
):
    real_env(monkeypatch, tmp_path, "0", "")
    forbid_real(monkeypatch)
    assert live.main(["dryrun", "--block", "B"]) == 0
    assert "simulated" in capsys.readouterr().out
    assert not (tmp_path / "real").exists()
    assert list((tmp_path / "dryrun").glob("*/block-B.json"))


def test_real_factory_disables_sdk_retries(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-key")
    model = live.make_real("claude-haiku-5-5", "plain")
    assert model._client.max_retries == 0
    assert model.max_tokens == protocol.MAX_TOKENS
    assert model.effort == protocol.EFFORT


def test_activated_run_goes_through_guard_and_ledger(
    monkeypatch, tmp_path, corpus_fr
):
    """All barriers open, the API replaced by a script: the
    conftest net would refuse any real network call."""
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    monkeypatch.setattr(live, "_ask", lambda _: True)
    assert live.main(RUN + ["A"]) == 0
    ledger = Ledger(tmp_path / "real" / "ledger.jsonl")
    assert ledger.attempts > 0
    assert live.main(RUN + ["A"]) == 2
    assert live.main(RUN + ["B"]) == 0


def test_block_d_refused_when_nothing_failed(
    monkeypatch, tmp_path, corpus_fr
):
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    monkeypatch.setattr(live, "_ask", lambda _: True)
    for block in "ABC":
        assert live.main(RUN + [block]) == 0
    assert live.main(RUN + ["D"]) == 2


def test_max_usd_is_the_limit_actually_applied(
    monkeypatch, tmp_path, corpus_fr
):
    """A limit below the first call stops before any attempt;
    2.00 USD alone authorizes nothing."""
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    monkeypatch.setattr(live, "_ask", lambda _: True)
    args = [
        "run",
        "--block",
        "A",
        "--max-usd",
        "0.0001",
        "--yes",
    ]
    assert live.main(args) == 0
    ledger = Ledger(tmp_path / "real" / "ledger.jsonl")
    assert ledger.attempts == 0
    data = json.loads(
        next(
            (tmp_path / "real").glob("*/block-A.json")
        ).read_text()
    )
    assert data["all_passed"] is False
    assert data["stopped"].startswith("cap reached")


def test_preflight_separates_estimate_and_limit(
    monkeypatch, tmp_path, capsys
):
    real_env(monkeypatch, tmp_path, "0", "")
    forbid_real(monkeypatch)
    assert live.main(["preflight", "--block", "A"]) == 0
    out = capsys.readouterr().out
    assert "claude-haiku-5-5" in out and "2026-11-05" in out
    assert "at most 19" in out
    assert "ESTIMATE" in out and "LIMITS APPLIED" in out
    assert "NOT COVERED" in out
    assert not (tmp_path / "real").exists()


def test_correspondence_names_real_cases():
    """docs/correspondance-ch10-protocole.md stays in sync."""
    import re
    from pathlib import Path

    doc = Path(__file__).parents[2] / "docs"
    table = doc / "correspondance-ch10-protocole.md"
    if not table.exists():
        # The reader's resources may hold code/ alone.
        pytest.skip("docs/ is not next to code/")
    text = table.read_text("utf-8")
    known = {c.id for s in BLOCKS.values() for c in s["cases"]}
    cited = set()
    for line in text.splitlines():
        parts = line.split("|")
        if len(parts) > 3 and re.match(r" [ABC] `", parts[2]):
            cited |= set(re.findall(r"`(\w+)`", parts[2]))
    assert len(cited) >= 10
    assert cited <= known
    assert "non exécuté" in text


def test_plan_shows_that_three_rounds_exceed_the_cap():
    from assistant.protocol import chapter9_rounds, up_to_cent

    rows = {r[0]: (r[1], r[2]) for r in chapter9_rounds()}
    assert rows["1 tuning + 1 final"][0] == 370
    assert up_to_cent(rows["1 tuning + 1 final"][1]) == 1.87
    assert rows["1 tuning + 3 final"][0] == 690
    assert up_to_cent(rows["1 tuning + 3 final"][1]) == 3.49
    assert rows["2 tuning + 3 final"][0] == 770
    assert up_to_cent(0.5252) == 0.53  # never rounded down


def test_total_cap_can_be_set_and_is_applied(
    monkeypatch, tmp_path, corpus_fr
):
    """ASSISTANT_MAX_TOTAL_USD replaces the 2.00 USD default."""
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    monkeypatch.setattr(live, "_ask", lambda _: True)
    monkeypatch.setenv("ASSISTANT_MAX_TOTAL_USD", "0.0001")
    args = ["run", "--block", "A", "--max-usd", "0.10", "--yes"]
    assert live.main(args) == 0
    ledger = Ledger(tmp_path / "real" / "ledger.jsonl")
    assert ledger.attempts == 0


def test_person_runs_block_a_then_one_case_of_c(
    monkeypatch, tmp_path, corpus_fr
):
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    asked = []

    def ask(preview):
        asked.append(preview)
        return True

    monkeypatch.setattr(live, "_ask", ask)
    assert live.main(["person"]) == 0
    assert asked
    real = tmp_path / "real"
    data = json.loads(
        (real / live.PERSON_C_FILE).read_text("utf-8")
    )
    assert [r["case"] for r in data["cases"]] == ["send_asked"]
    # It does not count as block C having been run.
    assert set(protocol_blocks(real)) == {"A"}
    # A second sitting spends nothing more.
    before = Ledger(real / "ledger.jsonl").attempts
    assert live.main(["person"]) == 0
    assert Ledger(real / "ledger.jsonl").attempts == before


def test_person_stops_when_refused_without_key(
    monkeypatch, tmp_path
):
    real_env(monkeypatch, tmp_path, key="")
    forbid_real(monkeypatch)
    assert live.main(["person"]) == 2


def test_block_c_can_leave_its_person_case_aside(
    tmp_path, corpus_fr
):
    def no_person(_):
        raise AssertionError("nobody may be asked here")

    data = run_block(
        "C",
        tmp_path,
        corpus_fr,
        ask=no_person,
        deferred=live.PERSON_C,
    )
    row = case(data, "send_asked")
    assert row["deferred"] == live.PERSON_C_FILE
    assert data["all_passed"], data["cases"]


def protocol_blocks(real):
    from assistant.protocol import _real_blocks

    return _real_blocks(real)


def test_only_keeps_a_check_apart_from_the_block(
    monkeypatch, tmp_path, corpus_fr
):
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    args = [
        "run",
        "--block",
        "A",
        "--only",
        "plan",
        "--max-usd",
        "0.05",
        "--yes",
    ]
    assert live.main(args) == 0
    real = tmp_path / "real"
    assert list(real.glob("*/check-A.json"))
    assert not protocol_blocks(real)


def test_person_runs_block_a_again_after_a_failure(
    monkeypatch, tmp_path, corpus_fr
):
    real_env(monkeypatch, tmp_path)
    monkeypatch.setattr(live, "make_real", maker(corpus_fr))
    monkeypatch.setattr(live, "_ask", lambda _: True)
    failed = tmp_path / "real" / "20200101T000000Z"
    failed.mkdir(parents=True)
    (failed / "block-A.json").write_text(
        json.dumps(
            {
                "source": "real-api",
                "block": "A",
                "all_passed": False,
            }
        ),
        "utf-8",
    )
    assert live.main(["person"]) == 0
    assert protocol_blocks(tmp_path / "real")["A"]["all_passed"]
