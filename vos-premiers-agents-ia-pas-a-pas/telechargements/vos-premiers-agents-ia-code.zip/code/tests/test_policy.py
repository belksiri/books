import os

import pytest

from assistant.policy import AccessDenied, FileAccessPolicy


@pytest.fixture
def area(tmp_path):
    data = tmp_path / "data"
    notes = tmp_path / "workspace" / "notes"
    data.mkdir()
    notes.mkdir(parents=True)
    (data / "a.md").write_text("ok")
    (tmp_path / "secret.txt").write_text("secret")
    return tmp_path, data, notes


def test_read_inside_is_allowed(area):
    _, data, _ = area
    policy = FileAccessPolicy(read_roots=[data])
    assert policy.check_read(data / "a.md").name == "a.md"


@pytest.mark.parametrize(
    "trick",
    [
        "../secret.txt",
        "../../etc/passwd",
    ],
)
def test_dotdot_escape_is_refused(area, trick):
    _, data, _ = area
    policy = FileAccessPolicy(read_roots=[data])
    with pytest.raises(AccessDenied):
        policy.check_read(data / trick)


def test_absolute_path_is_refused(area):
    root, data, _ = area
    policy = FileAccessPolicy(read_roots=[data])
    with pytest.raises(AccessDenied):
        policy.check_read(root / "secret.txt")


@pytest.mark.skipif(os.name == "nt", reason="symlinks")
def test_symlink_pointing_outside_is_refused(area):
    root, data, _ = area
    (data / "link.md").symlink_to(root / "secret.txt")
    policy = FileAccessPolicy(read_roots=[data])
    with pytest.raises(AccessDenied):
        policy.check_read(data / "link.md")


def test_read_root_is_not_writable(area):
    _, data, notes = area
    policy = FileAccessPolicy(
        read_roots=[data], write_roots=[notes]
    )
    with pytest.raises(AccessDenied):
        policy.write_new(data, "new.md", "x")


@pytest.mark.parametrize(
    "name",
    [
        "../evil.md",
        "a/b.md",
        "Note.md",
        "note.py",
        ".hidden.md",
        "x" * 70 + ".md",
    ],
)
def test_bad_note_names_are_refused(area, name):
    _, _, notes = area
    policy = FileAccessPolicy([], write_roots=[notes])
    with pytest.raises(AccessDenied):
        policy.write_new(notes, name, "x")


def test_existing_note_is_never_overwritten(area):
    _, _, notes = area
    policy = FileAccessPolicy([], write_roots=[notes])
    policy.write_new(notes, "summary.md", "first")
    with pytest.raises(AccessDenied):
        policy.write_new(notes, "summary.md", "second")
    assert (notes / "summary.md").read_text() == "first"


def test_size_limit(area):
    _, _, notes = area
    policy = FileAccessPolicy(
        [], write_roots=[notes], max_write_bytes=10
    )
    with pytest.raises(AccessDenied):
        policy.write_new(notes, "big.md", "x" * 11)
