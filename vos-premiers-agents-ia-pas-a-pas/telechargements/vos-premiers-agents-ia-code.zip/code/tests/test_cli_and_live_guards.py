import re

import pytest

from assistant import cli, live


def test_demo_runs_without_key(monkeypatch, capsys):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setenv("ASSISTANT_LANG", "fr")
    assert cli.main(["demo"]) == 0
    out = capsys.readouterr().out
    assert "modèle simulé" in out
    assert (
        "cr-ag-2026-03#p03    oui    oui      oui     ?" in out
    )


def test_ask_is_refused_when_live_is_off(monkeypatch, capsys):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "0")
    monkeypatch.setenv("ASSISTANT_LANG", "fr")
    assert cli.main(["ask", "Bonjour"]) == 2


def test_live_run_does_not_promise_no_call(monkeypatch, capsys):
    monkeypatch.setenv("ASSISTANT_NO_DOTENV", "1")
    monkeypatch.delenv("ASSISTANT_ALLOW_LIVE", raising=False)
    args = ["run", "--block", "A", "--max-usd", "0.01", "--yes"]
    assert live.main(args) == 2
    out = capsys.readouterr().out
    assert "No call is made" not in out
    assert "refused: ASSISTANT_ALLOW_LIVE" in out


def test_live_plan_makes_no_call(monkeypatch, capsys):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert live.main(["plan"]) == 0
    out = capsys.readouterr().out
    assert "cumulative cap" in out and "block D" in out


def test_live_run_refused_without_block(monkeypatch):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "1")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    assert live.main(["run", "--yes"]) == 2


def test_live_run_refused_without_switch(monkeypatch):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "0")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    assert live.main(["run", "--block", "A", "--yes"]) == 2


def test_live_run_refused_without_key(monkeypatch):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "1")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert live.main(["run", "--block", "A", "--yes"]) == 2


def test_live_run_refused_without_yes(monkeypatch):
    monkeypatch.setenv("ASSISTANT_ALLOW_LIVE", "1")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    assert live.main(["run", "--block", "A"]) == 2


@pytest.mark.parametrize("lang", ["fr", "de", "en", "es"])
def test_demo_all_checks_pass_in_every_language(
    monkeypatch, capsys, lang
):
    monkeypatch.setenv("ASSISTANT_LANG", lang)
    assert cli.main(["demo"]) == 0
    out = capsys.readouterr().out
    pattern = re.compile(r"  \S+#p\d\d ")
    lines = [x for x in out.splitlines() if pattern.match(x)]
    assert len(lines) == 2
    width = max(len(x) for x in out.splitlines())
    assert width <= 64


def test_tests_cannot_reach_the_api(monkeypatch):
    """The conftest safety net blocks the SDK call itself."""
    from assistant.llm_anthropic import AnthropicModel

    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    model = AnthropicModel("claude-haiku-5-5", max_retries=0)
    with pytest.raises(RuntimeError, match="network call"):
        model.complete("s", [{"role": "user", "content": "x"}])
