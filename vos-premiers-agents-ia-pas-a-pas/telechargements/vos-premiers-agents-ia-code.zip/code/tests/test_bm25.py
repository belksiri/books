import math

from assistant.step05.bm25 import bm25_scores, bm25_search


def test_hand_computed_value():
    docs = [["velo", "rouge"], ["velo"], ["casque"]]
    k1, b = 1.5, 0.75
    avg = 4 / 3
    idf = math.log(1 + (3 - 1 + 0.5) / (1 + 0.5))
    norm = k1 * (1 - b + b * 2 / avg)
    expected = idf * 1 * (k1 + 1) / (1 + norm)
    score = bm25_scores(["rouge"], docs)[0]
    assert math.isclose(score, expected)


def test_rare_word_weighs_more():
    docs = [["velo", "casque"], ["velo"], ["velo"]]
    scores = bm25_scores(["velo", "casque"], docs)
    assert scores[0] > scores[1] == scores[2]


def test_repetition_saturates():
    one = bm25_scores(["frein"], [["frein"], ["x"]])[0]
    five = bm25_scores(["frein"], [["frein"] * 5, ["x"]])[0]
    ten = bm25_scores(["frein"], [["frein"] * 10, ["x"]])[0]
    assert one < five < ten
    assert ten - five < five - one


def test_shorter_passage_wins_at_equal_counts():
    docs = [["selle"], ["selle", "a", "b", "c", "d"], ["z"]]
    scores = bm25_scores(["selle"], docs)
    assert scores[0] > scores[1]


def test_no_match_returns_nothing(corpus_fr):
    assert bm25_search(corpus_fr, "trottinette", 5) == []


def test_known_query_ranks_expected_passage_first(corpus_fr):
    hits = bm25_search(corpus_fr, "annulation paliers jours", 3)
    assert hits[0].ref == "remboursement#p03"


def test_german_known_query(corpus):
    if corpus.lang != "de":
        return
    hits = bm25_search(corpus, "Gepäckträger Last", 3)
    assert hits[0].ref == "securite-velos#p03"


KNOWN = {
    "fr": ("charge porte-bagages", "securite-velos#p03"),
    "de": ("Gepäckträger Last", "securite-velos#p03"),
    "en": ("rear rack load", "securite-velos#p03"),
    "es": ("carga portaequipajes", "securite-velos#p03"),
}


def test_known_query_in_every_language(corpus):
    query, ref = KNOWN[corpus.lang]
    assert bm25_search(corpus, query, 3)[0].ref == ref
