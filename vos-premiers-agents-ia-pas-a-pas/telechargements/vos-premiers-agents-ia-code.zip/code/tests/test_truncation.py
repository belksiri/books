"""Traces must match what the model really received."""

import pytest

from assistant.llm import ToolCall
from assistant.step04.tools import build_toolbox
from assistant.step05.citations import check_citations

DOC = "remboursement"  # five passages


def limit_cutting_p03(corpus, visible=40):
    """A size limit that sends p01, p02 whole, p03 in part."""
    doc = corpus.get(DOC)
    header = " | ".join(
        f"{k}: {v}" for k, v in doc.meta.items()
    )
    used = len(header) + 1
    for p in doc.passages[:2]:
        used += len(f"[{p.ref}] {p.text}") + 1
    return used + len(f"[{DOC}#p03] ") + visible


@pytest.fixture
def cut(corpus_fr, tmp_path):
    consulted: dict[str, str] = {}
    box = build_toolbox(
        corpus_fr,
        tmp_path,
        consulted,
        max_chars=limit_cutting_p03(corpus_fr),
    )
    out = box.execute(
        ToolCall("1", "read_document", {"doc_id": DOC})
    )
    return out, consulted


def test_only_transmitted_passages_are_recorded(corpus_fr, cut):
    out, consulted = cut
    p03 = corpus_fr.passage(f"{DOC}#p03").text
    assert set(consulted) == {
        f"{DOC}#p01",
        f"{DOC}#p02",
        f"{DOC}#p03",
    }
    assert consulted[f"{DOC}#p03"] == p03[:40]
    assert f"[{DOC}#p04]" not in out.content
    assert "[truncated: 3 passage(s)" in out.content


def test_reference_in_truncated_part_is_not_consulted(
    corpus_fr, cut
):
    _, consulted = cut
    p05 = corpus_fr.passage(f"{DOC}#p05").text
    answer = f"- [{DOC}#p05] « {p05[:30]} »"
    [check] = check_citations(answer, corpus_fr, consulted)
    assert check.exists and check.excerpt  # the text is real
    assert check.consulted is False  # but never sent


def test_partial_passage_depends_on_the_quote(corpus_fr, cut):
    _, consulted = cut
    p03 = corpus_fr.passage(f"{DOC}#p03").text
    inside = f"- [{DOC}#p03] « {p03[:25]} »"
    beyond = f"- [{DOC}#p03] « {p03[-30:]} »"
    no_quote = f"Voir [{DOC}#p03]."
    [a] = check_citations(inside, corpus_fr, consulted)
    [b] = check_citations(beyond, corpus_fr, consulted)
    [c] = check_citations(no_quote, corpus_fr, consulted)
    assert (a.partial, a.consulted) == (True, True)
    assert (b.partial, b.consulted, b.excerpt) == (
        True,
        False,
        True,
    )
    assert (c.partial, c.consulted) == (True, False)


def test_a_whole_view_is_not_downgraded(corpus_fr, tmp_path):
    consulted: dict[str, str] = {}
    whole = build_toolbox(corpus_fr, tmp_path, consulted)
    whole.execute(
        ToolCall("1", "read_document", {"doc_id": DOC})
    )
    small = build_toolbox(
        corpus_fr,
        tmp_path,
        consulted,
        max_chars=limit_cutting_p03(corpus_fr),
    )
    small.execute(
        ToolCall("2", "read_document", {"doc_id": DOC})
    )
    p03 = corpus_fr.passage(f"{DOC}#p03").text
    assert consulted[f"{DOC}#p03"] == p03


def test_search_results_are_cut_the_same_way(
    corpus_fr, tmp_path
):
    consulted: dict[str, str] = {}
    box = build_toolbox(
        corpus_fr, tmp_path, consulted, max_chars=120
    )
    out = box.execute(
        ToolCall(
            "1",
            "search_documents",
            {"query": "dépôt de garantie"},
        )
    )
    assert "[truncated:" in out.content
    shown = [r for r in consulted]
    assert 1 <= len(shown) <= 2
    for ref in shown:
        assert f"[{ref}]" in out.content


def test_citation_keeps_document_date_and_status(corpus_fr):
    ref = "tarifs-2026#p04"
    consulted = {ref: corpus_fr.passage(ref).text}
    [check] = check_citations(
        f"Voir [{ref}].", corpus_fr, consulted
    )
    assert check.doc_date == "2026-02-10"
    assert check.doc_status.startswith("projet")
    assert check.supported is None  # judgment, not code
