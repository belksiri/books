"""Commands of chapter 7: approval-demo, actions."""

from __future__ import annotations

import tempfile
import textwrap
from pathlib import Path

from assistant.approval import OutboxSender
from assistant.corpus import Corpus
from assistant.messages import localize, localize_preview, t
from assistant.prompts import load
from assistant.scenarios import (
    BUREAU,
    GATE_TEXT,
    misled_scenario,
)
from assistant.step04.agent import _describe, new_state, run
from assistant.step07.gate import (
    ActionJournal,
    GateRefused,
    SendGate,
)
from assistant.step07.tools import build_toolbox_step07

WIDTH = 64


def _c(lang: str) -> str:
    return "\u00a0: " if lang == "fr" else ": "


def _cut(line: str) -> str:
    return (
        line if len(line) <= WIDTH else line[: WIDTH - 1] + "…"
    )


def _show(text: str) -> None:
    for line in text.splitlines():
        if len(line) <= WIDTH:
            print(line)
        else:
            print(
                textwrap.fill(
                    line, WIDTH, break_on_hyphens=False
                )
            )


def _traced(toolbox, lang: str) -> None:
    """Print each call and its result as it happens."""
    execute = toolbox.execute

    def traced(call):
        outcome = execute(call)
        head, result = _describe(call, outcome).split("\n", 1)
        print(_cut(head))
        print(_cut("   " + localize(lang, result)))
        return outcome

    toolbox.execute = traced


class _CrashAfterWrite(OutboxSender):
    def send(self, action, approval, filename):
        path = super().send(action, approval, filename)
        raise SystemError(f"crash after {path.name}")


def _person(answers: list[bool], lang: str):
    """A scripted person: prints what a real one would read."""

    def ask(preview: str) -> bool:
        print(f"--- {t(lang, 'person_sees')} ---")
        _show(localize_preview(lang, preview))
        answer = answers.pop(0)
        word = "yes" if answer else "no"
        print(
            f"--- {t(lang, 'person_says')}{_c(lang)}"
            f"{t(lang, word)} ---"
        )
        return answer

    return ask


def approval_demo(lang: str, corpus: Corpus) -> int:
    print(f"({t(lang, 'simulated')})")
    text = GATE_TEXT[lang]
    clock = "2026-06-15T10:00:00+00:00"
    with tempfile.TemporaryDirectory() as tmp:
        journal = ActionJournal(
            Path(tmp) / "logs" / "actions.jsonl",
            clock=lambda: clock,
        )
        outbox = Path(tmp) / "outbox"
        print(f"=== {t(lang, 'session')} 1 ===")
        gate = SendGate(
            {BUREAU},
            _person([False, True], lang),
            "camille",
            OutboxSender(outbox),
            journal,
        )
        state = new_state()
        toolbox = build_toolbox_step07(
            corpus, state.consulted, gate
        )
        _traced(toolbox, lang)
        system = load("step07", lang, today="2026-06-15")
        result = run(
            misled_scenario(lang),
            system,
            text["ask"],
            toolbox,
            state,
        )
        print(f"{t(lang, 'status')}{_c(lang)}{result.status}")
        print(f"{t(lang, 'journal')}{_c(lang).rstrip()}")
        _print_journal(journal)

        print(f"=== {t(lang, 'session')} 2 ===")
        gate = SendGate(
            {BUREAU},
            _person([True], lang),
            "camille",
            _CrashAfterWrite(outbox),
            journal,
        )
        try:
            gate.submit(BUREAU, text["clean2"])
        except SystemError:
            print(_cut(text["crash"]))

        print(f"=== {t(lang, 'session')} 3 ===")
        gate = SendGate(
            {BUREAU},
            _person([], lang),  # nobody is even asked
            "camille",
            OutboxSender(outbox),
            journal,
        )
        try:
            gate.submit(BUREAU, text["clean2"])
        except GateRefused as error:
            _show(localize(lang, f"ERROR: {error}"))
        digest = journal.unknown()[0]
        print(_cut(text["checked"]))
        journal.resolve(digest, True, "camille")
        files = sum(1 for _ in outbox.iterdir())
        print(f"outbox: {files}")
        print(f"{t(lang, 'journal')}{_c(lang).rstrip()}")
        _print_journal(journal, last=3)
    return 0


def _print_journal(journal, last: int | None = None) -> None:
    events = journal.events()
    for event in events[-last:] if last else events:
        why = event.get("why", "")
        line = f"  {event['digest'][:8]} {event['event']} {why}"
        print(_cut(line.rstrip()))


def actions(settings, args) -> int:
    """List sendings with an unknown outcome, or settle one."""
    lang = settings.lang
    journal = ActionJournal(settings.journal_path)
    if args.resolve:
        if not args.who or args.happened is None:
            print(t(lang, "resolve_needs"))
            return 2
        try:
            journal.resolve(
                args.resolve, args.happened == "yes", args.who
            )
        except ValueError as error:
            print(localize(lang, str(error)))
            return 2
        return 0
    for digest in journal.unknown():
        print(digest)
    return 0
