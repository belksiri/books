"""Step 05: BM25 search, plus two memory tools.

Memory is read once, into the system prompt; the model can
only ask to add (`remember`) or remove (`forget`) an entry.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import Field

from assistant.corpus import Corpus
from assistant.memory import KINDS, MemoryRefused, MemoryStore
from assistant.step04.tools import (
    Strict,
    Tool,
    Toolbox,
    ToolError,
    build_toolbox,
)
from assistant.step05.bm25 import bm25_search


class RememberParams(Strict):
    # Capitalization of enum values is not guaranteed (T7).
    kind: str = Field(pattern=r"(?i)^(preference|fact)$")
    text: str = Field(min_length=1, max_length=200)


class ForgetParams(Strict):
    memory_id: str = Field(pattern=r"^m\d{3}$")


REMEMBER_SCHEMA = {
    "type": "object",
    "properties": {
        "kind": {"type": "string", "enum": list(KINDS)},
        "text": {
            "type": "string",
            "description": "One short sentence, no personal "
            "data.",
        },
    },
    "required": ["kind", "text"],
    "additionalProperties": False,
}

FORGET_SCHEMA = {
    "type": "object",
    "properties": {"memory_id": {"type": "string"}},
    "required": ["memory_id"],
    "additionalProperties": False,
}


def build_toolbox_step05(
    corpus: Corpus,
    notes_dir: Path,
    consulted: dict[str, str],
    memory: MemoryStore,
) -> Toolbox:
    base = build_toolbox(
        corpus, notes_dir, consulted, search=bm25_search
    )

    def remember(args: RememberParams) -> str:
        try:
            entry = memory.remember(
                args.kind.lower(), args.text
            )
        except MemoryRefused as error:
            raise ToolError(
                f"Not remembered: {error}"
            ) from error
        return f"Remembered as {entry.id}."

    def forget(args: ForgetParams) -> str:
        try:
            memory.forget(args.memory_id)
        except MemoryRefused as error:
            raise ToolError(str(error)) from error
        return f"Forgotten: {args.memory_id}."

    extra = [
        Tool(
            "remember",
            "Ask to remember a user preference or a stable "
            "fact "
            "for future sessions. The user must confirm.",
            REMEMBER_SCHEMA,
            RememberParams,
            remember,
        ),
        Tool(
            "forget",
            "Remove a memory entry by its id.",
            FORGET_SCHEMA,
            ForgetParams,
            forget,
        ),
    ]
    return Toolbox(
        list(base._tools.values()) + extra,
        base.consulted,
        base.max_chars,
    )
