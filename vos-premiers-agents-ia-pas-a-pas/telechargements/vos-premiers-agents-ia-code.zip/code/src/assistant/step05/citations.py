"""Step 05: checking the references given in an answer.

Four separate checks, never merged into one "ok":
1. exists      the passage id is real;
2. consulted   the model actually received that passage (for a
               passage cut by truncation: only if the quoted
               excerpt lies in the part it received);
3. excerpt     the quoted words appear in the passage;
4. supported   the passage says what the claim says.

Checks 1-3 are deterministic. Check 4 needs judgment (a person,
in chapter 9): it stays None until done.
Two other questions are NOT answered by a single citation:
is the passage still current at the reference date, and does
it prevail over a contradicting source? The document date and
status are copied here to help that review.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from assistant.corpus import Corpus

REF = re.compile(r"\[([a-z0-9][a-z0-9-]*#p\d{2})\]")
QUOTE_LINE = re.compile(
    r"^\s*[-*]\s*\[([a-z0-9][a-z0-9-]*#p\d{2})\]\s*"
    r"[«“\"„]\s*(.+?)\s*[»”\"“]\s*$"
)
ELLIPSIS = re.compile(r"\s*(?:…|\.\.\.)\s*")


# [snippet:check-class]
@dataclass
class CitationCheck:
    ref: str
    quote: str | None
    exists: bool
    consulted: bool
    excerpt: bool | None  # None: no quote given
    supported: bool | None = None  # None: not assessed yet
    partial: bool = False  # passage received only in part
    doc_date: str | None = None  # for the currency review
    doc_status: str | None = None


# [/snippet]


def _clean(text: str) -> str:
    text = text.replace("’", "'").replace("\u00a0", " ")
    text = text.replace("\u202f", " ")
    return " ".join(text.split()).lower()


# [snippet:excerpt]
def excerpt_in(quote: str, passage: str) -> bool:
    """True if every part of the quote is in the passage, in
    order. "…" marks words left out."""
    position, text = 0, _clean(passage)
    for part in ELLIPSIS.split(_clean(quote)):
        if not part:
            continue
        found = text.find(part, position)
        if found < 0:
            return False
        position = found + len(part)
    return True


# [/snippet]


def check_citations(
    answer: str, corpus: Corpus, consulted: dict[str, str]
) -> list[CitationCheck]:
    quotes = {}
    for line in answer.splitlines():
        match = QUOTE_LINE.match(line)
        if match:
            quotes.setdefault(match[1], match[2])
    checks = []
    for ref in dict.fromkeys(REF.findall(answer)):
        passage = corpus.passage(ref)
        quote = quotes.get(ref)
        excerpt = None
        if quote is not None:
            excerpt = bool(passage) and excerpt_in(
                quote, passage.text
            )
        seen, ok, partial = _consulted(
            ref, passage, quote, consulted
        )
        doc = corpus.get(ref.partition("#")[0])
        meta = doc.meta if doc else {}
        checks.append(
            CitationCheck(
                ref,
                quote,
                passage is not None,
                ok,
                excerpt,
                partial=partial,
                doc_date=meta.get("date"),
                doc_status=meta.get("status"),
            )
        )
    return checks


# [snippet:consulted]
def _consulted(ref, passage, quote, consulted):
    """(seen, consulted check, partial) for one reference."""
    seen = consulted.get(ref)
    if seen is None or passage is None:
        return seen, False, False
    if seen == passage.text:
        return seen, True, False
    # Received in part: accepted only if the quote is inside
    # the part received; without a quote, we cannot tell.
    ok = quote is not None and excerpt_in(quote, seen)
    return seen, ok, True


# [/snippet]
