"""Scripted models for `assistant-live dryrun`.

They exercise the trial program (guard, loop, checks, approval,
error handling) without any network call. Every answer and every
error here is written by hand and recorded with source
"simulated": it proves nothing about a real model or server.
"""

from __future__ import annotations

from assistant.llm import FakeModel, ModelError
from assistant.scenarios import (
    MEMORY_TEXT,
    deposit_scenario,
    memory_session1,
    memory_session2,
    synthesis_session1,
    synthesis_session2,
    team_full_run,
)

ANSWERS = {
    "membership": (
        "L'adhésion annuelle coûte 72 € depuis le "
        "1er avril 2026 [cr-ag-2026-03#p02].\n\nSources\n"
        "- [tarifs-2026#p02] « Adhésion annuelle : 72 € »"
    ),
    "refund": (
        "Oui, à 40 % [remboursement#p03].\n\nSources\n"
        "- [remboursement#p03] « 40 % de 2 à 4 jours »"
    ),
    "unknown": "Les documents ne donnent pas ce montant.",
    "injection": (
        "Il demande les tarifs de location à la journée "
        "[courriel-externe#p02]."
    ),
    "send": (
        "Une demande se fait sous 30 jours [remboursement#p01]."
    ),
}
SEARCH = {
    "membership": ("adhésion annuelle", "cr-ag-2026-03"),
    "refund": (
        "annulation jours remboursement",
        "remboursement",
    ),
    "unknown": ("entretien vélo coût", "fournisseurs"),
    "injection": ("office de tourisme", "courriel-externe"),
    "send": ("remboursement procédure", "remboursement"),
}


def _reader(task: str) -> FakeModel:
    query, doc = SEARCH[task]
    return FakeModel(
        [
            FakeModel.calls(
                ("search_documents", {"query": query})
            ),
            FakeModel.calls(("read_document", {"doc_id": doc})),
            FakeModel.says(ANSWERS[task]),
        ]
    )


def _mission(corpus) -> FakeModel:
    """Session 1 without its failure, then session 2."""
    first = synthesis_session1("fr", corpus)._replies[:-1]
    second = synthesis_session2("fr", corpus)._replies
    return FakeModel(first + second)


def _memory() -> FakeModel:
    return FakeModel(
        memory_session1("fr")._replies
        + memory_session2("fr")._replies
    )


def _send(text: str, target: str | None = None) -> FakeModel:
    calls = [
        FakeModel.calls(
            ("read_document", {"doc_id": "remboursement"})
        )
    ]
    if target:
        calls.append(
            FakeModel.calls(
                (
                    "send_message",
                    {"target": target, "content": text},
                )
            )
        )
    return FakeModel([*calls, FakeModel.says(text)])


def make_fake(
    name: str,
    case: str,
    corpus=None,
    tasks: list[str] | None = None,
    **options,
) -> FakeModel:
    model = _script(case, corpus, tasks or [])
    model.name = name  # priced as the real model, for the guard
    if "max_tokens" in options:
        model.max_tokens = options["max_tokens"]
    return model


def _script(case: str, corpus, tasks: list[str]) -> FakeModel:
    from assistant.scenarios import BUREAU, OUTSIDER

    if case == "plain":
        return FakeModel(
            [FakeModel.says("Je suis un modèle simulé.")]
        )
    if case in ("tools", "deposit"):
        return deposit_scenario("fr")
    if case in SEARCH:
        return _reader(case)
    if case == "plan":
        from assistant.scenarios import synthesis_plan

        return FakeModel([FakeModel.json(synthesis_plan("fr"))])
    if case == "review":
        return FakeModel([FakeModel.json({"issues": []})])
    if case == "schema":
        return FakeModel(
            [ModelError("400 (simulated by hand)", False)]
        )
    if case == "cut":
        return FakeModel([FakeModel.truncated("Première")])
    if case == "bad_id":
        return FakeModel(
            [
                FakeModel.calls(
                    (
                        "read_document",
                        {"doc_id": "statuts-2031"},
                    )
                ),
                FakeModel.calls(
                    ("read_document", {"doc_id": "statuts"})
                ),
                FakeModel.says(
                    "Au moins une fois par an [statuts#p03]."
                ),
            ]
        )
    if case == "timeout":
        return FakeModel(
            [ModelError("timeout (simulated by hand)", True)]
        )
    if case == "bad_key":
        return FakeModel(
            [
                ModelError("401 (simulated by hand)", False),
                FakeModel.says("not reached: no retry"),
            ]
        )
    if case == "mission":
        return _mission(corpus)
    if case == "memory":
        return _memory()
    if case == "send_asked":
        return _send(ANSWERS["send"], BUREAU)
    if case == "send_outsider":
        return _send("Envoi refusé par le programme.", OUTSIDER)
    if case == "send_injection":
        return _send(ANSWERS["injection"])
    if case == "team":
        return team_full_run("fr", corpus)
    if case == "compare":
        replies = []
        for task in tasks:
            replies += _reader(task)._replies
        return FakeModel(replies)
    raise ValueError(f"no script for {case}")


__all__ = ["MEMORY_TEXT", "make_fake"]
