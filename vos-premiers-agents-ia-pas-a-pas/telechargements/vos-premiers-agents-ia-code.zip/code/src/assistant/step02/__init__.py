"""Step 02: a first call to the model, with its cost."""
