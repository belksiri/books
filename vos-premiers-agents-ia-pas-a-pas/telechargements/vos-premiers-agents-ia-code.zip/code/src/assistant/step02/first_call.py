"""One question, one answer, its tokens and estimated cost.

A paid call, off by default: the model comes from paid.py, which
refuses unless ASSISTANT_ALLOW_LIVE is 1.

    uv run python -m assistant.step02.first_call "question"
"""

from __future__ import annotations

import sys

from assistant.config import load_settings
from assistant.llm import ModelError, ModelReply
from assistant.messages import localize, t
from assistant.paid import mission_key, open_model
from assistant.pricing import PRICE_TIERS, request_cost

# [snippet:system]
SYSTEM = (
    "Answer in the language of the question, in a few "
    "sentences. If you are not sure, say so."
)
# [/snippet]


# [snippet:show-reply]
def show_reply(
    reply: ModelReply, model_name: str, lang: str = "fr"
) -> None:
    usage = reply.usage
    tokens = f"{usage.input_tokens}/{usage.output_tokens}"
    cost = t(lang, "unknown")
    if model_name in PRICE_TIERS:
        usd = request_cost(model_name, usage)
        cost = f"{usd:.6f} USD"
    print(f"--- {t(lang, 'answer')} ---")
    print(reply.text)
    print("---")
    print(f"{'stop_reason':<24}{reply.stop_reason}")
    print(f"{t(lang, 'tokens'):<24}{tokens}")
    print(f"{t(lang, 'cost'):<24}{cost}")


# [/snippet]


# [snippet:first-call]
def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        print(
            localize(
                load_settings().lang,
                'usage: first_call "question"',
            )
        )
        return 2
    question = args[0]
    settings = load_settings()
    mission = mission_key("first", question)
    model = open_model(settings, mission, 1)
    if model is None:  # open_model has said why
        return 1
    messages = [{"role": "user", "content": question}]
    try:
        reply = model.complete(SYSTEM, messages)
    except ModelError as error:
        print(
            localize(
                settings.lang, f"refused or failed: {error}"
            )
        )
        return 1
    show_reply(reply, model.name, settings.lang)
    return 0


# [/snippet]


if __name__ == "__main__":
    raise SystemExit(main())
