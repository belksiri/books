"""Human approval of a sensitive action.

Rules:
- the person approves the exact action: kind, target and
  final content, summarized by a SHA-256 digest;
- any change alters the digest, so it requires a new approval;
- an approval can be used only once;
- what is shown is what leaves: the whole content, and nothing
  invisible in it;
- "sending" is simulated: it writes a file into outbox/.
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from assistant.policy import FileAccessPolicy

# [snippet:hidden]
NEWLINE_OR_TAB = "\n\t"
HIDDEN_CATEGORIES = {
    "Cc",  # controls: terminal escapes, bell...
    "Cf",  # format: zero-width, right-to-left, soft hyphen...
    "Co",  # private use
    "Cs",  # surrogates
    "Cn",  # not assigned in Python's Unicode tables
    "Zl",  # line separator
    "Zp",  # paragraph separator
}


def hidden_characters(text: str) -> list[str]:
    """Code points refused in a text a person must approve.

    Allowed: letters and combining accents, in any language;
    ordinary spaces, including no-break and thin ones; tab, LF,
    and CR only as part of CRLF. A lone CR could rewrite a
    line on a terminal. Variation selectors, which display
    nothing but can carry data, are refused too.
    """
    text = text.replace("\r\n", "\n")
    return sorted(
        {
            f"U+{ord(c):04X}"
            for c in text
            if c not in NEWLINE_OR_TAB
            and (
                unicodedata.category(c) in HIDDEN_CATEGORIES
                or "VARIATION SELECTOR"
                in unicodedata.name(c, "")
            )
        }
    )


# [/snippet]


# [snippet:action]
@dataclass(frozen=True)
class ProposedAction:
    kind: str  # for example "send_summary"
    target: str  # recipient or destination
    content: str  # final content, exactly as it will leave

    def digest(self) -> str:
        canonical = json.dumps(
            [self.kind, self.target, self.content],
            ensure_ascii=False,
        )
        return hashlib.sha256(canonical.encode()).hexdigest()

    def preview(self) -> str:
        return (
            f"action: {self.kind}\ntarget: {self.target}\n"
            f"digest: {self.digest()[:16]}\n"
            f"--- content ---\n{self.content}\n--- end ---"
        )


# [/snippet]


@dataclass(frozen=True)
class Approval:
    digest: str
    approved_by: str
    approved_at: str


class ApprovalRequired(Exception):
    pass


def request_approval(
    action: ProposedAction,
    ask: Callable[[str], bool],
    who: str,
) -> Approval | None:
    """Show the whole action and wait for an explicit answer."""
    if not ask(action.preview()):
        return None
    now = datetime.now(UTC).isoformat(timespec="seconds")
    return Approval(action.digest(), who, now)


def ask_person(preview: str, question: str) -> bool:
    """A real person, at the terminal. Anything but a clear
    yes is a no."""
    print(preview)
    answer = input(question).strip().lower()
    return answer in (
        "y",
        "yes",
        "o",
        "oui",
        "s",
        "si",
        "sí",
        "j",
        "ja",
    )


class OutboxSender:
    """The only component allowed to write into outbox/."""

    def __init__(self, outbox: Path):
        self.outbox = Path(outbox)
        self._policy = FileAccessPolicy(
            read_roots=[], write_roots=[self.outbox]
        )
        self._used: set[str] = set()

    # [snippet:send-checks]
    def send(
        self,
        action: ProposedAction,
        approval: Approval | None,
        filename: str,
    ) -> Path:
        if approval is None:
            raise ApprovalRequired("no approval")
        if approval.digest != action.digest():
            raise ApprovalRequired(
                "content changed since approval"
            )
        if approval.digest in self._used:
            raise ApprovalRequired("approval already used")
        # [/snippet]
        record = {
            "kind": action.kind,
            "target": action.target,
            "digest": approval.digest,
            "approved_by": approval.approved_by,
            "approved_at": approval.approved_at,
        }
        header = json.dumps(record, ensure_ascii=False)
        body = f"<!-- {header} -->\n{action.content}\n"
        path = self._policy.write_new(
            self.outbox, filename, body
        )
        self._used.add(approval.digest)
        return path
