"""Paid trials against the real API, block by block.

    assistant-live plan                  bounds, no call
    assistant-live preflight --block A   read before deciding
    assistant-live dryrun --block A      whole block, FakeModel
    assistant-live run --block A --max-usd 0.10 --yes
    assistant-live person                block A, then one case
                                         of C: for a person
    assistant-live run --block C --skip-person --max-usd 0.53 \\
        --yes

Blocks A, B, C, then D: see `protocol.py`. Paid runs are off by
default. `run` refuses to start unless ASSISTANT_ALLOW_LIVE=1,
a key is set locally, the block is named, its turn has come,
and both --max-usd and --yes are given. Every billable attempt,
failed ones included, goes to a cumulative ledger. The total
(2.00 USD unless ASSISTANT_MAX_TOTAL_USD says otherwise) is a
limit, not an authorization: the lowest limit applies. Results
carry their source: "real-api" or
"simulated". A simulated answer is never a model answer.
"""

from __future__ import annotations

import argparse
import json
import os
from datetime import UTC, datetime

from assistant.approval import ask_person
from assistant.budget import Ledger
from assistant.config import CODE_DIR, load_settings
from assistant.corpus import Corpus
from assistant.dryrun import make_fake
from assistant.paid import make_anthropic, policy_from_env
from assistant.pricing import PRICE_TIERS
from assistant.protocol import (
    BLOCKS,
    CAP_USD,
    EFFORT,
    LANG,
    MAX_TOKENS,
    _real_blocks,
    block_allowed,
    block_max_usd,
    describe_plan,
    preflight,
    session,
    up_to_cent,
)

RESULTS = CODE_DIR / "live_results"
PERSON_C_FILE = "person-C-send_asked.json"
PERSON_C = {"send_asked": PERSON_C_FILE}


def make_real(name: str, _case: str, **options):
    return make_anthropic(
        name,
        max_tokens=options.get("max_tokens", MAX_TOKENS),
        effort=EFFORT,
        timeout=options.get("timeout", 60.0),
        api_key=options.get("api_key"),
    )


def _failed_tasks(real_dir) -> list[str]:
    files = sorted(real_dir.glob("*/block-C.json"))
    data = json.loads(files[-1].read_text("utf-8"))
    return data["tasks_failed_automatically"]


def _stamp() -> str:
    return datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")


def _ask(preview: str) -> bool:
    return ask_person(
        preview, "Valider cet envoi simulé (fichier local) ?"
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="assistant-live")
    parser.add_argument(
        "action",
        choices=[
            "plan",
            "preflight",
            "dryrun",
            "run",
            "person",
        ],
    )
    parser.add_argument("--block", choices=list(BLOCKS))
    parser.add_argument(
        "--tasks",
        help="block D: tasks to compare, separated by commas "
        "(default: those failed automatically in block C)",
    )
    parser.add_argument("--yes", action="store_true")
    parser.add_argument(
        "--max-usd",
        type=float,
        help="limit applied by the program to this run",
    )
    parser.add_argument(
        "--again",
        action="store_true",
        help="run a block again: every attempt is paid again",
    )
    parser.add_argument(
        "--skip-person",
        action="store_true",
        help="block C: leave the case that needs a person to "
        "`assistant-live person`",
    )
    parser.add_argument(
        "--only",
        help="cases to check, separated by commas: kept in a "
        "check-*.json, never counted as the block run",
    )
    args = parser.parse_args(argv)
    for spec in BLOCKS.values():
        if spec["model"] not in PRICE_TIERS:
            print(f"no price for {spec['model']}")
            return 2
    if args.action == "preflight":
        if args.block is None:
            print("refused: choose --block A, B, C or D")
            return 2
        print(preflight(args.block))
        return 0
    load_settings()
    plan = describe_plan(
        float(os.getenv("ASSISTANT_MAX_TOTAL_USD") or CAP_USD)
    )
    if args.action in ("run", "person"):
        # Its first line promises no call: false for `run`.
        plan = plan.split("\n", 1)[1]
    print(plan)
    if args.action == "plan":
        return 0
    if args.action == "person":
        return _person(args)
    if args.block is None:
        print("refused: choose --block A, B, C or D")
        return 2
    tasks = args.tasks.split(",") if args.tasks else None
    if args.action == "dryrun":
        return _dryrun(args.block, tasks)
    return _real(args, tasks)


def _dryrun(block: str, tasks: list[str] | None) -> int:
    base = RESULTS / "dryrun" / _stamp()
    corpus = Corpus.load(CODE_DIR / "demo_data" / LANG, LANG)
    if block == "D" and not tasks:
        tasks = ["refund"]
    # Simulated spend is fictitious: one ledger per dry run,
    # never mixed with the real ledger.
    path = session(
        block,
        lambda name, case, **options: make_fake(
            name, case, corpus, tasks, **options
        ),
        "simulated",
        lambda _: True,
        base,
        Ledger(base / "ledger.jsonl"),
        tasks,
    )
    print(f"simulated, proves nothing about a model: {path}")
    return 0


def _real(args, tasks: list[str] | None) -> int:
    settings = load_settings()
    if not settings.allow_live:
        print("refused: ASSISTANT_ALLOW_LIVE is not 1")
        return 2
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("refused: ANTHROPIC_API_KEY is not set")
        return 2
    real_dir = RESULTS / "real"
    allowed, reason = block_allowed(
        args.block, real_dir, args.again or bool(args.only)
    )
    if not allowed:
        print(f"refused: {reason}")
        return 2
    if args.block == "D" and not tasks:
        tasks = _failed_tasks(real_dir)
        if not tasks:
            print(
                "refused: no task failed automatically; name "
                "--tasks only if a person found a failure"
            )
            return 2
    if not args.yes or args.max_usd is None:
        upper = up_to_cent(block_max_usd(args.block))
        print(
            f"refused: add --max-usd and --yes to accept block "
            f"{args.block}, upper estimate {upper:.2f} USD "
            "before taxes"
        )
        return 2
    ledger = Ledger(real_dir / "ledger.jsonl")
    policy = policy_from_env(ledger, args.max_usd)
    path = session(
        args.block,
        make_real,
        "real-api",
        _ask,
        real_dir / _stamp(),
        ledger,
        tasks,
        ledger.charged_usd + policy.room(args.block),
        policy.per_call_usd,
        only=set(args.only.split(",")) if args.only else None,
        deferred=PERSON_C
        if args.block == "C" and args.skip_person
        else None,
    )
    if args.only:
        # Not a block-*.json: not the block having been run.
        name = f"check-{args.block}.json"
        path = path.rename(path.with_name(name))
    print(f"written: {path}")
    return 0


def _person(args) -> int:
    """All that needs a person at the keyboard, in one sitting:
    block A, then the one case of block C with a real approval.
    Answer for yourself: nobody else may answer here."""
    settings = load_settings()
    if not settings.allow_live:
        print("refused: ASSISTANT_ALLOW_LIVE is not 1")
        return 2
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("refused: ANTHROPIC_API_KEY is not set")
        return 2
    real_dir = RESULTS / "real"
    ledger = Ledger(real_dir / "ledger.jsonl")
    done = _real_blocks(real_dir)
    stamp = real_dir / _stamp()
    if (
        "A" not in done
        or not done["A"]["all_passed"]
        or args.again
    ):
        # Room for one whole block, on top of earlier attempts.
        earlier = policy_from_env(ledger, 0.0).spent_on("A")
        policy = policy_from_env(ledger, 0.10 + earlier)
        path = session(
            "A",
            make_real,
            "real-api",
            _ask,
            stamp,
            ledger,
            None,
            ledger.charged_usd + policy.room("A"),
            policy.per_call_usd,
        )
        print(f"written: {path}")
        done = _real_blocks(real_dir)
    if not done["A"]["all_passed"]:
        print("block A did not pass: stopped here")
        return 1
    target = real_dir / PERSON_C_FILE
    if target.exists():
        print(f"already done: {target}")
        return 0
    earlier = policy_from_env(ledger, 0.0).spent_on("C")
    policy = policy_from_env(ledger, 0.04 + earlier)
    path = session(
        "C",
        make_real,
        "real-api",
        _ask,
        stamp,
        ledger,
        None,
        ledger.charged_usd + policy.room("C"),
        policy.per_call_usd,
        only={"send_asked"},
    )
    # Not a block-*.json: it must not count as block C run.
    path.rename(target)
    print(f"written: {target}")
    print("done: nothing else is needed from you for now")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
