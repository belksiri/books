"""The only door to the API: one ledger, one policy.

Each command that can reach the service gets its model here.
Off by default: ASSISTANT_ALLOW_LIVE=1, a local key and a known
price are needed. Limits per call, mission and day are read from
the environment, with low defaults; the ledger keeps counting
from one run to the next.
"""

from __future__ import annotations

import hashlib
import os

from assistant.budget import (
    PLANNING_CAP_USD,
    GuardedModel,
    Ledger,
)
from assistant.config import CODE_DIR
from assistant.messages import localize, t
from assistant.pricing import PRICE_TIERS
from assistant.step10.budgets import BudgetPolicy

REAL_DIR = CODE_DIR / "live_results" / "real"
DEFAULT_CALL_USD = 0.01
DEFAULT_MISSION_USD = 0.10
DEFAULT_DAY_USD = 1.00


def real_ledger() -> Ledger:
    return Ledger(REAL_DIR / "ledger.jsonl")


def policy_from_env(
    ledger: Ledger, per_mission_usd: float | None = None
) -> BudgetPolicy:
    def read(name: str, default: float) -> float:
        return float(os.getenv(name) or default)

    return BudgetPolicy(
        read("ASSISTANT_MAX_CALL_USD", DEFAULT_CALL_USD),
        per_mission_usd
        if per_mission_usd is not None
        else read("ASSISTANT_MAX_USD", DEFAULT_MISSION_USD),
        read("ASSISTANT_MAX_DAY_USD", DEFAULT_DAY_USD),
        ledger,
        read("ASSISTANT_MAX_TOTAL_USD", PLANNING_CAP_USD),
    )


def make_anthropic(name: str, **options):
    """No retry inside the SDK: each attempt is counted."""
    from assistant.llm_anthropic import AnthropicModel

    return AnthropicModel(name, max_retries=0, **options)


def mission_key(kind: str, text: str) -> str:
    digest = hashlib.sha256(text.encode()).hexdigest()[:8]
    return f"{kind}:{digest}"


def open_model(
    settings, mission: str, max_calls: int
) -> GuardedModel | None:
    """A guarded model, or None after saying why not."""
    lang = settings.lang
    if not settings.allow_live or not settings.model:
        print(t(lang, "live_off"))
        return None
    if not os.getenv("ANTHROPIC_API_KEY"):
        print(t(lang, "no_key"))
        return None
    if settings.model not in PRICE_TIERS:
        print(
            localize(
                lang, f"refused: no price for {settings.model}"
            )
        )
        return None
    policy = policy_from_env(real_ledger())
    return GuardedModel(
        make_anthropic(settings.model),
        policy.guard(mission, max_calls),
    )
