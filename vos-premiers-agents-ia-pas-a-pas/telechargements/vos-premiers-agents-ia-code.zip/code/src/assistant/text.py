"""Text normalization and word splitting (FR, EN, ES, DE)."""

from __future__ import annotations

import re
import unicodedata

STOPWORDS = {
    "fr": set(
        "le la les un une des du de d l et ou a au aux en dans"
        " pour par sur est sont que qui quoi quel quelle quels"
        " quelles ce cette ces se sa son ses il elle ils elles"
        " on nous vous je j ne pas plus avec sans y ete etre"
        " faut combien comment".split()
    ),
    "en": set(
        "the a an and or of to in on for by is are be was what"
        " which who how much many with without it this that"
        " do does".split()
    ),
    "es": set(
        "el la los las un una unos unas de del y o en para por"
        " con sin es son que cual cuales como cuanto cuanta se"
        " su sus al".split()
    ),
    "de": set(
        "der die das den dem des ein eine einen einem einer und"
        " oder in im an am auf fur mit ohne ist sind was wie"
        " viel welche welcher welches zu zum zur es sie wir ich"
        " nicht von vom bei".split()
    ),
}


def normalize(text: str) -> str:
    """Lowercase, accents removed: "Été" -> "ete"."""
    decomposed = unicodedata.normalize("NFKD", text.lower())
    return "".join(
        c for c in decomposed if not unicodedata.combining(c)
    )


def tokenize(text: str, lang: str = "fr") -> list[str]:
    words = re.findall(r"\w+", normalize(text))
    stop = STOPWORDS.get(lang, set())
    return [w for w in words if len(w) > 1 and w not in stop]
