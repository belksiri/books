# SPDX-License-Identifier: MIT
"""Add tools to a toolbox, through public methods only.

`Toolbox` (tools.py) belongs to the frozen experiment of
chapter 9 and does not change. `with_tools` wraps it: the
agent loop only calls `definitions()` and `execute()`, so a
wrapper that offers both is enough. The added tools get the
same treatment as the others (validation, error results,
truncation, shared `consulted`): they live in a small
`Toolbox` of their own.
"""

from __future__ import annotations

from assistant.llm import ToolCall
from assistant.step04.tools import Tool, Toolbox, ToolOutcome


# [snippet:with-tools]
class ExtendedToolbox:
    """A toolbox plus a few tools of yours."""

    def __init__(self, base: Toolbox, extra: list[Tool]):
        known = {d["name"] for d in base.definitions()}
        clash = known & {tool.name for tool in extra}
        if clash:
            raise ValueError(f"tool already exists: {clash}")
        self.consulted = base.consulted
        self.max_chars = base.max_chars
        self._base = base
        self._extra = Toolbox(
            extra, base.consulted, base.max_chars
        )
        self._names = {tool.name for tool in extra}

    def definitions(self) -> list[dict]:
        return (
            self._base.definitions() + self._extra.definitions()
        )

    def execute(self, call: ToolCall) -> ToolOutcome:
        if call.name in self._names:
            return self._extra.execute(call)
        return self._base.execute(call)


def with_tools(base: Toolbox, *tools: Tool) -> ExtendedToolbox:
    """`base` plus `tools`; a name already used is refused."""
    return ExtendedToolbox(base, list(tools))


# [/snippet]
