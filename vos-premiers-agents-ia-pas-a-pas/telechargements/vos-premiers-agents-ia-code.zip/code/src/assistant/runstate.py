"""Run state and limits of one mission (chapter 3)."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field

from assistant.llm import Usage


# [snippet:limits]
@dataclass(frozen=True)
class Limits:
    """Checked BETWEEN steps, never during a model call."""

    max_turns: int = 10  # model calls
    max_seconds: float = 120.0  # wall-clock time of the run
    max_tokens: int = 60_000  # input + output, cumulated
    max_tool_calls: int = 20  # tool executions (chapter 4)


# [/snippet]


# [snippet:run-state]
@dataclass
class RunState:
    limits: Limits
    clock: Callable[[], float] = time.monotonic
    turns: int = 0
    usage: Usage = field(default_factory=Usage)
    events: list[str] = field(default_factory=list)
    started: float = 0.0

    def __post_init__(self):
        self.started = self.clock()

    def log(self, event: str) -> None:
        self.events.append(event)

    def exceeded(self) -> str | None:
        """Name of the limit reached, or None."""
        if self.turns >= self.limits.max_turns:
            return "max_turns"
        if (
            self.clock() - self.started
            > self.limits.max_seconds
        ):
            return "max_seconds"
        if self.usage.total > self.limits.max_tokens:
            return "token_budget"
        return None


# [/snippet]
