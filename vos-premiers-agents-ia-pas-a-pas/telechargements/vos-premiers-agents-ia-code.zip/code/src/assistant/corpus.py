"""Loading the demo document folder.

Document format: a `---` header (key: value), then paragraphs
starting with an identifier such as `[p01]`. Identifiers are
the same in all four languages.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

from assistant.policy import FileAccessPolicy

DOC_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")
PASSAGE = re.compile(r"^\[(p\d{2})\]\s+(.*)$", re.DOTALL)


@dataclass(frozen=True)
class Passage:
    doc_id: str
    pid: str
    text: str

    @property
    def ref(self) -> str:
        return f"{self.doc_id}#{self.pid}"


@dataclass(frozen=True)
class Document:
    id: str
    title: str
    meta: dict[str, str]
    passages: tuple[Passage, ...]


class CorpusError(Exception):
    pass


def parse_document(doc_id: str, raw: str) -> Document:
    parts = raw.split("---", 2)
    if len(parts) != 3 or parts[0].strip():
        raise CorpusError(f"{doc_id}: missing header")
    meta = {}
    for line in parts[1].strip().splitlines():
        key, _, value = line.partition(":")
        meta[key.strip()] = value.strip()
    if meta.get("id") != doc_id:
        raise CorpusError(
            f"{doc_id}: id does not match file name"
        )
    passages, seen = [], set()
    for block in re.split(r"\n\s*\n", parts[2].strip()):
        match = PASSAGE.match(block.strip())
        if not match:
            continue  # heading or text without identifier
        pid, text = match.groups()
        if pid in seen:
            raise CorpusError(f"{doc_id}: duplicate {pid}")
        seen.add(pid)
        text = " ".join(text.split())
        passages.append(Passage(doc_id, pid, text))
    return Document(
        doc_id, meta.get("title", doc_id), meta, tuple(passages)
    )


class Corpus:
    def __init__(self, documents: list[Document], lang: str):
        self.lang = lang
        self._docs = {d.id: d for d in documents}

    @classmethod
    def load(cls, folder: Path, lang: str) -> Corpus:
        policy = FileAccessPolicy(read_roots=[folder])
        documents = []
        for path in sorted(folder.glob("*.md")):
            if not DOC_ID.match(path.stem):
                raise CorpusError(
                    f"invalid file name: {path.name}"
                )
            safe = policy.check_read(path)
            raw = safe.read_text(encoding="utf-8")
            documents.append(parse_document(path.stem, raw))
        return cls(documents, lang)

    @property
    def documents(self) -> list[Document]:
        return list(self._docs.values())

    def digests(self) -> dict[str, str]:
        """doc id -> SHA-256 of what the model can be shown:
        header and passages. Used to detect a changed folder."""
        result = {}
        for doc in self.documents:
            parts = [
                doc.meta,
                [[p.pid, p.text] for p in doc.passages],
            ]
            raw = json.dumps(
                parts, ensure_ascii=False, sort_keys=True
            )
            result[doc.id] = hashlib.sha256(
                raw.encode()
            ).hexdigest()
        return result

    def get(self, doc_id: str) -> Document | None:
        return self._docs.get(doc_id)

    def passage(self, ref: str) -> Passage | None:
        doc_id, _, pid = ref.partition("#")
        doc = self._docs.get(doc_id)
        if doc is None:
            return None
        return next(
            (p for p in doc.passages if p.pid == pid), None
        )

    def all_passages(self) -> list[Passage]:
        return [
            p for d in self._docs.values() for p in d.passages
        ]
