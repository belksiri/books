"""`assistant interface-demo`: the page's logic, in a terminal.

Simulated from start to end, in a temporary folder. It calls the
same functions as the page. It does not start the page.
"""

from __future__ import annotations

import tempfile
import textwrap
from pathlib import Path

from assistant.config import CODE_DIR, Settings
from assistant.messages import localize, localize_preview, t
from assistant.scenarios import BUREAU
from assistant.step07.gate import GateRefused
from assistant.step11.service import (
    SIMULATED,
    SendSetup,
    approve_send,
    first_draft,
    prepare_send,
    run_mode,
    simulated_label,
)

WIDTH = 64
WHO = "Camille"
QUESTIONS = {
    "fr": "Quel est le montant du dépôt de garantie ?",
    "de": "Wie hoch ist die Sicherheitsleistung?",
    "en": "How much is the security deposit?",
    "es": "¿Cuál es el importe del depósito de garantía?",
}


def _show(text: str) -> None:
    for line in text.splitlines():
        print(
            textwrap.fill(line, WIDTH, break_on_hyphens=False)
            or ""
        )


def _mark(lang: str, value: bool | None) -> str:
    if value is None:
        return t(lang, "unknown")
    return t(lang, "yes") if value else t(lang, "no")


def _refused(lang: str, label: str, setup, shown, text) -> None:
    try:
        approve_send(shown, BUREAU, text, WHO, setup)
    except GateRefused as error:
        refused = t(lang, "ui_refused")
        reason = localize(lang, str(error))
        _show(f"{label} -> {refused} ({reason})")


def interface_demo(settings: Settings) -> int:
    lang = settings.lang
    _show(f"({simulated_label(lang)})")
    done = run_mode(
        settings,
        SIMULATED,
        QUESTIONS[lang],
        CODE_DIR / "demo_data" / lang,
        "2026-06-15",
    )
    print(f"--- {t(lang, 'answer')} ---")
    _show(done.answer)
    print(f"--- {t(lang, 'ui_references')} ---")
    cols = t(lang, "cols").split()
    print(f"  {'':<20} {' '.join(cols)}")
    for check in done.checks:
        marks = [
            check.exists,
            check.consulted,
            check.excerpt,
            check.supported,
        ]
        cells = [
            f"{_mark(lang, m):<{len(c)}}"
            for m, c in zip(marks, cols, strict=True)
        ]
        print(f"  {check.ref:<20} " + " ".join(cells).rstrip())
    with tempfile.TemporaryDirectory() as tmp:
        setup = SendSetup(
            {BUREAU},
            Path(tmp) / "outbox",
            Path(tmp) / "actions.jsonl",
        )
        draft = first_draft(done, lang)
        shown = prepare_send(BUREAU, draft, setup.allowed)
        print(f"--- {t(lang, 'ui_preview')} ---")
        _show(localize_preview(lang, shown.text))
        print(f"=== {t(lang, 'ui_approve')} ===")
        _refused(
            lang,
            t(lang, "ui_demo_changed"),
            setup,
            shown,
            draft.replace("150", "100"),
        )
        path = approve_send(shown, BUREAU, draft, WHO, setup)
        label = t(lang, "ui_demo_exact")
        _show(f"{label} -> outbox/{path.name}")
        _refused(
            lang,
            t(lang, "ui_demo_again"),
            setup,
            shown,
            draft,
        )
    return 0
