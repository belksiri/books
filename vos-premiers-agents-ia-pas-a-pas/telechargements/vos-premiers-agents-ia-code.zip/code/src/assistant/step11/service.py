"""Step 11: what the interface does, without the interface.

No Streamlit here: each decision is a plain function, tested
with FakeModel. The page (app.py) only shows and collects.

"Sending" stays what it was in chapter 7: a local file in
outbox/, through SendGate. Nothing leaves the machine.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path

from assistant import paid
from assistant.approval import (
    OutboxSender,
    ProposedAction,
    hidden_characters,
)
from assistant.config import CODE_DIR, LANGS, Settings
from assistant.corpus import Corpus
from assistant.llm import ModelClient, ModelError
from assistant.memory import PERSONAL_DATA
from assistant.messages import t
from assistant.policy import AccessDenied, FileAccessPolicy
from assistant.prompts import load
from assistant.scenarios import BUREAU, deposit_scenario
from assistant.step04.agent import new_state, run
from assistant.step04.tools import build_toolbox
from assistant.step05.bm25 import bm25_search
from assistant.step05.citations import (
    CitationCheck,
    check_citations,
)
from assistant.step07.gate import (
    ActionJournal,
    GateRefused,
    SendGate,
)
from assistant.step10.redact import redact

SIMULATED, REAL = "simulated", "real"
MAX_CALLS = 12
# OutboxSender refuses 20 000 bytes, header included. Checked
# first: a refusal after "intent" would block every sending.
MAX_SEND_BYTES = 19_000
WHO = re.compile(r"[\w .'-]{1,60}")
# Streamlit serves each session from a thread of one process.
# The ledger and the journal check, then write: one at a time.
_ONE_RUN = threading.Lock()
_ONE_SEND = threading.Lock()


class LiveRefused(Exception):
    """The real mode is not available: nothing was called."""


# [snippet:password]
def check_password(given: str, expected: str | None) -> bool:
    """No password set: the door stays closed."""
    if not expected:
        return False
    return hmac.compare_digest(
        given.encode("utf-8"), expected.encode("utf-8")
    )


# [/snippet]


def expected_password() -> str | None:
    return os.getenv("ASSISTANT_UI_PASSWORD") or None


def documents_root() -> Path:
    raw = os.getenv("ASSISTANT_DATA_ROOT")
    return Path(raw) if raw else CODE_DIR / "demo_data"


def list_folders(root: Path) -> list[str]:
    """The folders a person may choose: never a free path."""
    if not root.is_dir():
        return []
    return sorted(
        p.name
        for p in root.iterdir()
        if p.is_dir() and any(p.glob("*.md"))
    )


def open_folder(root: Path, name: str) -> Path:
    """`name` comes from a web page: treat it as untrusted."""
    policy = FileAccessPolicy(read_roots=[root])
    folder = policy.check_read(root / name)
    if folder.parent != root.resolve() or not folder.is_dir():
        raise AccessDenied(f"not a document folder: {name}")
    return folder


def _folder_lang(folder: Path, lang: str) -> str:
    """A folder named fr, en, es or de says its language."""
    return folder.name if folder.name in LANGS else lang


# [snippet:answered]
@dataclass
class Answered:
    status: str
    answer: str
    checks: list[CitationCheck]
    passages: dict[str, str]  # ref -> text, to show it
    simulated: bool
    turns: int = 0
    tokens: tuple[int, int] = (0, 0)
    detail: str = ""  # why it stopped
    problems: int = field(init=False)

    def __post_init__(self) -> None:
        self.problems = sum(
            1 for c in self.checks if not _passes(c)
        )


def _passes(check: CitationCheck) -> bool:
    # An excerpt left unchecked (None) does not pass.
    return bool(
        check.exists and check.consulted and check.excerpt
    )


# [/snippet]


# [snippet:ask]
def ask(
    model: ModelClient,
    question: str,
    folder: Path,
    lang: str,
    today: str,
    simulated: bool,
) -> Answered:
    """One question, read-only tools, references checked."""
    corpus = Corpus.load(folder, _folder_lang(folder, lang))
    state = new_state()
    box = build_toolbox(
        corpus, None, state.consulted, search=bm25_search
    )
    system = load("step04", lang, today=today)
    detail = ""
    try:
        with _ONE_RUN:
            result = run(model, system, question, box, state)
        status, text = result.status, result.answer
    except ModelError as error:
        status, text = "model_error", ""
        detail = redact(str(error))
    checks = check_citations(text, corpus, state.consulted)
    shown = {
        c.ref: found.text
        for c in checks
        if (found := corpus.passage(c.ref))
    }
    usage = state.usage
    return Answered(
        status,
        text,
        checks,
        shown,
        simulated,
        state.turns,
        (usage.input_tokens, usage.output_tokens),
        detail,
    )


# [/snippet]


def available_modes(settings: Settings) -> list[str]:
    """Simulated comes first: it is the default of the page."""
    if settings.allow_live:
        return [SIMULATED, REAL]
    return [SIMULATED]


# [snippet:real-door]
def open_real(settings: Settings, question: str):
    """Real mode: the project's only door, and no other."""
    if not settings.allow_live:
        raise LiveRefused("ASSISTANT_ALLOW_LIVE is not 1")
    model = paid.open_model(
        settings, paid.mission_key("ui", question), MAX_CALLS
    )
    if model is None:  # no model, key or known price
        raise LiveRefused("see the server log")
    return model


# [/snippet]


def run_mode(
    settings: Settings,
    mode: str,
    question: str,
    folder: Path,
    today: str,
    log: Path | None = None,
) -> Answered:
    if mode == SIMULATED:
        model = deposit_scenario(
            _folder_lang(folder, settings.lang)
        )
    elif mode == REAL:
        model = open_real(settings, question)
    else:
        raise ValueError(f"unknown mode: {mode}")
    answered = ask(
        model,
        question,
        folder,
        settings.lang,
        today,
        mode == SIMULATED,
    )
    if log is not None:
        log_run(log, question, answered, mode)
    return answered


def run_log_path(settings: Settings) -> Path:
    return settings.journal_path.with_name("interface.jsonl")


# [snippet:log-run]
def log_run(
    path: Path, question: str, done: Answered, mode: str
) -> None:
    """Numbers and a digest: no question, no answer."""
    digest = hashlib.sha256(question.encode()).hexdigest()
    ActionJournal(path).add(
        "ask",
        digest[:16],
        mode=mode,
        status=done.status,
        turns=done.turns,
        input=done.tokens[0],
        output=done.tokens[1],
        references=len(done.checks),
        problems=done.problems,
    )


# [/snippet]


def simulated_label(lang: str) -> str:
    return t(lang, "ui_simulated")


def first_draft(done: Answered, lang: str) -> str:
    """A simulated text stays marked, even once it is a file."""
    if done.simulated:
        tag = t(lang, "ui_simulated_tag")
        return f"[{tag}]\n\n{done.answer}"
    return done.answer


@dataclass(frozen=True)
class SendSetup:
    allowed: set[str]
    outbox: Path
    journal: Path


def send_setup(
    settings: Settings, simulated: bool
) -> SendSetup:
    """Simulated texts never mix with the real outbox/."""
    if simulated:
        return SendSetup(
            {BUREAU},
            settings.outbox_dir / "simulated",
            settings.journal_path.with_name(
                "actions-simulated.jsonl"
            ),
        )
    return SendSetup(
        settings.allowed_targets,
        settings.outbox_dir,
        settings.journal_path,
    )


@dataclass(frozen=True)
class SendPreview:
    target: str
    content: str
    text: str  # exactly what the person is shown
    refusal: str | None
    personal_data: bool


def prepare_send(
    target: str, content: str, allowed: set[str]
) -> SendPreview:
    """Shows and warns, decides nothing: SendGate does."""
    action = ProposedAction("send_summary", target, content)
    refusal = None
    hidden = hidden_characters(content)
    if target not in allowed:
        refusal = f"recipient not allowed: {target}"
    elif hidden:
        refusal = f"hidden characters: {' '.join(hidden[:5])}"
    elif len(content.encode("utf-8")) > MAX_SEND_BYTES:
        refusal = "content too large"
    return SendPreview(
        target,
        content,
        action.preview(),
        refusal,
        any(p.search(content) for p in PERSONAL_DATA),
    )


# [snippet:approve]
def approve_send(
    shown: SendPreview,
    target: str,
    content: str,
    who: str,
    setup: SendSetup,
) -> Path:
    """The button approves what was shown, nothing else."""
    if not WHO.fullmatch(who.strip()):
        raise GateRefused("a name is required to approve")
    if len(content.encode("utf-8")) > MAX_SEND_BYTES:
        raise GateRefused("content too large")
    journal = ActionJournal(setup.journal)
    action = ProposedAction("send_summary", target, content)
    if action.preview() != shown.text:
        journal.add(
            "refused", action.digest(), why="not the preview"
        )
        raise GateRefused("text changed since the preview")

    def person_saw(preview: str) -> bool:
        # The gate may put a warning before the same preview.
        return preview.endswith(shown.text)

    gate = SendGate(
        setup.allowed,
        person_saw,
        who.strip(),
        OutboxSender(setup.outbox),
        journal,
    )
    with _ONE_SEND:
        return gate.submit(target, content)


# [/snippet]
