"""Step 11: the page. Widgets only: each decision is taken in
service.py, where tests reach it without Streamlit.

    uv run --extra interface streamlit run \
        src/assistant/step11/app.py \
        --server.address 127.0.0.1 \
        --server.headless true \
        --browser.gatherUsageStats false \
        --client.toolbarMode minimal

Streamlit runs this whole file again at every click. What must
survive goes into st.session_state; a model call stays under
`if st.button(...)`, so that it happens once.
"""

from __future__ import annotations

from datetime import date

import streamlit as st

from assistant.config import Settings, load_settings
from assistant.corpus import CorpusError
from assistant.messages import localize, localize_preview, t
from assistant.policy import AccessDenied
from assistant.step07.gate import GateRefused, UnknownOutcome
from assistant.step11 import service


# [snippet:gate-page]
def unlocked(lang: str) -> bool:
    if st.session_state.get("unlocked"):
        return True
    expected = service.expected_password()
    if not expected:
        st.error(t(lang, "ui_no_password"))
        return False
    st.caption(t(lang, "ui_limits"))
    # A form, so that the Enter key submits as well.
    with st.form("login"):
        given = st.text_input(
            t(lang, "ui_password"), type="password", key="given"
        )
        sent = st.form_submit_button(
            t(lang, "ui_unlock"), key="unlock"
        )
    if sent:
        if service.check_password(given, expected):
            st.session_state["unlocked"] = True
            st.rerun()
        st.error(t(lang, "ui_wrong_password"))
    return False


# [/snippet]


def ask_section(settings: Settings) -> None:
    lang = settings.lang
    root = service.documents_root()
    folders = service.list_folders(root)
    if not folders:
        st.error(t(lang, "ui_no_folder"))
        return
    labels = {
        service.SIMULATED: t(lang, "ui_mode_simulated"),
        service.REAL: t(lang, "ui_mode_real"),
    }
    modes = service.available_modes(settings)
    mode = st.radio(
        t(lang, "ui_mode"),
        modes,
        index=0,
        format_func=labels.get,
        key="mode",
    )
    if mode == service.REAL:
        st.warning(t(lang, "ui_real_on"))
    elif service.REAL not in modes:
        st.caption(t(lang, "ui_real_off"))
    start = folders.index(lang) if lang in folders else 0
    name = st.selectbox(
        t(lang, "ui_folder"), folders, index=start, key="folder"
    )
    question = st.text_area(
        t(lang, "ui_question"), max_chars=2000, key="question"
    )
    clicked = st.button(t(lang, "ui_ask"), key="ask")
    if not (clicked and question.strip()):
        return
    try:
        # Found on a real run: without it, nothing moves for
        # several seconds after the click.
        with st.spinner(t(lang, "ui_waiting")):
            done = service.run_mode(
                settings,
                mode,
                question,
                service.open_folder(root, name),
                date.today().isoformat(),
                service.run_log_path(settings),
            )
    except service.LiveRefused:
        st.error(t(lang, "ui_live_refused"))
        return
    except (AccessDenied, CorpusError) as error:
        st.error(t(lang, "ui_refused"))
        st.text(localize(lang, str(error)))
        return
    st.session_state["answered"] = done
    st.session_state["draft"] = service.first_draft(done, lang)
    st.session_state.pop("shown", None)
    st.session_state.pop("sent", None)


# [snippet:answer-view]
def answer_section(done: service.Answered, lang: str) -> None:
    if done.simulated:
        st.warning(service.simulated_label(lang))
    if done.detail or not done.answer:
        st.error(t(lang, "ui_stopped"))
        if done.detail:
            st.text(localize(lang, done.detail))
        st.caption(done.status)  # an identifier, not a sentence
        return
    # Plain text on purpose: as Markdown, a link or an image
    # dictated by a document would come alive in the browser.
    st.code(done.answer, language=None, wrap_lines=True)
    st.subheader(t(lang, "ui_references"))
    st.caption(t(lang, "ui_refs_note"))
    if not done.checks:
        st.warning(t(lang, "ui_no_refs"))
    cols = t(lang, "cols").split()[:3]
    for check in done.checks:
        marks = (check.exists, check.consulted, check.excerpt)
        title = " · ".join(
            f"{c} {t(lang, 'yes' if m else 'no')}"
            for c, m in zip(cols, marks, strict=True)
        )
        with st.expander(f"{check.ref} · {title}"):
            st.text(f"{check.doc_date} {check.doc_status}")
            st.code(
                done.passages.get(check.ref, "-"),
                language=None,
                wrap_lines=True,
            )


# [/snippet]


def send_section(settings: Settings, done, lang: str) -> None:
    setup = service.send_setup(settings, done.simulated)
    st.subheader(t(lang, "ui_send_title"))
    if not setup.allowed:
        st.info(t(lang, "ui_no_target"))
        return
    target = st.selectbox(
        t(lang, "ui_target"),
        sorted(setup.allowed),
        key="target",
    )
    who = st.text_input(t(lang, "ui_who"), key="who")
    content = st.text_area(
        t(lang, "ui_draft"), height=220, key="draft"
    )
    if st.button(t(lang, "ui_prepare"), key="prepare"):
        st.session_state["shown"] = service.prepare_send(
            target, content, setup.allowed
        )
        st.session_state.pop("sent", None)
    if "sent" in st.session_state:
        st.success(t(lang, "ui_sent"))
        st.code(st.session_state["sent"], language=None)
    shown = st.session_state.get("shown")
    if shown is None:
        return
    if shown.refusal:
        st.error(t(lang, "ui_refused"))
        st.text(localize(lang, shown.refusal))
        return
    st.caption(t(lang, "ui_preview"))
    if shown.personal_data:
        st.warning(t(lang, "ui_personal"))
    st.code(
        localize_preview(lang, shown.text),
        language=None,
        wrap_lines=True,
    )
    if (target, content) != (shown.target, shown.content):
        st.info(t(lang, "ui_changed"))
        return
    if not st.button(t(lang, "ui_approve"), key="approve"):
        return
    try:
        path = service.approve_send(
            shown, target, content, who, setup
        )
    except UnknownOutcome:
        st.error(t(lang, "ui_unknown_outcome"))
    except GateRefused as error:
        st.error(t(lang, "ui_refused"))
        st.text(localize(lang, str(error)))
    else:
        st.session_state["sent"] = str(path)
        del st.session_state["shown"]
        st.rerun()


def main() -> None:
    settings = load_settings()
    lang = settings.lang
    st.set_page_config(page_title=t(lang, "ui_title"))
    st.title(t(lang, "ui_title"))
    if not unlocked(lang):
        return
    ask_section(settings)
    done = st.session_state.get("answered")
    if done is not None:
        answer_section(done, lang)
        if done.answer:
            send_section(settings, done, lang)


if __name__ == "__main__":
    main()
