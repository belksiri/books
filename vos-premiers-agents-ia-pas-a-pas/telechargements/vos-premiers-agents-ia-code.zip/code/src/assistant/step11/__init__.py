"""Step 11: an interface for the assistant."""
