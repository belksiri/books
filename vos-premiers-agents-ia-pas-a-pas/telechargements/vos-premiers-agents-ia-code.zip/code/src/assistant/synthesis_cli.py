"""Commands of chapter 6: synthesis (paid) and synthesis-demo.

Both share the same steps: get a plan (or resume a saved
mission), run the steps, then assemble and check.
"""

from __future__ import annotations

import hashlib
import tempfile
import textwrap
from pathlib import Path

from assistant.approval import OutboxSender, ask_person
from assistant.config import CODE_DIR
from assistant.corpus import Corpus, CorpusError
from assistant.messages import (
    localize,
    localize_preview,
    t,
)
from assistant.scenarios import (
    SYNTHESIS_TEXT,
    synthesis_session1,
    synthesis_session2,
)
from assistant.step06.mission import (
    MissionState,
    MissionStore,
    StepResult,
    corpus_changes,
    run_mission,
)
from assistant.step06.plan import (
    Plan,
    PlanRefused,
    fixed_plan,
    propose_plan,
)
from assistant.step06.verify import assemble, review, run_checks
from assistant.step07.gate import (
    ActionJournal,
    GateRefused,
    SendGate,
)
from assistant.step07.retry import RetryingModel

WIDTH = 64
QUOTES = {
    "fr": ("« ", " »"),
    "en": ('"', '"'),
    "es": ("«", "»"),
    "de": ("„", "“"),
}


def _c(lang: str) -> str:
    return "\u00a0: " if lang == "fr" else ": "


def _cut(line: str) -> str:
    return (
        line if len(line) <= WIDTH else line[: WIDTH - 1] + "…"
    )


def mission_id(
    question: str, lang: str, folder: str = ""
) -> str:
    digest = hashlib.sha256(
        f"{lang}:{folder}:{question}".encode()
    )
    return "m-" + digest.hexdigest()[:8]


def open_corpus(
    lang: str, dossier: str | None, corpus_lang: str | None
) -> tuple[Corpus, str] | None:
    """The documents to analyse, chosen independently of the
    interface language `lang`. None: nothing usable there."""
    words = corpus_lang or lang  # for the search stop words
    folder = Path(
        dossier or CODE_DIR / "demo_data" / words
    ).resolve()
    try:
        corpus = Corpus.load(folder, words)
    except (CorpusError, OSError) as error:
        print(
            f"{t(lang, 'no_docs')}{_c(lang)}"
            f"{localize(lang, str(error))}"
        )
        return None
    if not corpus.documents:
        print(f"{t(lang, 'no_docs')}{_c(lang)}{folder}")
        return None
    return corpus, str(folder)


def start_or_resume(
    model,
    store,
    mid,
    question,
    lang,
    today,
    plan_kind,
    folder="",
    corpus_lang="",
    digests=None,
    restart=False,
) -> MissionState | None:
    state = None if restart else store.load(mid)
    if state is not None:
        if state.folder != folder:
            # Its traces and references belong to other files.
            label = t(lang, "other_folder")
            print(f"{label}{_c(lang)}{state.folder}")
            return None
        changed = corpus_changes(
            state.doc_digests, digests or {}
        )
        if changed:
            # Finished steps may rest on text that no longer
            # exists: no partial reuse, the person decides.
            label = t(lang, "corpus_changed")
            print(_cut(f"{label}{_c(lang)}{' '.join(changed)}"))
            print(t(lang, "use_restart"))
            return None
        done = [
            s.id
            for s in state.plan.steps
            if s.id not in {x.id for x in state.todo()}
        ]
        print(f"{t(lang, 'resumed')}{_c(lang)}{' '.join(done)}")
        return state
    if plan_kind == "fixed":
        plan = fixed_plan(question[:120], question[:80], lang)
    else:
        try:
            plan = propose_plan(model, question, lang)
        except PlanRefused as error:
            print(
                f"{t(lang, 'plan_refused')}{_c(lang)}"
                f"{localize(lang, str(error))}"
            )
            return None
        print(f"{t(lang, 'plan_ok')}{_c(lang).rstrip()}")
    _print_plan(plan)
    state = MissionState(
        mission_id=mid,
        question=question,
        lang=lang,
        today=today,
        plan=plan,
        folder=folder,
        corpus_lang=corpus_lang,
        doc_digests=digests or {},
    )
    store.save(state)
    return state


def _print_plan(plan: Plan) -> None:
    for step in plan.steps:
        print(_cut(f"  {step.id} {step.goal} [{step.query}]"))


def execute(model, state, corpus, store, lang) -> str:
    def on_step(step, result: StepResult) -> None:
        line = f"{step.id}{_c(lang)}{result.status}"
        if result.status != "done":
            line += f" ({localize(lang, result.answer)})"
        print(_cut(line))

    status = run_mission(
        model, state, corpus, store, on_step=on_step
    )
    if status == "done":
        print(t(lang, "mission_done"))
    else:
        print(t(lang, "interrupted"))
        print(
            f"{t(lang, 'saved')}{_c(lang)}"
            f"missions/{state.mission_id}.json"
        )
    return status


def finish(
    model, state, corpus, lang, simulated: bool = False
) -> tuple[str, str]:
    """Assemble, run the code checks, then the review.

    Returns (synthesis, report). On screen, the synthesis is
    shown without its blank lines.
    """
    synthesis = assemble(state)
    print(f"--- {t(lang, 'synthesis')} ---")
    for line in synthesis.splitlines():
        if line.startswith("- ["):  # a source line
            print(_cut(line))
        elif line:
            print(
                textwrap.fill(
                    line, WIDTH, break_on_hyphens=False
                )
            )
    print("---")
    report = [f"{t(lang, 'code_checks')}{_c(lang).rstrip()}"]
    for check in run_checks(state, corpus):
        mark = t(lang, "yes") if check.ok else t(lang, "no")
        line = f"  {check.name:<17} {mark} {check.detail}"
        report.append(_cut(line.rstrip()))
    title = t(lang, "review_demo" if simulated else "review")
    report.append(f"{title}{_c(lang).rstrip()}")
    opinion = review(model, state, corpus)
    if opinion is None:
        report.append(f"  {t(lang, 'no_review')}")
    elif not opinion.issues:
        report.append(f"  {t(lang, 'no_issue')}")
    left, right = QUOTES[lang]
    for issue in opinion.issues if opinion else []:
        report.append(
            _cut(f"  {issue.step} {left}{issue.claim}{right}")
        )
        for line in textwrap.wrap(issue.problem, WIDTH - 5):
            report.append(f"     {line}")
    print("\n".join(report))
    return synthesis, "\n".join(report) + "\n"


def synthesis_demo(lang: str, corpus: Corpus) -> int:
    """Session 1 is interrupted; session 2 resumes it."""
    print(f"({t(lang, 'simulated')})")
    text = SYNTHESIS_TEXT[lang]
    with tempfile.TemporaryDirectory() as tmp:
        store = MissionStore(Path(tmp) / "missions")
        sessions = [synthesis_session1, synthesis_session2]
        for number, script in enumerate(sessions, start=1):
            print(f"=== {t(lang, 'session')} {number} ===")
            model = script(lang, corpus)
            state = start_or_resume(
                model,
                store,
                "demo-ch06",
                text["question"],
                lang,
                "2026-06-15",
                "model",
                digests=corpus.digests(),
            )
            status = execute(model, state, corpus, store, lang)
        if status == "done":
            finish(model, state, corpus, lang, simulated=True)
    return 0


def run_synthesis(
    model,
    store,
    opened,
    question,
    lang,
    today,
    plan_kind,
    mid,
    gate=None,
    send_to=None,
    restart=False,
) -> int:
    """Plan or resume, run, then assemble, check and write.

    The sending, if asked, comes last, outside any step: only
    if the code checks pass, and through the gate (chapter 7).
    """
    corpus, folder = opened
    state = start_or_resume(
        model,
        store,
        mid or mission_id(question, lang, folder),
        question,
        lang,
        today,
        plan_kind,
        folder,
        corpus.lang,
        corpus.digests(),
        restart,
    )
    if state is None:
        return 3
    if execute(model, state, corpus, store, lang) != "done":
        return 4
    synthesis, report = finish(model, state, corpus, lang)
    store.write(f"{state.mission_id}.md", synthesis)
    store.write(f"{state.mission_id}-report.txt", report)
    if not send_to:
        return 0
    if not all(c.ok for c in run_checks(state, corpus)):
        print(t(lang, "checks_failed"))
        return 5
    try:
        print(gate.submit(send_to, synthesis).name)
    except GateRefused as error:
        print(
            f"{t(lang, 'not_sent')}{_c(lang)}"
            f"{localize(lang, str(error))}"
        )
        return 6
    return 0


def synthesis_live(settings, args) -> int:
    """Real run (paid): only with ASSISTANT_ALLOW_LIVE=1."""
    import os

    from assistant.llm import ModelError
    from assistant.paid import open_model

    lang = settings.lang
    opened = None
    if settings.allow_live and settings.model:
        opened = open_corpus(
            lang, args.dossier, args.corpus_lang
        )
        if opened is None:
            return 3
    mid = args.mission or mission_id(
        args.question, lang, opened[1] if opened else ""
    )
    guarded = open_model(settings, f"mission:{mid}", 40)
    if guarded is None:
        return 2
    # Retries outside the guard: each attempt is counted.
    model = RetryingModel(guarded)
    gate = SendGate(
        settings.allowed_targets,
        lambda p: ask_person(
            localize_preview(lang, p), t(lang, "approve_q")
        ),
        os.getenv("USER", "unknown"),
        OutboxSender(settings.outbox_dir),
        ActionJournal(settings.journal_path),
    )
    store = MissionStore(CODE_DIR / "workspace" / "missions")
    try:
        return run_synthesis(
            model,
            store,
            opened,
            args.question,
            lang,
            args.date,
            args.plan,
            mid,
            gate,
            args.send_to,
            args.restart,
        )
    except ModelError as error:
        print(localize(lang, f"stop: {error}"))
        return 3
