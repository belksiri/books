"""Indicative prices, to bound and estimate the cost of runs.

These values change: use them for estimates and caps only.
Source: https://platform.claude.com/docs/en/about-claude/pricing
Checked on 2026-11-05. US dollars per million tokens (input,
output), standard rate, no cache, no batch.
"""

from __future__ import annotations

from assistant.llm import Usage

CHECKED_ON = "2026-11-05"
SOURCE = (
    "https://platform.claude.com/docs/en/about-claude/pricing"
)

# (max input tokens for this rate, input price, output price)
PRICE_TIERS: dict[
    str, list[tuple[int | None, float, float]]
] = {
    "claude-haiku-5-5": [
        (100_000, 0.10, 0.50),
        (None, 0.50, 2.50),
    ],
    "claude-sonnet-5-5": [(None, 2.00, 10.00)],
    "claude-opus-5-5": [(None, 4.00, 20.00)],
}
PRICES_USD_PER_MTOK = PRICE_TIERS  # kept for older imports


def prices(
    model: str, input_tokens: int
) -> tuple[float, float]:
    """Prices of one request, given its input size."""
    for limit, price_in, price_out in PRICE_TIERS[model]:
        if limit is None or input_tokens <= limit:
            return price_in, price_out
    raise ValueError("no matching tier")


def request_cost(model: str, usage: Usage) -> float:
    """Cost of ONE request (tiers depend on its input size)."""
    price_in, price_out = prices(model, usage.input_tokens)
    return (
        usage.input_tokens * price_in
        + usage.output_tokens * price_out
    ) / 1_000_000


def estimate_cost(model: str, usage: Usage) -> float | None:
    """Rough cost of cumulated usage (base tier), or None."""
    if model not in PRICE_TIERS:
        return None
    _, price_in, price_out = PRICE_TIERS[model][0]
    return (
        usage.input_tokens * price_in
        + usage.output_tokens * price_out
    ) / 1_000_000
