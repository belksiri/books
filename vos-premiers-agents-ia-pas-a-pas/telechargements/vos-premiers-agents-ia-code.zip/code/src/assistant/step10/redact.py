"""Step 10: what must not stay in a log, and for how long.

Masking is a safety net, not a guarantee: patterns miss things.
The first protection is to write less: an action journal holds
digests, not contents (chapter 7).
"""

from __future__ import annotations

import re
from datetime import date, timedelta
from pathlib import Path

from assistant.memory import PERSONAL_DATA

# [snippet:redact]
SECRETS = [
    re.compile(r"sk-ant-[\w-]+"),
    re.compile(r"(ANTHROPIC_API_KEY\s*=\s*)\S+"),
    re.compile(r"(?i)(authorization:\s*|x-api-key:\s*)\S+"),
]


def redact(text: str) -> str:
    for pattern in SECRETS:
        text = pattern.sub(
            lambda m: (
                (m.group(1) if m.groups() else "") + "[secret]"
            ),
            text,
        )
    for pattern in PERSONAL_DATA:
        text = pattern.sub("[personal]", text)
    return text


# [/snippet]


# [snippet:retention]
def expired(
    folder: Path, today: date, keep_days: int = 30
) -> list[Path]:
    """Dated logs (`2026-06-15.log`) past their retention. The
    caller decides: nothing is deleted here. The action journal
    is not in this format: it has its own rule (chapter 7)."""
    limit = today - timedelta(days=keep_days)
    found = []
    for path in sorted(folder.glob("*.log")):
        try:
            day = date.fromisoformat(path.stem)
        except ValueError:
            continue  # not a dated log: never touched
        if day < limit:
            found.append(path)
    return found


# [/snippet]
