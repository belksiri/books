"""Step 10: limits per call, per mission and per day.

They become one figure for the guard of chapter 7, which refuses
a call whose maximal cost would pass it. The ledger is the only
count, kept between runs: stopping and starting again gives no
new room. A limit on what the program computes: not the invoice.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from assistant.budget import (
    PLANNING_CAP_USD,
    Ledger,
    SpendGuard,
)


# [snippet:budget-policy]
@dataclass
class BudgetPolicy:
    per_call_usd: float
    per_mission_usd: float
    per_day_usd: float
    ledger: Ledger
    total_usd: float = PLANNING_CAP_USD

    def spent_today(self, today: str) -> float:
        return sum(
            r["charged_usd"]
            for r in self.ledger.records
            if r["time"].startswith(today)
        )

    def spent_on(self, mission: str) -> float:
        return sum(
            r["charged_usd"]
            for r in self.ledger.records
            if r["phase"] == mission
            or r["phase"].startswith(f"{mission}:")
        )

    def room(self, mission: str, today: str = "") -> float:
        """What this mission may still spend, here and now."""
        today = today or datetime.now(UTC).date().isoformat()
        self.ledger.refresh()
        return max(
            0.0,
            min(
                self.per_mission_usd - self.spent_on(mission),
                self.per_day_usd - self.spent_today(today),
                self.total_usd - self.ledger.charged_usd,
            ),
        )

    def guard(
        self, mission: str, max_calls: int, today: str = ""
    ) -> SpendGuard:
        return SpendGuard(
            self.ledger.charged_usd + self.room(mission, today),
            max_calls,
            ledger=self.ledger,
            phase=mission,
            max_call_usd=self.per_call_usd,
        )


# [/snippet]
