"""Step 10: a cost report per mission, from the ledger.

Tokens come from the service. Dollars are computed at published
prices: an estimate to compare runs, not the invoice. A failed
attempt counts at its maximum, its real billing being unknown.
"""

from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path

from assistant.budget import GuardedModel, Ledger
from assistant.corpus import Corpus
from assistant.messages import t


# [snippet:cost-report]
@dataclass
class MissionCost:
    attempts: int = 0
    failed: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    usd: float = 0.0


def cost_report(records: list[dict]) -> dict[str, MissionCost]:
    report: dict[str, MissionCost] = {}
    for record in records:
        line = report.setdefault(record["phase"], MissionCost())
        line.attempts += 1
        line.usd += record["charged_usd"]
        if record["status"] == "ok":
            line.input_tokens += record["input"]
            line.output_tokens += record["output"]
        else:
            line.failed += 1
    return report


# [/snippet]


def print_report(
    report: dict[str, MissionCost], lang: str
) -> None:
    if not report:
        print(t(lang, "costs_empty"))
        return
    print(t(lang, "costs_head"))
    total = 0.0
    for name, line in report.items():
        tokens = f"{line.input_tokens}/{line.output_tokens}"
        print(
            f"  {name}: {line.attempts}, {line.failed}, "
            f"{tokens}, {line.usd:.4f}"
        )
        total += line.usd
    print(f"{t(lang, 'costs_total')}: {total:.4f}")
    print(_wrapped(t(lang, "costs_note")))


def _wrapped(text: str) -> str:
    import textwrap

    return textwrap.fill(text, 64, break_on_hyphens=False)


def costs_demo(lang: str, corpus: Corpus) -> int:
    """A simulated ledger: usage estimated from the characters
    of hand-written replies, one failed attempt written by
    hand. It shows the report, and measures nothing."""
    from assistant.budget import SpendGuard
    from assistant.llm import FakeModel, ModelError
    from assistant.scenarios import (
        deposit_scenario,
        team_full_run,
    )
    from assistant.step04.agent import new_state, run
    from assistant.step04.tools import build_toolbox
    from assistant.step05.bm25 import bm25_search
    from assistant.step08.orchestrator import run_team

    print(f"({t(lang, 'simulated')})")
    today = "2026-06-15"

    def guarded(script, phase: str, ledger: Ledger):
        script.name = "claude-haiku-5-5"
        guard = SpendGuard(1.0, 30, ledger=ledger, phase=phase)
        return GuardedModel(script, guard)

    def agent(model) -> None:
        from assistant.prompts import load

        state = new_state()
        box = build_toolbox(
            corpus, None, state.consulted, search=bm25_search
        )
        system = load("step04", lang, today=today)
        run(model, system, _QUESTIONS[lang], box, state)

    with tempfile.TemporaryDirectory() as tmp:
        ledger = Ledger(Path(tmp) / "ledger.jsonl")
        agent(guarded(deposit_scenario(lang), "agent", ledger))
        run_team(
            guarded(
                team_full_run(lang, corpus), "team", ledger
            ),
            _QUESTIONS[lang],
            corpus,
            lang,
            today,
        )
        down = FakeModel(
            [ModelError("timeout (simulated)", True)]
        )
        try:
            agent(guarded(down, "failed", ledger))
        except ModelError:
            pass
        print_report(cost_report(ledger.records), lang)
    return 0


_QUESTIONS = {
    "fr": "Quel est le montant du dépôt de garantie ?",
    "de": "Wie hoch ist die Sicherheitsleistung?",
    "en": "How much is the security deposit?",
    "es": "¿Cuál es el importe del depósito de garantía?",
}

__all__ = [
    "MissionCost",
    "cost_report",
    "costs_demo",
    "print_report",
]
