"""Step 10: each use of the agent gets the fewest tools.

A tool has one level. A use allows some levels. A tool unknown
to this table is refused: adding a tool forces a decision.
"""

from __future__ import annotations

# [snippet:levels]
TOOL_LEVEL = {
    "list_documents": "read",
    "search_documents": "read",
    "read_document": "read",
    "submit_brief": "hand_over",
    "submit_review": "hand_over",
    "save_note": "write_local",
    "remember": "write_local",
    "forget": "write_local",
    "send_message": "send",
}
ALLOWED = {
    "mission_step": {"read"},
    "team_role": {"read", "hand_over"},
    "assistant": {"read", "write_local"},
    "sender": {"read", "send"},
}


def excess_tools(tools: list[str], use: str) -> list[str]:
    """The tools this use should not have."""
    allowed = ALLOWED[use]
    return [
        name
        for name in tools
        if TOOL_LEVEL.get(name, "unknown") not in allowed
    ]


# [/snippet]
