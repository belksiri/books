"""Step 10: permissions, logs, budgets and cost reports."""
