"""Step 03: one document, loaded whole, in the instructions."""

from __future__ import annotations

from pathlib import Path

from assistant.prompts import load


# [snippet:load-whole]
def system_with_document(path: Path, lang: str = "fr") -> str:
    """The whole file goes to the model, at every call."""
    document = path.read_text("utf-8")
    return load("step03", lang, document=document)


# [/snippet]
