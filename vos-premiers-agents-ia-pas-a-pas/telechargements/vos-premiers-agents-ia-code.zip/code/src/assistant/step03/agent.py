"""Step 03: a first agent loop, without tools yet.

The loop already has its stopping conditions: final answer,
turn limit, time limit and token budget.
"""

from __future__ import annotations

from dataclasses import dataclass

from assistant.llm import ModelClient
from assistant.runstate import Limits, RunState

CONTINUE = (
    "Your reply was cut off. Write only what comes next, from "
    "the next word. Do not repeat anything."
)


@dataclass
class RunResult:
    status: str  # "done", a limit name, or "stopped:<reason>"
    answer: str
    state: RunState


# [snippet:loop]
def run(
    model: ModelClient,
    system: str,
    question: str,
    limits: Limits | None = None,
    state: RunState | None = None,
) -> RunResult:
    state = state or RunState(limits or Limits())
    messages = [{"role": "user", "content": question}]
    parts: list[str] = []
    while True:
        reason = state.exceeded()
        if reason:
            return RunResult(reason, "".join(parts), state)
        reply = model.complete(system, messages)
        state.turns += 1
        state.usage += reply.usage
        state.log(f"turn {state.turns}: {reply.stop_reason}")
        messages.append(
            {"role": "assistant", "content": reply.content}
        )
        parts.append(reply.text)
        if reply.stop_reason == "end_turn":
            return RunResult("done", "".join(parts), state)
        if reply.stop_reason == "max_tokens":
            # Truncated answer: ask for the rest, within limits.
            messages.append(
                {"role": "user", "content": CONTINUE}
            )
            continue
        status = f"stopped:{reply.stop_reason}"
        return RunResult(status, "".join(parts), state)


# [/snippet]
