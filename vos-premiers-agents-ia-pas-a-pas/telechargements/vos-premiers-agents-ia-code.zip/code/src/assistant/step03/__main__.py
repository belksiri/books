"""Demo of step 03: a scripted model, no key and no cost.

    uv run python -m assistant.step03

The replies are written by hand: this exercises the loop, its
stops and its log. It says nothing about a real model.
"""

from __future__ import annotations

from assistant.config import CODE_DIR, load_settings
from assistant.llm import FakeModel
from assistant.messages import localize
from assistant.runstate import Limits
from assistant.step03.agent import run
from assistant.step03.document import system_with_document

TEXT = {
    "fr": {
        "question": (
            "Une location annulée 3 jours avant, remboursée ?"
        ),
        "whole": "Oui, à 40 % [p03].",
        "start": "Oui, à ",
        "rest": "40 % [p03].",
        "banner": "SIMULÉ : réponses écrites à la main.",
        "size": "Instructions et document : {} signes",
        "s1": "Une réponse complète",
        "s2": "Une réponse coupée, puis sa suite",
        "s3": (
            "Une réponse toujours coupée, trois tours au plus"
        ),
        "status": "statut : ",
        "answer": "réponse : ",
        "sizes": "messages envoyés à chaque appel : ",
        "tokens": "jetons (estimés) : ",
        "log": "journal :",
    },
    "en": {
        "question": (
            "A rental cancelled 3 days before: refunded?"
        ),
        "whole": "Yes, at 40% [p03].",
        "start": "Yes, at ",
        "rest": "40% [p03].",
        "banner": "SIMULATED: replies written by hand.",
        "size": "Instructions and document: {} characters",
        "s1": "A complete answer",
        "s2": "A cut answer, then the rest of it",
        "s3": "An answer always cut, three turns at most",
        "status": "status: ",
        "answer": "answer: ",
        "sizes": "messages sent at each call: ",
        "tokens": "tokens (estimated): ",
        "log": "log:",
    },
    "es": {
        "question": (
            "¿Alquiler cancelado 3 días antes, reembolsado?"
        ),
        "whole": "Sí, al 40 % [p03].",
        "start": "Sí, al ",
        "rest": "40 % [p03].",
        "banner": "SIMULADO: respuestas escritas a mano.",
        "size": "Instrucciones y documento: {} caracteres",
        "s1": "Una respuesta completa",
        "s2": "Una respuesta cortada y luego su continuación",
        "s3": ("Respuesta siempre cortada, máximo tres turnos"),
        "status": "estado: ",
        "answer": "respuesta: ",
        "sizes": "mensajes enviados en cada llamada: ",
        "tokens": "tokens (estimados): ",
        "log": "registro:",
    },
    "de": {
        "question": (
            "Miete 3 Tage vorher storniert: Erstattung?"
        ),
        "whole": "Ja, zu 40 % [p03].",
        "start": "Ja, zu ",
        "rest": "40 % [p03].",
        "banner": "SIMULIERT: von Hand geschriebene Antworten.",
        "size": "Anweisungen und Dokument: {} Zeichen",
        "s1": "Eine vollständige Antwort",
        "s2": (
            "Eine abgeschnittene Antwort, dann ihre Fortsetzung"
        ),
        "s3": (
            "Immer abgeschnittene Antwort, maximal drei Runden"
        ),
        "status": "Status: ",
        "answer": "Antwort: ",
        "sizes": "pro Aufruf gesendete Nachrichten: ",
        "tokens": "Tokens (geschätzt): ",
        "log": "Protokoll:",
    },
}


def _scenarios(
    text: dict[str, str],
) -> list[tuple[str, FakeModel, Limits]]:
    return [
        (
            text["s1"],
            FakeModel([FakeModel.says(text["whole"])]),
            Limits(),
        ),
        (
            text["s2"],
            FakeModel(
                [
                    FakeModel.truncated(text["start"]),
                    FakeModel.says(text["rest"]),
                ]
            ),
            Limits(),
        ),
        (
            text["s3"],
            FakeModel(
                [FakeModel.truncated("bla ") for _ in range(9)]
            ),
            Limits(max_turns=3),
        ),
    ]


def main() -> None:
    lang = load_settings().lang
    text = TEXT[lang]
    document = (
        CODE_DIR / "demo_data" / lang / "remboursement.md"
    )
    system = system_with_document(document, lang)
    print(text["banner"])
    print(text["size"].format(len(system)))
    for number, (title, model, limits) in enumerate(
        _scenarios(text), start=1
    ):
        result = run(model, system, text["question"], limits)
        sizes = [len(r["messages"]) for r in model.requests]
        print(f"\n=== {number}. {title} ===")
        print(f"{text['status']}{result.status}")
        print(f"{text['answer']}{result.answer}")
        print(f"{text['sizes']}{sizes}")
        print(f"{text['tokens']}{result.state.usage.total}")
        print(text["log"])
        for event in result.state.events:
            print(f"  {localize(lang, event)}")


if __name__ == "__main__":
    main()
