"""System prompts, one file per language and step."""

from pathlib import Path

HERE = Path(__file__).parent


def load(step: str, lang: str, **values: str) -> str:
    text = (HERE / f"{step}.{lang}.txt").read_text("utf-8")
    return text.format(**values)
