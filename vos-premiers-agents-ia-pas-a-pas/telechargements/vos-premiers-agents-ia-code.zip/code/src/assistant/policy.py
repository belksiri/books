"""File access restrictions, enforced in code.

Layout (relative to the `code/` folder):

    demo_data/<lang>/  read-only: the document folder
    workspace/notes/   written by the agent (save_note tool),
                       new files only, never overwritten
    workspace/memory/  memory.json, replaced as a whole by the
                       memory module after user confirmation
    outbox/            written only after human approval
                       (approval module), never by an agent tool
    logs/              written by the program, not the agent

An isolated folder is not enough: every access goes through
`check_read` or `check_write`, which resolve the real path
(symbolic links included) before comparing it to the roots.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

SAFE_NAME = re.compile(
    r"^[a-z0-9][a-z0-9-]{0,59}\.(md|txt|json)$"
)


class AccessDenied(Exception):
    pass


# [snippet:inside]
def _inside(path: Path, roots: list[Path]) -> Path:
    real = path.resolve()  # follows links and ".."
    for root in roots:
        if real.is_relative_to(root.resolve()):
            return real
    raise AccessDenied(f"outside allowed folders: {path}")


# [/snippet]


class FileAccessPolicy:
    def __init__(
        self,
        read_roots: list[Path],
        write_roots: list[Path] | None = None,
        max_write_bytes: int = 20_000,
    ):
        self.read_roots = [Path(r) for r in read_roots]
        self.write_roots = [Path(r) for r in write_roots or []]
        self.max_write_bytes = max_write_bytes

    def check_read(self, path: Path) -> Path:
        return _inside(Path(path), self.read_roots)

    # [snippet:check-write]
    def check_write(self, folder: Path, name: str) -> Path:
        if not SAFE_NAME.match(name):
            raise AccessDenied(f"file name refused: {name}")
        target = _inside(Path(folder) / name, self.write_roots)
        if target.exists():
            raise AccessDenied(f"file already exists: {name}")
        return target

    # [/snippet]

    def write_new(
        self, folder: Path, name: str, text: str
    ) -> Path:
        data = text.encode("utf-8")
        if len(data) > self.max_write_bytes:
            raise AccessDenied("content too large")
        target = self.check_write(folder, name)
        target.parent.mkdir(parents=True, exist_ok=True)
        # Mode "x" fails if the file appeared in the meantime.
        with open(target, "xb") as handle:
            handle.write(data)
        return target

    def replace(
        self, folder: Path, name: str, text: str
    ) -> Path:
        """Replace a whole file (memory file only).

        Atomicity: the new content goes to a temporary file in
        the SAME folder (same filesystem), then os.replace swaps
        it in. Per the Python docs, a successful rename is
        atomic on POSIX systems; it may fail across
        filesystems. Readers see the old file or the new one.
        Durability (surviving a power cut) is another matter:
        we fsync the file, and the folder on POSIX. The result
        still depends on the filesystem and the hardware.
        """
        if not SAFE_NAME.match(name):
            raise AccessDenied(f"file name refused: {name}")
        data = text.encode("utf-8")
        if len(data) > self.max_write_bytes:
            raise AccessDenied("content too large")
        target = _inside(Path(folder) / name, self.write_roots)
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(f".{name}.{os.getpid()}.tmp")
        with open(temp, "xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, target)
        if os.name == "posix":
            folder_fd = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(folder_fd)
            finally:
                os.close(folder_fd)
        return target
