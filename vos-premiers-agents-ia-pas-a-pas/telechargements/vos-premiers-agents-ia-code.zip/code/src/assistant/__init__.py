"""Rivelune document assistant (book companion code)."""
