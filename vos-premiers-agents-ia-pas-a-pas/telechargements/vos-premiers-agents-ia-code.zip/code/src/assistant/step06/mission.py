"""Step 06: running a plan step by step, with a saved state.

After each step, the whole mission state is written to
`workspace/missions/<id>.json`. If the run stops (error,
limit, Ctrl-C), running it again skips the steps already done
and replays the others from their start. Steps are read-only,
so a replay has no external effect; it is NOT reproducible: the
model may answer differently. An action with effects never
happens inside a step (chapter 7). If the documents changed,
the mission does not resume (see `corpus_changes`).
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from pydantic import BaseModel, Field

from assistant.corpus import Corpus
from assistant.llm import ModelClient, ModelError, Usage
from assistant.policy import FileAccessPolicy
from assistant.prompts import load
from assistant.runstate import Limits
from assistant.step04.agent import new_state, run
from assistant.step04.tools import build_toolbox
from assistant.step05.bm25 import bm25_search
from assistant.step06.plan import Plan, Step


# [snippet:state]
class StepResult(BaseModel):
    status: str = "pending"  # done, error, or a limit name
    answer: str = ""
    # What the model received during THIS step (chapter 4).
    consulted: dict[str, str] = Field(default_factory=dict)
    input_tokens: int = 0
    output_tokens: int = 0


class MissionState(BaseModel):
    mission_id: str
    question: str
    lang: str
    today: str
    plan: Plan
    # The documents analysed: independent of `lang`, the
    # language of the prompts and messages.
    folder: str = ""
    corpus_lang: str = ""
    # One digest per document, at the start of the mission.
    doc_digests: dict[str, str] = Field(default_factory=dict)
    results: dict[str, StepResult] = Field(default_factory=dict)

    def todo(self) -> list[Step]:
        return [
            s
            for s in self.plan.steps
            if self.result(s.id).status != "done"
        ]

    def result(self, step_id: str) -> StepResult:
        return self.results.setdefault(step_id, StepResult())


# [/snippet]


class MissionStore:
    """Saves and loads mission states, inside one folder."""

    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self._policy = FileAccessPolicy(
            read_roots=[self.folder],
            write_roots=[self.folder],
            max_write_bytes=200_000,
        )

    def path(self, mission_id: str) -> Path:
        return self.folder / f"{mission_id}.json"

    def save(self, state: MissionState) -> None:
        self._policy.replace(
            self.folder,
            f"{state.mission_id}.json",
            state.model_dump_json(indent=2),
        )

    def write(self, name: str, text: str) -> None:
        """The synthesis and its report, next to the state."""
        self._policy.replace(self.folder, name, text)

    def load(self, mission_id: str) -> MissionState | None:
        path = self.path(mission_id)
        if not path.exists():
            return None
        raw = self._policy.check_read(path).read_text("utf-8")
        return MissionState.model_validate_json(raw)


# [snippet:corpus-changes]
def corpus_changes(
    saved: dict[str, str], current: dict[str, str]
) -> list[str]:
    """Documents added, removed or modified since the start."""
    return sorted(
        doc
        for doc in saved.keys() | current.keys()
        if saved.get(doc) != current.get(doc)
    )


# [/snippet]


def task_text(state: MissionState, step: Step) -> str:
    """The user message of one step."""
    return load(
        "step06-task",
        state.lang,
        question=state.question,
        step_id=step.id,
        count=str(len(state.plan.steps)),
        goal=step.goal,
        query=step.query,
    )


# [snippet:run-mission]
def run_mission(
    model: ModelClient,
    state: MissionState,
    corpus: Corpus,
    store: MissionStore,
    limits: Limits | None = None,
    on_step: Callable[[Step, StepResult], None] | None = None,
) -> str:
    """Run the steps not done yet; save after each one."""
    system = load("step04", state.lang, today=state.today)
    for step in state.todo():
        run_state = new_state(limits)
        toolbox = build_toolbox(
            corpus,
            None,  # read-only: a replay repeats no action
            run_state.consulted,
            search=bm25_search,
        )
        result = state.result(step.id)
        try:
            outcome = run(
                model,
                system,
                task_text(state, step),
                toolbox,
                run_state,
            )
            result.status = outcome.status
            result.answer = outcome.answer
        except ModelError as error:
            result.status = "error"
            result.answer = str(error)
        result.consulted = dict(run_state.consulted)
        _add_usage(result, run_state.usage)
        store.save(state)  # after EVERY step, done or not

        if on_step:
            on_step(step, result)
        if result.status != "done":
            return "interrupted"
    return "done"


# [/snippet]


def _add_usage(result: StepResult, usage: Usage) -> None:
    # Tokens of failed attempts are kept: they were spent.
    result.input_tokens += usage.input_tokens
    result.output_tokens += usage.output_tokens
