"""Step 06: a plan, fixed by the code or proposed by the model.

Same dual schema as the tools of chapter 4: PLAN_SCHEMA is
what the model is asked to follow (structured outputs accept
no length bounds); the Pydantic classes are what the code
enforces, bounds included.
"""

from __future__ import annotations

from pydantic import Field, ValidationError, model_validator

from assistant.llm import JsonModelClient
from assistant.prompts import load
from assistant.step04.tools import Strict


# [snippet:plan-classes]
class Step(Strict):
    id: str = Field(pattern=r"^s[1-9]$")
    goal: str = Field(min_length=5, max_length=200)
    query: str = Field(min_length=2, max_length=80)


class Plan(Strict):
    title: str = Field(min_length=3, max_length=120)
    steps: list[Step] = Field(min_length=2, max_length=5)

    @model_validator(mode="after")
    def ids_in_order(self) -> Plan:
        expected = [
            f"s{i}" for i in range(1, len(self.steps) + 1)
        ]
        if [s.id for s in self.steps] != expected:
            raise ValueError(f"step ids must be {expected}")
        return self


# [/snippet]

# [snippet:plan-schema]
STEP_SCHEMA = {
    "type": "object",
    "properties": {
        "id": {"type": "string", "description": "s1, s2..."},
        "goal": {"type": "string"},
        "query": {
            "type": "string",
            "description": "Search keywords.",
        },
    },
    "required": ["id", "goal", "query"],
    "additionalProperties": False,
}
PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "steps": {"type": "array", "items": STEP_SCHEMA},
    },
    "required": ["title", "steps"],
    "additionalProperties": False,
}
# [/snippet]


class PlanRefused(Exception):
    """The proposed plan does not pass validation."""


# [snippet:propose]
def propose_plan(
    model: JsonModelClient, question: str, lang: str
) -> Plan:
    system = load("step06-plan", lang)
    messages = [{"role": "user", "content": question}]
    reply = model.complete_json(system, messages, PLAN_SCHEMA)

    if reply.stop_reason != "end_turn":
        raise PlanRefused(f"no plan: {reply.stop_reason}")
    try:
        return Plan.model_validate_json(reply.text)
    except ValidationError as error:
        first = error.errors()[0]
        where = ".".join(str(x) for x in first["loc"])
        raise PlanRefused(f"{where}: {first['msg']}") from error


# [/snippet]

# Goals of the plan fixed by the code, one per language.
FIXED_GOALS = {
    "fr": (
        "Établir les règles et montants actuels",
        "Retracer les décisions et leurs dates",
        "Relever les points provisoires ou contradictoires",
    ),
    "en": (
        "Establish the current rules and amounts",
        "Trace the decisions and their dates",
        "List provisional or contradictory points",
    ),
    "es": (
        "Establecer las reglas y los importes vigentes",
        "Reconstruir las decisiones y sus fechas",
        "Señalar los puntos provisionales o contradictorios",
    ),
    "de": (
        "Die geltenden Regeln und Beträge feststellen",
        "Die Beschlüsse und ihre Daten nachvollziehen",
        "Vorläufige oder widersprüchliche Punkte festhalten",
    ),
}


# [snippet:fixed-plan]
def fixed_plan(title: str, query: str, lang: str) -> Plan:
    """A workflow: the code decides the steps, always the
    same three, whatever the subject."""
    steps = [
        Step(id=f"s{i}", goal=goal, query=query)
        for i, goal in enumerate(FIXED_GOALS[lang], start=1)
    ]
    return Plan(title=title, steps=steps)


# [/snippet]
