"""Step 06: assembling the synthesis, then checking it.

First the checks the code can make (structure, references,
length): deterministic. Then a review by a model: an opinion,
useful to find what the code cannot see, never a proof.
"""

from __future__ import annotations

from dataclasses import dataclass

from pydantic import Field, ValidationError

from assistant.corpus import Corpus
from assistant.llm import JsonModelClient
from assistant.prompts import load
from assistant.step04.tools import Strict
from assistant.step05.citations import (
    QUOTE_LINE,
    REF,
    check_citations,
)
from assistant.step06.mission import MissionState

SOURCES = {
    "fr": "Sources",
    "en": "Sources",
    "es": "Fuentes",
    "de": "Quellen",
}
MAX_SECTION_WORDS = 120


def split_answer(answer: str) -> tuple[str, list[str]]:
    """(body, source lines) of one step's answer."""
    body, sources = [], []
    headings = {w.lower() for w in SOURCES.values()}
    for line in answer.splitlines():
        if QUOTE_LINE.match(line):
            sources.append(line.strip())
        elif line.strip("#*: ").lower() not in headings:
            body.append(line)
    return "\n".join(body).strip(), sources


def assemble(state: MissionState) -> str:
    """The synthesis in Markdown: written by the code, from
    the answers of the steps."""
    parts, seen = [f"# {state.plan.title}"], {}
    for step in state.plan.steps:
        body, sources = split_answer(
            state.result(step.id).answer
        )
        parts += [f"## {step.goal}", body]
        for line in sources:
            seen.setdefault(QUOTE_LINE.match(line)[1], line)
    parts.append(f"## {SOURCES[state.lang]}")
    parts.append("\n".join(seen.values()))
    return "\n\n".join(parts) + "\n"


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""


def run_checks(
    state: MissionState, corpus: Corpus
) -> list[Check]:
    steps = state.plan.steps
    missing = [s.id for s in state.todo()]
    checks = [
        Check("steps_done", not missing, " ".join(missing))
    ]

    # [snippet:checks]
    no_ref, bad, long = [], [], []
    for step in steps:
        result = state.result(step.id)
        body, _ = split_answer(result.answer)
        if not REF.search(body):
            no_ref.append(step.id)
        if len(body.split()) > MAX_SECTION_WORDS:
            long.append(step.id)

        # Each step is checked against ITS OWN trace.
        for c in check_citations(
            result.answer, corpus, result.consulted
        ):
            if (
                not (c.exists and c.consulted)
                or c.excerpt is False
            ):
                bad.append(f"{step.id}:{c.ref}")
    # [/snippet]

    checks.append(
        Check("refs_in_sections", not no_ref, " ".join(no_ref))
    )
    checks.append(Check("refs_valid", not bad, " ".join(bad)))
    checks.append(Check("length", not long, " ".join(long)))
    return checks


# [snippet:review]
class Issue(Strict):
    step: str = Field(pattern=r"^s[1-9]$")
    claim: str = Field(max_length=300)
    problem: str = Field(max_length=300)


class Review(Strict):
    issues: list[Issue] = Field(max_length=10)


ISSUE_SCHEMA = {
    "type": "object",
    "properties": {
        "step": {"type": "string"},
        "claim": {"type": "string"},
        "problem": {"type": "string"},
    },
    "required": ["step", "claim", "problem"],
    "additionalProperties": False,
}
REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "issues": {"type": "array", "items": ISSUE_SCHEMA}
    },
    "required": ["issues"],
    "additionalProperties": False,
}


def review(
    model: JsonModelClient,
    state: MissionState,
    corpus: Corpus,
) -> Review | None:
    """A model's opinion on the claims. None: no usable
    opinion (the checks above still stand)."""
    reply = model.complete_json(
        load("step06-review", state.lang),
        [
            {
                "role": "user",
                "content": review_input(state, corpus),
            }
        ],
        REVIEW_SCHEMA,
    )
    if reply.stop_reason != "end_turn":
        return None
    try:
        return Review.model_validate_json(reply.text)
    except ValidationError:
        return None


# [/snippet]


def review_input(state: MissionState, corpus: Corpus) -> str:
    """Each step's answer, then every passage it cites, whole,
    with its document's date and status: without them, a real
    reviewer called correct statuses unsupported."""
    parts = []
    for step in state.plan.steps:
        answer = state.result(step.id).answer
        parts.append(
            f'<step id="{step.id}">\n{answer}\n</step>'
        )
    refs = dict.fromkeys(
        ref
        for step in state.plan.steps
        for ref in REF.findall(state.result(step.id).answer)
    )
    for ref in refs:
        passage = corpus.passage(ref)
        if passage:
            meta = corpus.get(passage.doc_id).meta
            parts.append(
                f'<passage ref="{ref}" '
                f'date="{meta.get("date", "")}" '
                f'status="{meta.get("status", "")}">\n'
                f"{passage.text}\n</passage>"
            )
    return "\n\n".join(parts)
