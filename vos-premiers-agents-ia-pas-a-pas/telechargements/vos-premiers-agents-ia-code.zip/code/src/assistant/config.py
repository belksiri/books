"""Settings read from the environment (and the .env file)."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

CODE_DIR = Path(__file__).resolve().parents[2]
LANGS = ("fr", "en", "es", "de")


@dataclass(frozen=True)
class Settings:
    model: str | None
    lang: str
    allow_live: bool

    @property
    def data_dir(self) -> Path:
        return CODE_DIR / "demo_data" / self.lang

    @property
    def notes_dir(self) -> Path:
        return CODE_DIR / "workspace" / "notes"

    @property
    def outbox_dir(self) -> Path:
        return CODE_DIR / "outbox"

    @property
    def allowed_targets(self) -> set[str]:
        raw = os.getenv("ASSISTANT_ALLOWED_TARGETS", "")
        return {t.strip() for t in raw.split(",") if t.strip()}

    @property
    def journal_path(self) -> Path:
        return CODE_DIR / "logs" / "actions.jsonl"


def load_settings() -> Settings:
    # Tests set ASSISTANT_NO_DOTENV=1: a real .env must never
    # leak a key or a "live" switch into the test suite.
    if os.getenv("ASSISTANT_NO_DOTENV") != "1":
        load_dotenv(CODE_DIR / ".env")
    lang = os.getenv("ASSISTANT_LANG", "fr")
    if lang not in LANGS:
        raise SystemExit(f"invalid ASSISTANT_LANG: {lang}")
    return Settings(
        model=os.getenv("AGENT_MODEL") or None,
        lang=lang,
        allow_live=os.getenv("ASSISTANT_ALLOW_LIVE") == "1",
    )
