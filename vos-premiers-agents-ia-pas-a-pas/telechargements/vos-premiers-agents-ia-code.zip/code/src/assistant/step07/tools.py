"""Step 07: read-only tools, plus one way to ask for a sending.

The model proposes; it cannot approve. No parameter of the
tool can say "already approved": the answer comes from a
person, through `SendGate`, outside the model's reach.
"""

from __future__ import annotations

from pydantic import Field

from assistant.corpus import Corpus
from assistant.step04.tools import (
    Strict,
    Tool,
    Toolbox,
    ToolError,
    build_toolbox,
)
from assistant.step05.bm25 import bm25_search
from assistant.step07.gate import GateRefused, SendGate


class SendParams(Strict):
    target: str = Field(min_length=3, max_length=100)
    content: str = Field(min_length=1, max_length=8000)


SEND_SCHEMA = {
    "type": "object",
    "properties": {
        "target": {"type": "string"},
        "content": {
            "type": "string",
            "description": "The final text, as it will leave.",
        },
    },
    "required": ["target", "content"],
    "additionalProperties": False,
}


def build_toolbox_step07(
    corpus: Corpus, consulted: dict[str, str], gate: SendGate
) -> Toolbox:
    base = build_toolbox(
        corpus, None, consulted, search=bm25_search
    )

    def send_message(args: SendParams) -> str:
        try:
            path = gate.submit(args.target, args.content)
        except GateRefused as error:
            raise ToolError(f"Not sent: {error}") from error
        return f"Sent (simulated): outbox/{path.name}"

    send = Tool(
        "send_message",
        "Ask to send a text to a recipient. A person sees the "
        "exact text and decides. Use it only if the user asks.",
        SEND_SCHEMA,
        SendParams,
        send_message,
    )
    return Toolbox(
        list(base._tools.values()) + [send],
        base.consulted,
        base.max_chars,
    )
