"""Step 07: the only way out for a sensitive action.

"Sending" writes a local file into outbox/. Simulated failures
test the logic of this program: they prove nothing about a real
mail service, nor about surviving a hardware power cut.

Order of the checks, for each proposed sending:
1. a previous sending with an unknown outcome blocks everything;
2. the recipient must be on a list fixed by the code;
3. the content must not hide anything from the person;
4. the exact same action is not sent twice;
5. the person sees the whole action and answers;
6. the journal records the intent BEFORE the effect, and the
   result AFTER it.

If the program stops between those two records, nobody knows
whether the effect happened. The next run does not guess: it
refuses to send until a person has looked and said.
"""

from __future__ import annotations

import json
import os
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

from assistant.approval import (
    OutboxSender,
    ProposedAction,
    hidden_characters,
    request_approval,
)
from assistant.memory import PERSONAL_DATA

MAX_CONTENT_BYTES = 19_000  # the file also holds a header


class GateRefused(Exception):
    """Not sent, for a reason the model may be told."""


class UnknownOutcome(GateRefused):
    """A person must check what happened to an earlier send."""


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class ActionJournal:
    """Append-only audit log. Digests only, never the content:
    a log must not become a second copy of sensitive data."""

    def __init__(self, path: Path, clock=_now):
        self.path, self.clock = Path(path), clock

    def add(self, event: str, digest: str, **details) -> None:
        record = {
            "at": self.clock(),
            "event": event,
            "digest": digest,
            **details,
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as log:
            log.write(json.dumps(record, ensure_ascii=False))
            log.write("\n")
            log.flush()
            os.fsync(log.fileno())

    def events(self) -> list[dict]:
        if not self.path.exists():
            return []
        lines = self.path.read_text("utf-8").splitlines()
        return [json.loads(line) for line in lines]

    # [snippet:journal]
    def outcome(self) -> dict[str, str]:
        """digest -> "intent" (unknown!), "sent", "not_sent"."""
        result = {}
        for e in self.events():
            if e["event"] in ("intent", "sent", "not_sent"):
                result[e["digest"]] = e["event"]
        return result

    def unknown(self) -> list[str]:
        known = self.outcome().items()
        return [d for d, state in known if state == "intent"]

    def resolve(self, digest: str, happened: bool, who: str):
        """A person looked: was it sent or not?"""
        if digest not in self.unknown():
            raise ValueError(f"nothing to resolve: {digest}")
        state = "sent" if happened else "not_sent"
        self.add(state, digest, resolved_by=who)

    # [/snippet]


class SendGate:
    def __init__(
        self,
        allowed_targets: set[str],
        ask: Callable[[str], bool],
        who: str,
        sender: OutboxSender,
        journal: ActionJournal,
    ):
        self.allowed = allowed_targets
        self.ask, self.who = ask, who
        self.sender, self.journal = sender, journal

    # [snippet:submit]
    def submit(self, target: str, content: str) -> Path:
        action = ProposedAction("send_summary", target, content)
        digest = action.digest()
        log = self.journal

        if log.unknown():
            raise UnknownOutcome(
                "an earlier sending has an unknown outcome: "
                "a person must check it; do not try again"
            )
        if target not in self.allowed:
            log.add(
                "refused", digest, why="target", target=target
            )
            raise GateRefused(
                f"recipient not allowed: {target}"
            )
        hidden = hidden_characters(content)
        if hidden:
            log.add("refused", digest, why="hidden characters")
            raise GateRefused(
                f"hidden characters: {' '.join(hidden[:5])}"
            )
        if len(content.encode("utf-8")) > MAX_CONTENT_BYTES:
            # Refused here: a failure after "intent" would
            # block every sending until a person looks.
            log.add("refused", digest, why="too long")
            raise GateRefused("text too long to send")
        if log.outcome().get(digest) == "sent":
            log.add("refused", digest, why="already sent")
            raise GateRefused(
                "this exact action was already sent"
            )

        approval = request_approval(
            action, self._ask_with_warning(content), self.who
        )
        if approval is None:
            log.add("declined", digest, by=self.who)
            raise GateRefused("declined by the person")
        log.add("approved", digest, by=self.who, target=target)

        log.add("intent", digest)  # BEFORE the effect
        path = self.sender.send(
            action, approval, f"{digest[:16]}.md"
        )
        log.add("sent", digest, file=path.name)  # AFTER it
        return path

    # [/snippet]

    def _ask_with_warning(self, content: str):
        """Same filter as memory, limited too: it warns the
        person, it does not decide."""
        if not any(p.search(content) for p in PERSONAL_DATA):
            return self.ask

        def ask(preview: str) -> bool:
            warning = "WARNING: looks like personal data\n"
            return self.ask(warning + preview)

        return ask
