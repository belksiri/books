"""Step 07: retrying a model call, without looping forever.

Only model calls are retried, and only when the error says it
is worth it. An action with effects is never retried here
(see gate.py). Put this wrapper AROUND the spending guard, so
every attempt is checked and counted; give the SDK client
max_retries=0, or its own retries multiply with these.
"""

from __future__ import annotations

import time
from collections.abc import Callable

from assistant.llm import ModelClient, ModelError


# [snippet:retrying]
class RetryingModel:
    def __init__(
        self,
        model: ModelClient,
        attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        sleep: Callable[[float], None] = time.sleep,
    ):
        self.model = model
        self.name, self.max_tokens = (
            model.name,
            model.max_tokens,
        )
        self.attempts, self.sleep = attempts, sleep
        self.base_delay, self.max_delay = base_delay, max_delay
        self.retries = 0  # visible in reports

    def _call(self, call):
        for attempt in range(1, self.attempts + 1):
            try:
                return call()
            except ModelError as error:
                if not error.retryable:
                    raise  # invalid request, key, budget...
                if attempt == self.attempts:
                    raise  # bounded: we stop and say so
                delay = self.base_delay * 2 ** (attempt - 1)
                delay = max(delay, error.retry_after or 0)
                if delay > self.max_delay:
                    raise  # too long to wait here
                self.retries += 1
                self.sleep(delay)
        raise AssertionError("attempts must be at least 1")

    # [/snippet]

    def complete(self, system, messages, tools=None):
        return self._call(
            lambda: self.model.complete(system, messages, tools)
        )

    def complete_json(self, system, messages, schema):
        return self._call(
            lambda: self.model.complete_json(
                system, messages, schema
            )
        )
