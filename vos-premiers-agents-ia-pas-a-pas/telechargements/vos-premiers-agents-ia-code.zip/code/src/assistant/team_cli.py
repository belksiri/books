"""Commands of chapter 8: team-demo (simulated), team (paid)."""

from __future__ import annotations

import textwrap

from assistant.corpus import Corpus
from assistant.messages import localize, t
from assistant.scenarios import (
    team_full_run,
    team_lost_reference,
)
from assistant.step08.orchestrator import (
    TeamResult,
    assemble_answer,
    run_team,
)

WIDTH = 64
QUESTIONS = {
    "fr": "Quel est le montant du dépôt de garantie ?",
    "de": "Wie hoch ist die Sicherheitsleistung?",
    "en": "How much is the security deposit?",
    "es": "¿Cuál es el importe del depósito de garantía?",
}


def _c(lang: str) -> str:
    return "\u00a0: " if lang == "fr" else ": "


def _cut(line: str) -> str:
    return (
        line if len(line) <= WIDTH else line[: WIDTH - 1] + "…"
    )


def _role(lang: str, name: str) -> str:
    return t(lang, name)


def print_run(
    lang: str, result: TeamResult, budget, simulated: bool
) -> None:
    for x in result.log:
        size = f" ({x.chars})" if x.chars else ""
        print(
            _cut(
                f"{_role(lang, x.sender)} -> "
                f"{_role(lang, x.receiver)}{_c(lang)}"
                f"{x.contract}{size}"
            )
        )
    print(f"{t(lang, 'status')}{_c(lang)}{result.status}")
    for problem in result.problems:
        print(_cut(f"  {localize(lang, problem)}"))
    for ref in result.lost_refs:
        print(_cut(f"  {t(lang, 'lost')}{_c(lang)}{ref}"))
    if result.review:
        print(f"--- {t(lang, 'answer')} ---")
        for line in assemble_answer(result):
            print(
                textwrap.fill(
                    line, WIDTH, break_on_hyphens=False
                )
            )
        print("---")
        key = "verdicts_demo" if simulated else "review"
        print(f"{t(lang, key)}{_c(lang).rstrip()}")
        for v in result.review.verdicts:
            mark = t(lang, "yes" if v.supported else "no")
            print(
                _cut(f"  {v.claim} {mark}{_c(lang)}{v.reason}")
            )
    counts = ", ".join(
        f"{_role(lang, r)} {budget.calls.get(r, 0)}"
        for r in ("researcher", "writer", "verifier")
    )
    print(_cut(f"{t(lang, 'calls_by_role')}{_c(lang)}{counts}"))


def team_demo(lang: str, corpus: Corpus) -> int:
    print(f"({t(lang, 'simulated')})")
    runs = [team_lost_reference, team_full_run]
    for number, script in enumerate(runs, start=1):
        print(f"=== {t(lang, 'attempt')} {number} ===")
        result, budget = run_team(
            script(lang, corpus),
            QUESTIONS[lang],
            corpus,
            lang,
            "2026-06-15",
        )
        print_run(lang, result, budget, simulated=True)
    return 0


def team_live(settings, args) -> int:
    """Real run (paid): only with ASSISTANT_ALLOW_LIVE=1."""
    from assistant.paid import mission_key, open_model
    from assistant.step07.retry import RetryingModel
    from assistant.synthesis_cli import open_corpus

    lang = settings.lang
    guarded = open_model(
        settings, mission_key("team", args.question), 40
    )
    if guarded is None:
        return 2
    opened = open_corpus(lang, args.dossier, args.corpus_lang)
    if opened is None:
        return 3
    result, budget = run_team(
        RetryingModel(guarded),
        args.question,
        opened[0],
        lang,
        args.date,
    )
    print_run(lang, result, budget, simulated=False)
    ok = result.status.startswith("done")
    return 0 if ok or result.status == "no_answer" else 4
