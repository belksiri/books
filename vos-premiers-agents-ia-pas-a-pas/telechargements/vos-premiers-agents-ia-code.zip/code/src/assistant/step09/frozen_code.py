# SPDX-License-Identifier: MIT
"""The code of the chapter 9 experiment, kept apart.

`experiments/ch09/frozen-src/` holds a byte-for-byte copy of
the files the fingerprint covers, as they were when the real
rounds ran (fingerprint 8376d976b0fd296b). The distributed
code may evolve for teaching; this copy does not.
`differences()` names the distributed files that no longer
match it: while the list is empty, `fingerprint()` and
`historical_fingerprint()` agree.
"""

from __future__ import annotations

import hashlib

from assistant.step09.evaluate import (
    EXPERIMENT,
    FINGERPRINTED,
    FIRST_MODEL,
    SRC,
)

FROZEN = EXPERIMENT / "frozen-src"
HISTORICAL = "8376d976b0fd296b"


def historical_fingerprint() -> str:
    """Same recipe as `fingerprint()`, on the frozen copy."""
    digest = hashlib.sha256(FIRST_MODEL.encode())
    paths = [FROZEN / name for name in FINGERPRINTED] + [
        EXPERIMENT / "tasks.json",
        EXPERIMENT / "config.json",
        EXPERIMENT / "grading-grid.json",
        EXPERIMENT / "corpus" / "MANIFEST.json",
    ]
    for path in paths:
        digest.update(path.read_bytes())
    return digest.hexdigest()[:16]


def differences() -> list[str]:
    return [
        name
        for name in FINGERPRINTED
        if (SRC / name).read_bytes()
        != (FROZEN / name).read_bytes()
    ]
