"""Step 09: one agent and the team, by the same rules."""
