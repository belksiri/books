"""The evaluation tasks, fixed before any real run."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import Field

from assistant.step04.tools import Strict


# [snippet:eval-task]
class EvalTask(Strict):
    id: str
    # "tuning": may be used to adjust prompts and code.
    # "final": kept for the evaluation, never for adjusting.
    split: Literal["tuning", "final"]
    category: str
    question: str
    # Each group: at least one of these passages must be cited.
    expected_refs: list[list[str]]
    # Each group: at least one of these strings in the answer.
    must_state: list[list[str]]
    must_not_state: list[str] = Field(default_factory=list)
    # True: the documents do not contain the answer.
    absent: bool = False
    # What a person checks; never shown to the agents.
    key_points: str
    # The criteria of the grid that apply to this task.
    criteria: list[str]


# [/snippet]


def load_tasks(path: Path) -> list[EvalTask]:
    data = json.loads(path.read_text("utf-8"))
    return [EvalTask.model_validate(item) for item in data]
