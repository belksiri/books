"""Scoring: what the code can check, then a person's grade.

The automatic checks say whether strings and references are
there. They cannot say whether the answer is right, and they
never become a grade: quality is the grid filled by a person.
"""

from __future__ import annotations

import re
import statistics

from assistant.corpus import Corpus
from assistant.step05.citations import check_citations
from assistant.step09.compare import limit_reached
from assistant.step09.grading import CRITERIA, last_attempts
from assistant.step09.tasks import EvalTask


def _has(needle: str, answer: str) -> bool:
    found = re.search(
        rf"(?<![\d\w]){re.escape(needle)}(?![\d\w])",
        answer,
        re.IGNORECASE,
    )
    return found is not None


def auto_score(
    task: EvalTask,
    answer: str,
    corpus: Corpus,
    consulted: dict[str, str],
) -> dict:
    checks = check_citations(answer, corpus, consulted)
    refs = {c.ref for c in checks}
    return {
        "delivered": bool(answer),
        "refs_count": len(checks),
        "refs_exist": all(c.exists for c in checks),
        "refs_consulted": all(c.consulted for c in checks),
        "excerpts_found": all(
            c.excerpt is not False for c in checks
        ),
        "expected_refs": all(
            refs & set(group) for group in task.expected_refs
        ),
        "must_state": all(
            any(_has(word, answer) for word in group)
            for group in task.must_state
        ),
        "must_not_state": not any(
            word.lower() in answer.lower()
            for word in task.must_not_state
        ),
    }


AUTO_KEYS = (
    "refs_exist",
    "refs_consulted",
    "excerpts_found",
    "expected_refs",
    "must_state",
    "must_not_state",
)


def _span(values) -> str:
    if not values:
        return "-"
    middle = statistics.median(values)
    return f"{middle:g} ({min(values):g}-{max(values):g})"


def summary(
    rows: list[dict],
    grades: dict[str, dict],
    tasks: list[EvalTask],
) -> dict:
    """All attempts count in spending. For quality, the last
    attempt of each run: no answer counts 0, by rule, on each
    criterion of the task; it is not a person's grade."""
    by_id = {t.id: t for t in tasks}
    last = last_attempts(rows)
    kinds: dict[str, int] = {}
    limits: dict[str, int] = {}
    for row in last:
        kinds[row["kind"]] = kinds.get(row["kind"], 0) + 1
    for row in rows:
        name = limit_reached(row["status"])
        if name:
            limits[name] = limits.get(name, 0) + 1
    points = {name: [0, 0] for name in CRITERIA}
    graded = no_answer = pending = 0
    for row in last:
        applicable = by_id[row["task"]].criteria
        if not row["answer"]:
            no_answer += 1
            marks = {name: 0 for name in applicable}
        elif row["run_id"] in grades:
            graded += 1
            marks = grades[row["run_id"]]
        else:
            pending += 1
            continue
        for name, value in marks.items():
            points[name][0] += value
            points[name][1] += 2
    return {
        "runs": len(last),
        "attempts": len(rows),
        "kinds": kinds,
        "limits": limits,
        "points": {
            k: tuple(v) for k, v in points.items() if v[1]
        },
        "graded": graded,
        "no_answer": no_answer,
        "pending": pending,
        "auto": {
            key: sum(1 for r in last if r["auto"].get(key))
            for key in AUTO_KEYS
        },
        "calls": _span([r["calls"] for r in rows]),
        "tokens": _span([r["tokens"] for r in rows]),
        "usd_charged": sum(r["charged_usd"] for r in rows),
        "seconds": _span([r["seconds"] for r in rows]),
        "objected": sum(1 for r in last if r["objections"]),
        "revised": sum(1 for r in last if r["revisions"]),
    }
