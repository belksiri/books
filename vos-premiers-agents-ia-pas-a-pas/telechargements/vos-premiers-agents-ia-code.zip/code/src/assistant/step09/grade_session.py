"""A guided grading session: one answer at a time, for a person.

Blind: origin, cost and duration stay hidden. Each answer is
saved at once; stop with q and come back. The program grades
nothing here, and only a person may answer.
"""

from __future__ import annotations

import csv
import os
from pathlib import Path

from assistant.step09.grading import CRITERIA, NOT_APPLICABLE


class Quit(Exception):
    """The person stops for now; what is saved stays."""


def _save(path: Path, rows: list[dict]) -> None:
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(tmp, path)


def _read(path: Path) -> list[dict]:
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _mark(ask, prompt: str) -> str:
    while True:
        value = ask(prompt).strip().lower()
        if value == "q":
            raise Quit
        if value in ("0", "1", "2"):
            return value
        print("0, 1 ou 2 ; q pour arrêter.")


def _todo(row: dict) -> list[str]:
    return [
        name
        for name in CRITERIA
        if row[name] != NOT_APPLICABLE and not row[name].strip()
    ]


def _grade_sheet(path, grid, grader, ask, show) -> None:
    rows = _read(path)
    total = len(rows)
    for number, row in enumerate(rows, 1):
        todo = _todo(row)
        if not todo:
            continue
        show(
            f"\n=== Réponse {number} sur {total} "
            f"({row['answer_id']}) ===\n\n"
            f"QUESTION\n{row['question']}\n\n"
            f"POINTS ATTENDUS\n{row['key_points']}\n\n"
            f"RÉPONSE À NOTER\n{row['answer']}\n"
        )
        marks = {}
        for name in todo:
            item = grid[name]
            show(
                f"{item['label']}\n"
                f"  2 : {item['2']}\n"
                f"  1 : {item['1']}\n"
                f"  0 : {item['0']}"
            )
            marks[name] = _mark(ask, "Note (0, 1, 2 ; q) : ")
        row.update(marks)
        row["comment"] = ask("Commentaire (Entrée si aucun) : ")
        row["grader"] = grader
        _save(path, rows)


def _grade_reservations(path, grader, ask, show) -> None:
    rows = _read(path)
    for number, row in enumerate(rows, 1):
        if row["useful_0_1_2"].strip():
            continue
        show(
            f"\n=== Réserves {number} sur {len(rows)} ===\n"
            "Ici, ce n'est plus à l'aveugle : ces réserves "
            "viennent du vérificateur du workflow.\n\n"
            f"QUESTION\n{row['question']}\n\n"
            f"SORTIE COMPLÈTE\n{row['full_output']}\n"
        )
        row["useful_0_1_2"] = _mark(
            ask,
            "Ces réserves aident-elles ? "
            "(0 non, 1 un peu, 2 oui ; q) : ",
        )
        row["comment"] = ask("Commentaire (Entrée si aucun) : ")
        row["grader"] = grader
        _save(path, rows)


def session(
    folder: Path, grid: dict, ask=input, show=print
) -> bool:
    """True when everything is graded."""
    sheets = sorted(folder.glob("sheet-*.csv"))
    left = sum(
        1 for s in sheets for row in _read(s) if _todo(row)
    )
    if not left:
        show("Rien à noter dans les fiches à l'aveugle.")
    else:
        show(
            f"{left} réponse(s) à noter. Ne cherchez pas à "
            "deviner leur origine, et n'ouvrez pas key-*.json. "
            "q arrête ; tout est déjà enregistré."
        )
    grader = ""
    while not grader:
        grader = ask(
            "Votre nom (une personne, pas un modèle) : "
        )
        grader = grader.strip()
    try:
        for sheet in sheets:
            _grade_sheet(sheet, grid, grader, ask, show)
        for path in sorted(folder.glob("reservations-*.csv")):
            _grade_reservations(path, grader, ask, show)
    except Quit:
        show(
            "Arrêt : relancez la même commande pour continuer."
        )
        return False
    show("Notation terminée, merci.")
    return True
