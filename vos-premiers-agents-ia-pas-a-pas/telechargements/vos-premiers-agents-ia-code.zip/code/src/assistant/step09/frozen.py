"""A frozen copy of the documents, for the comparison.

Both architectures read the same copy. Its digests are checked
before EVERY run, not only at the start: a file changed during
the experiment stops it, instead of biasing it silently.
"""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

from assistant.corpus import Corpus

MANIFEST = "MANIFEST.json"


class FrozenCorpusChanged(Exception):
    """The copy no longer matches its manifest."""


def _digests(folder: Path) -> dict[str, str]:
    return {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(folder.glob("*.md"))
    }


def freeze(source: Path, target: Path) -> dict[str, str]:
    """Copy once: an existing copy is never overwritten."""
    if target.exists():
        raise FileExistsError(f"already frozen: {target}")
    target.mkdir(parents=True)
    for path in sorted(source.glob("*.md")):
        shutil.copyfile(path, target / path.name)
    digests = _digests(target)
    (target / MANIFEST).write_text(
        json.dumps(digests, indent=1, sort_keys=True) + "\n",
        "utf-8",
    )
    return digests


def changes(folder: Path) -> list[str]:
    saved = json.loads((folder / MANIFEST).read_text("utf-8"))
    now = _digests(folder)
    return sorted(
        name
        for name in saved.keys() | now.keys()
        if saved.get(name) != now.get(name)
    )


# [snippet:load-frozen]
def load_frozen(folder: Path, lang: str) -> Corpus:
    changed = changes(folder)
    if changed:
        raise FrozenCorpusChanged(" ".join(changed))
    return Corpus.load(folder, lang)


# [/snippet]
