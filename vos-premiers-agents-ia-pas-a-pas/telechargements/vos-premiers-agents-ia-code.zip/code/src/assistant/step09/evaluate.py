"""The comparative experiment: rounds, rules, results, report.

Rules enforced here, written down before any real run:
- the same frozen documents and questions for both;
- tuning first; limits may change only then, with a written
  justification; after the first final run nothing changes: the
  fingerprint of prompts, code, tasks, grid, limits and number
  of rounds is locked;
- the number of final rounds is fixed before the first one; a
  round starts only if its maximal cost fits under the limit
  given for this run; results never change that number;
- every attempt is appended to the results, never removed;
- an API failure gets one new attempt, both kept;
- a partial round stays visible, never counted as complete;
- the report has no "winner" line, and calls itself exploratory.
"""

from __future__ import annotations

import hashlib
import json
import random
import textwrap
import time
from pathlib import Path

from assistant.budget import (
    CapReached,
    GuardedModel,
    SpendGuard,
)
from assistant.config import CODE_DIR
from assistant.corpus import Corpus
from assistant.messages import t
from assistant.protocol import (
    CAP_USD,
    FIRST_MODEL,
    MAX_INPUT_TOKENS,
    REF_DATE,
    max_per_call,
)
from assistant.step09.compare import (
    ARCHITECTURES,
    RUNNERS,
    Outcome,
    RunLimits,
)
from assistant.step09.frozen import load_frozen
from assistant.step09.grading import last_attempts
from assistant.step09.score import auto_score, summary
from assistant.step09.tasks import EvalTask, load_tasks

EXPERIMENT = CODE_DIR / "experiments" / "ch09"
SRC = Path(__file__).resolve().parents[1]
INITIAL_LIMITS = RunLimits()
WIDTH = 64
SEED = "rivelune-ch09-v1"  # fixed before any real run
FINGERPRINTED = [
    "prompts/step04.fr.txt",
    "prompts/step08-researcher.fr.txt",
    "prompts/step08-writer.fr.txt",
    "prompts/step08-verifier.fr.txt",
    "step04/agent.py",
    "step04/tools.py",
    "step05/bm25.py",
    "step08/contracts.py",
    "step08/roles.py",
    "step09/compare.py",
]


class RoundRefused(Exception):
    """The rules of the experiment forbid this round."""


def load_config(experiment: Path = EXPERIMENT) -> dict:
    path = experiment / "config.json"
    return json.loads(path.read_text("utf-8"))


def limits_of(config: dict) -> RunLimits:
    return RunLimits(**config["limits"])


def fingerprint(experiment: Path = EXPERIMENT) -> str:
    digest = hashlib.sha256(FIRST_MODEL.encode())
    paths = [SRC / name for name in FINGERPRINTED] + [
        experiment / "tasks.json",
        experiment / "config.json",
        experiment / "grading-grid.json",
        experiment / "corpus" / "MANIFEST.json",
    ]
    for path in paths:
        digest.update(path.read_bytes())
    return digest.hexdigest()[:16]


def round_runs(tasks: list[EvalTask], split: str) -> int:
    count = sum(1 for t in tasks if t.split == split)
    return count * len(ARCHITECTURES)


def round_max_usd(
    runs: int, limits: RunLimits = INITIAL_LIMITS
) -> float:
    return runs * limits.max_calls * max_per_call(FIRST_MODEL)


def run_order(
    tasks: list[EvalTask], split: str, number: int
) -> list[tuple[EvalTask, str]]:
    """Fixed in advance: which architecture goes first changes
    from task to task, so that time does not favour either."""
    chosen = [t for t in tasks if t.split == split]
    rng = random.Random(f"{SEED}:{split}:{number}")
    rng.shuffle(chosen)
    order = []
    for task in chosen:
        pair = list(ARCHITECTURES)
        rng.shuffle(pair)
        order += [(task, arch) for arch in pair]
    return order


class Results:
    """Append-only: a row, once written, stays."""

    def __init__(self, path: Path):
        self.path = path
        self.rows: list[dict] = []
        if path.exists():
            for line in path.read_text("utf-8").splitlines():
                if line.strip():
                    self.rows.append(json.loads(line))

    def add(self, row: dict) -> None:
        self.rows.append(row)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def rounds(self, split: str) -> list[int]:
        return sorted(
            {
                r["round"]
                for r in self.rows
                if r["split"] == split
            }
        )


# [snippet:check-limits]
def check_limits(config: dict, tuning_done: bool) -> None:
    """Limits change only after tuning, and with a reason."""
    changes = config["limit_changes"]
    if limits_of(config) == INITIAL_LIMITS and not changes:
        return
    if not tuning_done:
        raise RoundRefused(
            "limits may change only after a tuning round"
        )
    if not changes or not all(
        c.get("justification", "").strip() for c in changes
    ):
        raise RoundRefused(
            "a change of limits needs a written justification"
        )


# [/snippet]


def round_limits(
    config: dict, split: str, tuning_done: bool
) -> RunLimits:
    """The first tuning round always runs at the initial limits:
    a change recorded later needs that round to justify it, and
    a replay in a new folder follows the same path."""
    if split == "tuning" and not tuning_done:
        return INITIAL_LIMITS
    check_limits(config, tuning_done)
    return limits_of(config)


def check_round(
    split: str,
    results: Results,
    tasks: list[EvalTask],
    spent: float,
    current: str,
    config: dict,
    limit_usd: float = CAP_USD,
) -> int:
    """The number of the round, or RoundRefused. `limit_usd` is
    the limit the program applies: nothing may pass it."""
    tuning, final = (
        results.rounds("tuning"),
        results.rounds("final"),
    )
    limits = round_limits(config, split, bool(tuning))
    needed = round_max_usd(round_runs(tasks, split), limits)
    if split == "tuning":
        if final:
            raise RoundRefused(
                "final runs exist: no more tuning; adjusting "
                "now would need new final tasks"
            )
        if len(tuning) >= config["tuning_rounds_max"]:
            raise RoundRefused("tuning rounds used up")
    else:
        if not tuning:
            raise RoundRefused("run a tuning round first")
        if len(final) >= config["final_rounds_planned"]:
            raise RoundRefused("planned final rounds done")
        locked = {
            r["fingerprint"]
            for r in results.rows
            if r["split"] == "final"
        }
        if locked and locked != {current}:
            raise RoundRefused(
                "prompts, code, tasks, grid, limits or rounds "
                "changed since the first final run"
            )
    if spent + needed > limit_usd:
        raise RoundRefused(
            f"maximal cost {needed:.2f} USD does not fit: "
            f"spent {spent:.2f}, limit {limit_usd:.2f}"
        )
    return len(tuning if split == "tuning" else final) + 1


def _one_attempt(
    make_model,
    task: EvalTask,
    arch: str,
    corpus: Corpus,
    ledger,
    cap: float,
    phase: str,
    limits: RunLimits,
    max_call_usd: float | None = None,
) -> tuple[Outcome, dict]:
    before = ledger.charged_usd
    guard = SpendGuard(
        cap,
        limits.max_calls,
        MAX_INPUT_TOKENS,
        ledger=ledger,
        phase=phase,
        max_call_usd=max_call_usd,
    )
    model = GuardedModel(make_model(task, arch), guard)
    start = time.monotonic()
    outcome = RUNNERS[arch](
        model, task.question, corpus, REF_DATE, limits
    )
    return outcome, {
        "calls": guard.calls,
        "tokens": sum(outcome.tokens_by_role.values()),
        "charged_usd": ledger.charged_usd - before,
        "seconds": round(time.monotonic() - start, 2),
    }


def run_round(
    split: str,
    make_model,
    source: str,
    experiment: Path,
    folder: Path,
    ledger,
    limit_usd: float = CAP_USD,
    max_call_usd: float | None = None,
) -> dict:
    tasks = load_tasks(experiment / "tasks.json")
    config = load_config(experiment)
    results = Results(folder / "runs.jsonl")
    current = fingerprint(experiment)
    limits = round_limits(
        config, split, bool(results.rounds("tuning"))
    )
    number = check_round(
        split,
        results,
        tasks,
        ledger.charged_usd,
        current,
        config,
        limit_usd,
    )
    cap = limit_usd
    stopped = None
    for task, arch in run_order(tasks, split, number):
        slot = f"{split}:{number}:{task.id}:{arch}"
        if stopped:
            results.add(
                _not_run(
                    split,
                    number,
                    task,
                    arch,
                    slot,
                    stopped,
                    source,
                    current,
                )
            )
            continue
        for attempt in (1, 2):
            # Checked before EVERY run; raises if changed.
            corpus = load_frozen(experiment / "corpus", "fr")
            run_id = f"{slot}:{attempt}"
            before = ledger.charged_usd
            try:
                outcome, cost = _one_attempt(
                    make_model,
                    task,
                    arch,
                    corpus,
                    ledger,
                    cap,
                    run_id,
                    limits,
                    max_call_usd,
                )
            except CapReached as stop:
                stopped = str(stop)
                row = _not_run(
                    split,
                    number,
                    task,
                    arch,
                    slot,
                    stopped,
                    source,
                    current,
                )
                # What this run spent before the stop.
                row["charged_usd"] = ledger.charged_usd - before
                results.add(row)
                break
            results.add(
                {
                    "run_id": run_id,
                    "slot": slot,
                    "source": source,
                    "model": FIRST_MODEL,
                    "fingerprint": current,
                    "split": split,
                    "round": number,
                    "task": task.id,
                    "category": task.category,
                    "architecture": arch,
                    "attempt": attempt,
                    "kind": outcome.kind,
                    "status": outcome.status,
                    # The common final answer, graded blind.
                    "answer": outcome.answer,
                    # All that the user would see.
                    "full_output": outcome.full_output,
                    "objections": outcome.objections,
                    "revisions": outcome.revisions,
                    "calls_by_role": outcome.calls_by_role,
                    "auto": auto_score(
                        task,
                        outcome.answer,
                        corpus,
                        outcome.consulted,
                    ),
                    **cost,
                }
            )
            if outcome.kind != "api_error":
                break
    return {"split": split, "round": number, "stopped": stopped}


def _not_run(
    split, number, task, arch, slot, why, source, current
) -> dict:
    """Kept too: a missing run must stay visible."""
    return {
        "run_id": f"{slot}:not-run",
        "slot": slot,
        "source": source,
        "model": FIRST_MODEL,
        "fingerprint": current,
        "split": split,
        "round": number,
        "task": task.id,
        "category": task.category,
        "architecture": arch,
        "attempt": 0,
        "kind": "not_run",
        "status": why,
        "answer": "",
        "full_output": "",
        "objections": [],
        "revisions": 0,
        "calls_by_role": {},
        "auto": {},
        "calls": 0,
        "tokens": 0,
        "charged_usd": 0.0,
        "seconds": 0.0,
    }


def _wrap(text: str, indent: str = "") -> list[str]:
    return textwrap.wrap(
        text,
        WIDTH,
        initial_indent=indent,
        subsequent_indent=indent + "  ",
        break_on_hyphens=False,
    )


def round_states(
    rows: list[dict], expected: int
) -> tuple[list[int], list[int]]:
    """(complete rounds, partial rounds). A round is complete
    only if every run of both architectures was carried out."""
    complete, partial = [], []
    for number in sorted({r["round"] for r in rows}):
        mine = [r for r in rows if r["round"] == number]
        slots = {
            r["slot"] for r in mine if r["kind"] != "not_run"
        }
        (
            complete if len(slots) == expected else partial
        ).append(number)
    return complete, partial


def report(
    rows: list[dict],
    grades: dict[str, dict],
    tasks: list[EvalTask],
    config: dict,
    lang: str = "fr",
) -> str:
    lines = []
    if any(r["source"] == "simulated" for r in rows):
        lines += _wrap(t(lang, "rep_sim"))
    lines += _wrap(t(lang, "rep_exp"))
    for split in ("tuning", "final"):
        chosen = [r for r in rows if r["split"] == split]
        if not chosen:
            continue
        lines.append("")
        lines += _split_report(
            split, chosen, grades, tasks, config, lang
        )
    return "\n".join(lines)


def _split_report(split, chosen, grades, tasks, config, lang):
    expected = round_runs(tasks, split)
    complete, partial = round_states(chosen, expected)
    planned = (
        config["final_rounds_planned"]
        if split == "final"
        else config["tuning_rounds_max"]
    )
    key = "rep_final" if split == "final" else "rep_tuning"
    lines = [f"== {t(lang, key)} =="]
    lines += _wrap(
        t(lang, "rep_head").format(
            tasks=expected // len(ARCHITECTURES),
            model=chosen[0]["model"],
        )
    )
    lines += _wrap(
        t(lang, "rep_rounds").format(
            complete=len(complete),
            partial=len(partial),
            planned=planned,
        )
    )
    full = [r for r in chosen if r["round"] in complete]
    for arch in ARCHITECTURES:
        mine = [r for r in full if r["architecture"] == arch]
        if mine:
            lines += _block(
                arch, summary(mine, grades, tasks), lang
            )
    if split == "final" and full:
        lines += _pairs(full, grades, tasks, lang)
    for number in partial:
        lines += _partial(chosen, number, expected, lang)
    return lines


def _partial(chosen, number, expected, lang) -> list[str]:
    """Traces kept, outside the counts of complete rounds."""
    mine = [r for r in chosen if r["round"] == number]
    done = {r["slot"] for r in mine if r["kind"] != "not_run"}
    broken = sorted(
        {r["task"] for r in mine if r["kind"] == "not_run"}
    )
    return _wrap(
        t(lang, "rep_partial").format(
            number=number,
            done=len(done),
            expected=expected,
            tasks=" ".join(broken),
        )
    )


def _block(arch: str, s: dict, lang: str) -> list[str]:
    lines = [
        "-- "
        + t(lang, "rep_runs").format(
            arch=t(lang, f"rep_{arch}"),
            runs=s["runs"],
            attempts=s["attempts"],
        )
    ]
    kinds = ", ".join(f"{k} {v}" for k, v in s["kinds"].items())
    lines += _wrap(
        t(lang, "rep_outcomes").format(kinds=kinds), "   "
    )
    lines += _wrap(
        t(lang, "rep_graded").format(
            graded=s["graded"],
            none=s["no_answer"],
            pending=s["pending"],
        ),
        "   ",
    )
    for name, (got, total) in s["points"].items():
        label = t(lang, f"crit_{name}")
        lines.append(f"     {label}: {got}/{total}")
    auto = ", ".join(f"{k} {v}" for k, v in s["auto"].items())
    lines += _wrap(
        t(lang, "rep_auto").format(runs=s["runs"], auto=auto),
        "   ",
    )
    lines += _wrap(
        t(lang, "rep_usage").format(
            calls=s["calls"], tokens=s["tokens"]
        ),
        "   ",
    )
    lines += _wrap(
        t(lang, "rep_time").format(
            seconds=s["seconds"], usd=f"{s['usd_charged']:.4f}"
        ),
        "   ",
    )
    limits = ", ".join(
        f"{k} {v}" for k, v in s["limits"].items()
    )
    lines += _wrap(
        t(lang, "rep_limits").format(limits=limits or "0"),
        "   ",
    )
    lines += _wrap(
        t(lang, "rep_objected").format(
            objected=s["objected"], revised=s["revised"]
        ),
        "   ",
    )
    return lines


def _pairs(rows, grades, tasks, lang) -> list[str]:
    """Task by task, by a person's grades; no verdict drawn."""
    by_id = {x.id: x for x in tasks}
    scores: dict[str, dict[str, list[float]]] = {}
    ungraded = set()
    for row in last_attempts(rows):
        name = row["task"]
        if not row["answer"]:
            value = 0.0
        elif row["run_id"] in grades:
            marks = grades[row["run_id"]]
            value = sum(marks.values()) / (2 * len(marks))
        else:
            ungraded.add(name)
            continue
        scores.setdefault(name, {}).setdefault(
            row["architecture"], []
        ).append(value)
    agent = team = equal = 0
    for name in by_id:
        pair = scores.get(name, {})
        if name in ungraded or len(pair) < 2:
            continue
        a = sum(pair["agent"]) / len(pair["agent"])
        b = sum(pair["team"]) / len(pair["team"])
        agent += a > b
        team += b > a
        equal += a == b
    return _wrap(
        "-- "
        + t(lang, "rep_pairs").format(
            agent=agent,
            team=team,
            equal=equal,
            ungraded=len(ungraded),
        )
    )
