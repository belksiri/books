"""Scripted runs for `assistant evaluate --dry-run`.

They exercise the program only. The answers are written by hand
from the expected passages: they always succeed, they do not
rank the architectures and say nothing about a real model.
"""

from __future__ import annotations

from assistant.llm import FakeModel
from assistant.step09.tasks import EvalTask


def _refs(task: EvalTask) -> list[str]:
    return [group[0] for group in task.expected_refs]


def _reads(task: EvalTask) -> list:
    docs = list(
        dict.fromkeys(r.split("#")[0] for r in _refs(task))
    )
    turns = [
        FakeModel.calls(("search_documents", {"query": "vélo"}))
    ]
    if docs:
        turns.append(
            FakeModel.calls(
                *[
                    ("read_document", {"doc_id": d})
                    for d in docs
                ]
            )
        )
    return turns


def _facts(task: EvalTask) -> str:
    return " ".join(group[0] for group in task.must_state)


def agent_script(task: EvalTask, corpus) -> FakeModel:
    if task.absent:
        text = "Les documents ne donnent pas cette information."
    else:
        sources = [
            f"- [{r}] « {corpus.passage(r).text[:40]} »"
            for r in _refs(task)
        ]
        cited = " ".join(f"[{r}]" for r in _refs(task))
        text = "\n".join(
            [
                f"Réponse simulée {_facts(task)} {cited}.",
                "",
                "Sources",
                *sources,
            ]
        )
    return FakeModel([*_reads(task), FakeModel.says(text)])


def team_script(task: EvalTask, corpus) -> FakeModel:
    if task.absent:
        brief = {
            "evidence": [],
            "gaps": ["Absent des documents."],
        }
        return FakeModel(
            [
                *_reads(task),
                FakeModel.calls(("submit_brief", brief)),
            ]
        )
    refs = _refs(task)
    brief = {
        "evidence": [
            {
                "ref": r,
                "quote": corpus.passage(r).text[:40],
                "note": "simulé",
            }
            for r in refs
        ],
        "gaps": [],
    }
    claims = [
        {
            "text": f"Réponse simulée {_facts(task)}",
            "refs": refs,
        }
    ]
    verdicts = [
        {"claim": 1, "supported": True, "reason": "simulé"}
    ]
    return FakeModel(
        [
            *_reads(task),
            FakeModel.calls(("submit_brief", brief)),
            FakeModel.json({"claims": claims}),
            FakeModel.calls(
                ("submit_review", {"verdicts": verdicts})
            ),
        ]
    )


SCRIPTS = {"agent": agent_script, "team": team_script}
