"""The human grade: a person, a grid, no sight of the origin.

Two views. The blind forms show the same deliverable for both
architectures: the final answer. The verifier's reservations
would name the architecture: they stay in the archive, with the
full output, and their use is reviewed apart, not blind.

The sheets hide the architecture, the cost, the calls and the
duration, and mix the answers. Nothing here computes a grade:
an answer stays ungraded until a person has given every grade.
Limits: one grader, and the style may betray the origin.
"""

from __future__ import annotations

import csv
import json
import random
import secrets
from pathlib import Path

from assistant.step09.tasks import EvalTask

CRITERIA = (
    "exactitude",
    "sources",
    "contradictions",
    "absence",
)
NOT_APPLICABLE = "n/a"


def last_attempts(rows: list[dict]) -> list[dict]:
    finals: dict[str, dict] = {}
    for row in rows:
        finals[row["slot"]] = row
    return list(finals.values())


def _keys(folder: Path) -> list[Path]:
    return sorted(folder.glob("key-*.json"))


def new_batch(
    rows: list[dict],
    tasks: list[EvalTask],
    grid: dict,
    folder: Path,
    split: str,
) -> Path | None:
    """Sheets for the answers not yet given to the grader.

    Never touches an earlier sheet: grades already entered stay.
    """
    folder.mkdir(parents=True, exist_ok=True)
    given: set[str] = set()
    for path in _keys(folder):
        given |= set(
            json.loads(path.read_text("utf-8")).values()
        )
    chosen = [
        r
        for r in last_attempts(rows)
        if r["split"] == split
        and r["answer"]
        and r["run_id"] not in given
    ]
    if not chosen:
        return None
    rng = random.SystemRandom()
    rng.shuffle(chosen)
    number = len(_keys(folder)) + 1
    by_id = {t.id: t for t in tasks}
    key, lines = {}, []
    for row in chosen:
        answer_id = secrets.token_hex(4)
        key[answer_id] = row["run_id"]
        task = by_id[row["task"]]
        line = {
            "answer_id": answer_id,
            "question": task.question,
            "key_points": task.key_points,
            "answer": row["answer"],
        }
        for name in CRITERIA:
            line[name] = (
                "" if name in task.criteria else NOT_APPLICABLE
            )
        line["comment"] = ""
        line["grader"] = ""
        lines.append(line)
    sheet = folder / f"sheet-{number}.csv"
    with open(sheet, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(lines[0]))
        writer.writeheader()
        writer.writerows(lines)
    (folder / f"key-{number}.json").write_text(
        json.dumps(key, indent=1), "utf-8"
    )
    (folder / f"forms-{number}.md").write_text(
        _forms(lines, grid), "utf-8"
    )
    _reservations(chosen, by_id, folder, number)
    return sheet


def _reservations(chosen, by_id, folder, number) -> None:
    """Not blind: to judge whether the reservations help."""
    lines = [
        {
            "run_id": row["run_id"],
            "question": by_id[row["task"]].question,
            "full_output": row["full_output"],
            "useful_0_1_2": "",
            "comment": "",
            "grader": "",
        }
        for row in chosen
        if row["objections"]
    ]
    path = folder / f"reservations-{number}.csv"
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "run_id",
                "question",
                "full_output",
                "useful_0_1_2",
                "comment",
                "grader",
            ],
        )
        writer.writeheader()
        writer.writerows(lines)


def _forms(lines: list[dict], grid: dict) -> str:
    """Printable forms: one per answer. Grades go in the CSV."""
    out = [
        "# Fiches de notation",
        "",
        "Notez sans ouvrir `key-*.json`. L'origine, le coût et "
        "la durée sont masqués. 0, 1 ou 2 ; `n/a` déjà rempli.",
        "",
    ]
    for line in lines:
        out += [
            f"## Réponse {line['answer_id']}",
            "",
            f"**Question.** {line['question']}",
            "",
            f"**Points attendus.** {line['key_points']}",
            "",
            "**Réponse à noter**",
            "",
            *[f"> {x}" for x in line["answer"].splitlines()],
            "",
        ]
        for name in CRITERIA:
            if line[name] == NOT_APPLICABLE:
                continue
            item = grid[name]
            out += [
                f"- {item['label']} : ☐ 2 {item['2']} "
                f"☐ 1 {item['1']} ☐ 0 {item['0']}"
            ]
        out.append("")
    return "\n".join(out)


def read_grades(folder: Path) -> dict[str, dict]:
    """run_id -> grades, only for answers fully graded and
    signed by a person. A bad value stops: no silent guess."""
    grades: dict[str, dict] = {}
    for key_file in _keys(folder):
        number = key_file.stem.split("-")[1]
        key = json.loads(key_file.read_text("utf-8"))
        sheet = folder / f"sheet-{number}.csv"
        with open(sheet, encoding="utf-8", newline="") as f:
            for line in csv.DictReader(f):
                parsed = _parse(line)
                if parsed is not None:
                    grades[key[line["answer_id"]]] = parsed
    return grades


# [snippet:parse-grade]
def _parse(line: dict) -> dict | None:
    marks = {}
    for name in CRITERIA:
        value = line[name].strip()
        if value == NOT_APPLICABLE:
            continue
        if value == "":
            return None
        if value not in ("0", "1", "2"):
            raise ValueError(
                f"{line['answer_id']}: bad grade {value!r}"
            )
        marks[name] = int(value)
    if not line["grader"].strip():
        raise ValueError(
            f"{line['answer_id']}: graded but not signed"
        )
    return marks


# [/snippet]
