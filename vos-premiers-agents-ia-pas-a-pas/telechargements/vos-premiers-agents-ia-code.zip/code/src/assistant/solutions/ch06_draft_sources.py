"""Chapter 6 exercise, one possible solution.

A check that flags the sections relying on a document whose
status says it is a draft. It is a signal for the reader,
not an error: a section may cite a draft on purpose, to say
what was proposed.
"""

from __future__ import annotations

from assistant.corpus import Corpus
from assistant.step05.citations import REF
from assistant.step06.mission import MissionState
from assistant.step06.verify import Check
from assistant.text import normalize

# First word of a draft status, in the four corpus languages.
DRAFT_WORDS = {"projet", "draft", "proyecto", "entwurf"}


def is_draft(status: str) -> bool:
    words = normalize(status).replace(",", " ").split()
    return bool(words) and words[0] in DRAFT_WORDS


def draft_sources(state: MissionState, corpus: Corpus) -> Check:
    flagged = []
    for step in state.plan.steps:
        answer = state.result(step.id).answer
        for ref in dict.fromkeys(REF.findall(answer)):
            doc = corpus.get(ref.partition("#")[0])
            if doc and is_draft(doc.meta.get("status", "")):
                flagged.append(f"{step.id}:{doc.id}")
    # ok=True: only a signal; the detail lists what to read.
    return Check("draft_sources", True, " ".join(flagged))
