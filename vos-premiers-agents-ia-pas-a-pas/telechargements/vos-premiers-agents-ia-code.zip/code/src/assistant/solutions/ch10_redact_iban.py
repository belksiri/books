"""Chapter 10 exercise, one possible solution.

One more pattern to mask. Spaces are allowed inside the number,
and the two check digits keep ordinary references out. The
IBAN is masked FIRST: the phone pattern of `redact` would
otherwise eat its digits and leave the country letters.
"""

from __future__ import annotations

import re

from assistant.step10.redact import redact

IBAN = re.compile(
    r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}"
    r"(?: ?[A-Z0-9]{1,3})?\b"
)


def redact_with_iban(text: str) -> str:
    return redact(IBAN.sub("[personal]", text))
