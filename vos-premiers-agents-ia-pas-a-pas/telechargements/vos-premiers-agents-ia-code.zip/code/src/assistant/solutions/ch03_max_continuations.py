"""Chapter 3 exercise, one possible solution.

The loop of step 03, with a limit on the requests to continue:
a reply cut again and again stops with its own status, before
it uses all the turns.
"""

from __future__ import annotations

from assistant.runstate import Limits, RunState
from assistant.step03.agent import CONTINUE, RunResult


def run_capped(
    model,
    system: str,
    question: str,
    limits: Limits | None = None,
    max_continuations: int = 2,
) -> RunResult:
    state = RunState(limits or Limits())
    messages = [{"role": "user", "content": question}]
    parts: list[str] = []
    continuations = 0
    while True:
        reason = state.exceeded()
        if reason:
            return RunResult(reason, "".join(parts), state)
        reply = model.complete(system, messages)
        state.turns += 1
        state.usage += reply.usage
        state.log(f"turn {state.turns}: {reply.stop_reason}")
        messages.append(
            {"role": "assistant", "content": reply.content}
        )
        parts.append(reply.text)
        if reply.stop_reason == "end_turn":
            return RunResult("done", "".join(parts), state)
        if reply.stop_reason != "max_tokens":
            status = f"stopped:{reply.stop_reason}"
            return RunResult(status, "".join(parts), state)
        if continuations >= max_continuations:
            status = "max_continuations"
            return RunResult(status, "".join(parts), state)
        continuations += 1
        messages.append({"role": "user", "content": CONTINUE})
