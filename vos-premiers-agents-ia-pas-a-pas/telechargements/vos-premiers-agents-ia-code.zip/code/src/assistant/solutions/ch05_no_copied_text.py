"""Chapter 5 exercise, one possible solution.

Refuse to remember a text that copies a document passage
(8 words or more in a row). Documents are data, not trusted
preferences: copying them into memory would let an injected
instruction survive into every later session.
"""

from __future__ import annotations

from assistant.corpus import Corpus
from assistant.memory import MemoryRefused, MemoryStore
from assistant.text import normalize


def _words(text: str) -> list[str]:
    return normalize(text).split()


def copied_from(
    text: str, corpus: Corpus, n: int = 8
) -> str | None:
    """Passage sharing n words in a row with text, or None."""
    words = _words(text)
    grams = {
        tuple(words[i : i + n])
        for i in range(len(words) - n + 1)
    }
    if not grams:
        return None
    for passage in corpus.all_passages():
        pw = _words(passage.text)
        for i in range(len(pw) - n + 1):
            if tuple(pw[i : i + n]) in grams:
                return passage.ref
    return None


class GuardedMemory(MemoryStore):
    def __init__(self, corpus: Corpus, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.corpus = corpus

    def remember(self, kind: str, text: str):
        ref = copied_from(text, self.corpus)
        if ref:
            raise MemoryRefused(f"text copied from {ref}")
        return super().remember(kind, text)
