"""Chapter 11 exercise, one possible solution.

Too many wrong passwords close the door for a while, even for
the right one. Kept in memory: a restart forgets it, and with
one shared password one person can lock out everybody.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field

from assistant.step11.service import check_password


@dataclass
class LoginThrottle:
    max_failures: int = 5
    window_seconds: float = 900.0
    clock: Callable[[], float] = time.monotonic
    failures: list[float] = field(default_factory=list)

    def locked(self) -> bool:
        limit = self.clock() - self.window_seconds
        self.failures = [t for t in self.failures if t > limit]
        return len(self.failures) >= self.max_failures

    def attempt(self, given: str, expected: str | None) -> bool:
        if self.locked():
            return False
        if check_password(given, expected):
            self.failures.clear()
            return True
        self.failures.append(self.clock())
        return False
