"""Chapter 8 exercise, one possible solution.

A limit per role, on top of the limits shared by the team, so
that a researcher who wanders off leaves calls for the others.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from assistant.llm import ModelError
from assistant.step08.orchestrator import TeamBudget


@dataclass
class RoleBudget(TeamBudget):
    per_role: dict[str, int] = field(default_factory=dict)

    def check(self, role: str = "") -> None:
        super().check(role)
        cap = self.per_role.get(role)
        if cap is not None and self.calls.get(role, 0) >= cap:
            raise ModelError(
                f"{role}: call limit reached", False
            )
