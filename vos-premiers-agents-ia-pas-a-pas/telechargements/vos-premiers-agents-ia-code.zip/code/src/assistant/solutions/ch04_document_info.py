"""Chapter 4 exercise, one possible solution: `document_info`.

Returns a document header (title, date, status) without its
passages, so the agent can compare dates cheaply.
"""

from __future__ import annotations

from pathlib import Path

from assistant.corpus import Corpus
from assistant.step04.extend import ExtendedToolbox, with_tools
from assistant.step04.tools import (
    DESCRIPTIONS,
    READ_SCHEMA,
    ReadParams,
    Tool,
    ToolError,
    build_toolbox,
)


def build_toolbox_with_info(
    corpus: Corpus, notes_dir: Path, consulted: dict[str, str]
) -> ExtendedToolbox:
    base = build_toolbox(corpus, notes_dir, consulted)

    def document_info(args: ReadParams) -> str:
        doc = corpus.get(args.doc_id)
        if doc is None:
            raise ToolError(
                f"No document '{args.doc_id}'. Call"
                " list_documents to see valid ids."
            )
        # No passage is shown, so none is marked consulted.
        return " | ".join(
            f"{k}: {v}" for k, v in doc.meta.items()
        )

    info = Tool(
        "document_info",
        "Return the header of a document (title, date,"
        " status) without its passages.",
        READ_SCHEMA,
        ReadParams,
        document_info,
    )
    assert "document_info" not in DESCRIPTIONS
    return with_tools(base, info)
