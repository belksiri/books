"""Chapter 7 exercise, one possible solution.

Refuse a sending whose text holds a link outside a list of
domains. A link is a classic way to smuggle data out: the
address itself can carry it. The check comes BEFORE the person
is asked. It does not replace their reading: it only catches
links written in full.
"""

from __future__ import annotations

import re
from urllib.parse import urlparse

from assistant.approval import ProposedAction
from assistant.step07.gate import GateRefused, SendGate

LINK = re.compile(r"https?://\S+", re.IGNORECASE)
# A link at the end of a sentence: "… https://site.org/x."
TRAILING = ".,;:!?)]»\"'"


def foreign_links(text: str, domains: set[str]) -> list[str]:
    links = [
        link.rstrip(TRAILING) for link in LINK.findall(text)
    ]
    return [
        link
        for link in links
        if urlparse(link).hostname not in domains
    ]


class LinkGuardGate(SendGate):
    def __init__(self, domains: set[str], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.domains = domains

    def submit(self, target: str, content: str):
        found = foreign_links(content, self.domains)
        if found:
            # Like the other refusals of the gate: journaled.
            action = ProposedAction(
                "send_summary", target, content
            )
            self.journal.add(
                "refused", action.digest(), why="link"
            )
            raise GateRefused(f"link not allowed: {found[0]}")
        return super().submit(target, content)
