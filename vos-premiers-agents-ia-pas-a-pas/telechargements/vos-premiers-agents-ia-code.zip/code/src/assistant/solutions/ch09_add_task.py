"""Chapter 9 exercise, one possible solution.

Add a task to YOUR COPY of the experiment. The official folder
and its lock stay untouched: its fingerprint covers tasks.json,
so a new task there would forbid any further final run.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from assistant.step09.evaluate import EXPERIMENT
from assistant.step09.frozen import load_frozen
from assistant.step09.tasks import EvalTask, load_tasks


def my_copy(target: Path) -> Path:
    """A separate experiment; an existing folder is refused."""
    shutil.copytree(EXPERIMENT, target)
    return target


def add_task(experiment: Path, item: dict) -> EvalTask:
    if experiment.resolve() == EXPERIMENT.resolve():
        raise ValueError("work on your copy, not the original")
    task = EvalTask.model_validate(item)
    path = experiment / "tasks.json"
    tasks = load_tasks(path)
    if task.id in {t.id for t in tasks}:
        raise ValueError(f"task already exists: {task.id}")
    corpus = load_frozen(experiment / "corpus", "fr")
    texts = []
    for group in task.expected_refs:
        for ref in group:
            passage = corpus.passage(ref)
            if passage is None:
                raise ValueError(f"unknown passage: {ref}")
            texts.append(passage.text)
    for group in task.must_state:
        if not any(w in text for w in group for text in texts):
            raise ValueError(f"not in the passages: {group}")
    data = json.loads(path.read_text("utf-8"))
    data.append(task.model_dump())
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=1) + "\n",
        "utf-8",
    )
    return task
