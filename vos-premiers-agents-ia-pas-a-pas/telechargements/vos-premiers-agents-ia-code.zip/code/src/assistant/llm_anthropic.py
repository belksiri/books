"""`ModelClient` implementation for the Claude API.

The only module of the project that imports the `anthropic`
SDK. Written for anthropic==2.3.0 (see docs/sources.md).
"""

from __future__ import annotations

import anthropic

from assistant.llm import (
    ModelError,
    ModelReply,
    ToolCall,
    Usage,
)


class AnthropicModel:
    def __init__(
        self,
        model: str,
        max_tokens: int = 4096,
        effort: str | None = None,
        client: anthropic.Anthropic | None = None,
        max_retries: int = 2,
        timeout: float = 60.0,
        api_key: str | None = None,
    ):
        self.name = model
        self.max_tokens = max_tokens
        self.effort = effort
        # The SDK reads the key from ANTHROPIC_API_KEY.
        # Paid trials use max_retries=0: one check, one request.
        # `timeout` is the only bound acting DURING a call: the
        # client stops waiting. It does not cancel generation on
        # the server, which may still bill the request.
        self._client = client or anthropic.Anthropic(
            max_retries=max_retries,
            timeout=timeout,
            api_key=api_key,
        )

    # [snippet:anthropic-complete]
    def complete(self, system, messages, tools=None):
        params = {
            "model": self.name,
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": messages,
        }
        if tools:
            params["tools"] = tools
        if self.effort:
            params["output_config"] = {"effort": self.effort}
        return self._send(params)

    # [/snippet]

    # [snippet:anthropic-json]
    def complete_json(self, system, messages, schema):
        """Same call, with the reply constrained to `schema`.

        The JSON arrives in the text block. Per the docs it can
        still miss the schema (refusal, max_tokens): validate.
        """
        params = {
            "model": self.name,
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": messages,
            "output_config": {
                "format": {
                    "type": "json_schema",
                    "schema": schema,
                }
            },
        }
        if self.effort:
            params["output_config"]["effort"] = self.effort
        return self._send(params)

    # [/snippet]

    def _send(self, params: dict) -> ModelReply:
        try:
            response = self._client.messages.create(**params)
        except anthropic.APIStatusError as error:
            code = error.status_code
            retry = code == 429 or code >= 500
            raise ModelError(
                str(error), retry, _retry_after(error)
            ) from error
        except anthropic.APIConnectionError as error:
            raise ModelError(str(error), True) from error
        return to_reply(response)


def _retry_after(error) -> float | None:
    """The `retry-after` header in seconds, if there is one."""
    try:
        return float(error.response.headers["retry-after"])
    except (AttributeError, KeyError, TypeError, ValueError):
        return None


def to_reply(response) -> ModelReply:
    texts, calls = [], []
    for block in response.content:
        if block.type == "text":
            texts.append(block.text)
        elif block.type == "tool_use":
            calls.append(
                ToolCall(
                    block.id, block.name, dict(block.input)
                )
            )
    usage = Usage(
        response.usage.input_tokens,
        response.usage.output_tokens,
    )
    return ModelReply(
        stop_reason=response.stop_reason,
        text="\n".join(texts),
        tool_calls=calls,
        usage=usage,
        # SDK blocks go back untouched, including thinking
        # blocks the model expects to find again.
        content=list(response.content),
    )
