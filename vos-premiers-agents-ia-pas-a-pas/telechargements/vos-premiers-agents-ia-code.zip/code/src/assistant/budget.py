"""Spending guard for paid runs: stop BEFORE the cap is passed.

Before each call, the guard computes a worst-case cost:
- input: UTF-8 bytes of the visible request (a token is at
  least one byte), plus every output token already produced in
  this conversation (earlier thinking stays in context and is
  billed as input, even when its text is not returned), plus a
  fixed margin for the tool system prompt and message framing;
- output: `max_tokens`, a strict limit that includes thinking.
The call runs only if `spent + worst_case <= cap`. After the
call, the real cost from `usage` is added. If a real cost ever
exceeds its worst case, the bound is wrong: everything stops.

Every request that leaves the program is a billable attempt
and is written to the ledger BEFORE leaving, at its worst case;
a reply then settles it. A failed or interrupted request returns
no `usage`, so it stays charged at its worst case.
The SDK's automatic retries are disabled for paid trials
(max_retries=0), so one attempt = one HTTP request; any retry
must go through `complete` again and is counted again. The
ledger is cumulative: the cap covers all sessions together.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from assistant.llm import ModelError, ModelReply, Usage
from assistant.pricing import request_cost

FRAMING_MARGIN = 600  # tool prompt (286) + per-message framing
# A planning hypothesis, not an authorization to spend.
PLANNING_CAP_USD = 2.00


class BudgetStop(ModelError):
    """Raised before a call that could pass the cap."""

    def __init__(self, message: str):
        super().__init__(message, retryable=False)


class CapReached(BudgetStop):
    """The cumulative cap: nothing more may run, anywhere."""


def _jsonable(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    return str(value)


def input_bound(
    system, messages, tools, prior_output: int
) -> int:
    payload = json.dumps(
        [system, messages, tools or []],
        ensure_ascii=False,
        default=_jsonable,
    )
    return (
        len(payload.encode("utf-8"))
        + prior_output
        + FRAMING_MARGIN
        + 10 * len(messages)
    )


class Ledger:
    """Append-only record of billable attempts (JSON Lines).

    An attempt is written BEFORE it leaves, at its maximal cost,
    then settled by a second line. If the program is killed in
    between, its cost stays counted at that maximum: an attempt
    of unknown cost cannot escape the cap. The file is read
    again before each check, so that two programs using the same
    ledger see each other. With `path=None` it lives in memory.
    """

    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else None
        self._lines: list[dict] = []
        self._read()

    def _read(self) -> None:
        if self.path and self.path.exists():
            text = self.path.read_text("utf-8")
            self._lines = [
                json.loads(line)
                for line in text.splitlines()
                if line.strip()
            ]

    def refresh(self) -> None:
        self._read()

    def add(self, record: dict) -> None:
        record = {
            "time": datetime.now(UTC).isoformat(
                timespec="seconds"
            ),
            **record,
        }
        self._lines.append(record)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")

    @property
    def records(self) -> list[dict]:
        """One line per attempt: settled, or at its maximum."""
        settled = {
            line["settles"]
            for line in self._lines
            if "settles" in line
        }
        return [
            line
            for line in self._lines
            if line.get("id") not in settled
            or "settles" in line
        ]

    @property
    def charged_usd(self) -> float:
        return sum(r["charged_usd"] for r in self.records)

    @property
    def attempts(self) -> int:
        return len(self.records)


@dataclass
class SpendGuard:
    cap_usd: float  # cumulative, all runs in the ledger
    max_calls: int  # attempts allowed in this session
    max_input_tokens: int = 30_000
    ledger: Ledger = field(default_factory=Ledger)
    phase: str = ""
    calls: int = 0  # attempts in this session
    cap_reached: bool = False  # stays set once refused
    max_call_usd: float | None = None  # per call, if set

    @property
    def spent_usd(self) -> float:
        self.ledger.refresh()
        return self.ledger.charged_usd

    @property
    def log(self) -> list[dict]:
        return self.ledger.records

    def before(
        self, model: str, worst_in: int, max_tokens: int
    ) -> float:
        if self.calls >= self.max_calls:
            raise BudgetStop(
                f"call cap {self.max_calls} reached"
            )
        if worst_in > self.max_input_tokens:
            raise BudgetStop(
                f"request may exceed {self.max_input_tokens}"
                " input tokens"
            )
        try:
            worst = request_cost(
                model, Usage(worst_in, max_tokens)
            )
        except KeyError as error:
            raise BudgetStop(f"no price for {model}") from error
        if (
            self.max_call_usd is not None
            and worst > self.max_call_usd
        ):
            raise BudgetStop(
                f"call may cost {worst:.4f} USD; limit per "
                f"call "
                f"{self.max_call_usd:.4f}"
            )
        if self.spent_usd + worst > self.cap_usd:
            self.cap_reached = True
            raise CapReached(
                f"next call could cost {worst:.4f} USD; spent "
                f"{self.spent_usd:.4f} of {self.cap_usd:.4f}"
            )
        return worst

    def start(self, model: str, worst: float) -> str:
        """Written before the request leaves, at its maximum."""
        attempt = uuid4().hex
        self.ledger.add(
            {
                "id": attempt,
                "phase": self.phase,
                "model": model,
                "status": "started",
                "input": None,
                "output": None,
                "cost_usd": None,
                "worst_usd": worst,
                "charged_usd": worst,
            }
        )
        return attempt

    def after(
        self,
        model: str,
        usage: Usage,
        worst: float,
        attempt: str,
    ) -> float:
        cost = request_cost(model, usage)
        self.calls += 1
        self.ledger.add(
            {
                "settles": attempt,
                "phase": self.phase,
                "model": model,
                "status": "ok",
                "input": usage.input_tokens,
                "output": usage.output_tokens,
                "cost_usd": cost,
                "worst_usd": worst,
                "charged_usd": cost,
            }
        )
        if cost > worst + 1e-12:
            raise BudgetStop(
                "real cost above its worst case: bound broken"
            )
        return cost

    def after_failure(
        self,
        model: str,
        worst: float,
        error: BaseException,
        attempt: str,
    ) -> None:
        """A failed attempt may be billed: charge the worst."""
        self.calls += 1
        self.ledger.add(
            {
                "settles": attempt,
                "phase": self.phase,
                "model": model,
                "status": f"failed: {type(error).__name__}",
                "input": None,
                "output": None,
                "cost_usd": None,
                "worst_usd": worst,
                "charged_usd": worst,
            }
        )


class GuardedModel:
    """Wraps a ModelClient: each attempt is checked, counted."""

    def __init__(self, model, guard: SpendGuard):
        if isinstance(model, GuardedModel):
            # Two guards would count each attempt twice.
            raise ValueError("this model is already guarded")
        self.model, self.guard = model, guard
        self.name = model.name
        # Must be the value the model really sends.
        self.max_tokens = model.max_tokens
        # Output tokens produced in this conversation.
        self.prior_output = 0

    def new_conversation(self) -> None:
        self.prior_output = 0

    def complete(
        self, system, messages, tools=None
    ) -> ModelReply:
        return self._guarded(
            system,
            messages,
            tools,
            lambda: self.model.complete(
                system, messages, tools
            ),
        )

    def complete_json(
        self, system, messages, schema
    ) -> ModelReply:
        # The schema is part of the input: count it like tools.
        return self._guarded(
            system,
            messages,
            [schema],
            lambda: self.model.complete_json(
                system, messages, schema
            ),
        )

    def _guarded(self, system, messages, extra, call):
        worst_in = input_bound(
            system, messages, extra, self.prior_output
        )
        worst = self.guard.before(
            self.name, worst_in, self.max_tokens
        )
        attempt = self.guard.start(self.name, worst)
        try:
            reply = call()
        except BaseException as error:  # Ctrl-C too
            self.guard.after_failure(
                self.name, worst, error, attempt
            )
            raise
        self.prior_output += reply.usage.output_tokens
        self.guard.after(self.name, reply.usage, worst, attempt)
        return reply
