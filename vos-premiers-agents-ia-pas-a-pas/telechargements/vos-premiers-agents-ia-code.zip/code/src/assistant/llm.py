"""Provider-independent access to the model.

The rest of the project only knows `ModelClient` and
`ModelReply`. Only `llm_anthropic.py` imports a provider SDK.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass(frozen=True)
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0

    def __add__(self, other: Usage) -> Usage:
        return Usage(
            self.input_tokens + other.input_tokens,
            self.output_tokens + other.output_tokens,
        )

    @property
    def total(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass(frozen=True)
class ToolCall:
    id: str
    name: str
    input: dict[str, Any]


# [snippet:model-reply]
@dataclass
class ModelReply:
    stop_reason: str  # "end_turn", "tool_use", "max_tokens"...
    text: str  # text meant for the user
    tool_calls: list[ToolCall]
    usage: Usage
    # Raw content, sent back unchanged in the history:
    content: list[Any] = field(default_factory=list)


class ModelClient(Protocol):
    name: str

    def complete(
        self,
        system: str,
        messages: list[dict],
        tools: list[dict] | None = None,
    ) -> ModelReply: ...


# [/snippet]


class JsonModelClient(ModelClient, Protocol):
    """A model that can also answer in a JSON format (ch. 6).

    The reply's `text` is meant to be JSON matching `schema`;
    the caller must still validate it.
    """

    def complete_json(
        self, system: str, messages: list[dict], schema: dict
    ) -> ModelReply: ...


class ModelError(Exception):
    """A model call failed; `retryable`: worth retrying."""

    def __init__(
        self,
        message: str,
        retryable: bool,
        retry_after: float | None = None,
    ):
        super().__init__(message)
        self.retryable = retryable
        self.retry_after = retry_after  # seconds, if stated


def _estimate_tokens(value: Any) -> int:
    """Rough estimate: about 4 characters per token."""
    text = json.dumps(value, ensure_ascii=False, default=str)
    return max(1, len(text) // 4)


class FakeModel:
    """Scripted model: replays replies written in advance.

    It records every request, so tests can check what the
    agent actually sent. No network, no key, no cost.
    """

    name = "fake-model"
    max_tokens = 4096

    def __init__(self, replies: list[ModelReply | Exception]):
        self._replies = list(replies)
        self.requests: list[dict] = []

    def complete(self, system, messages, tools=None):
        snapshot = json.loads(json.dumps(messages, default=str))
        self.requests.append(
            {
                "system": system,
                "messages": snapshot,
                "tools": tools or [],
            }
        )
        if not self._replies:
            raise ModelError(
                "FakeModel: script exhausted", retryable=False
            )
        reply = self._replies.pop(0)
        if isinstance(reply, Exception):
            raise reply  # a scripted failure (network...)
        if reply.usage == Usage():  # keep usage set by a test
            reply.usage = Usage(
                _estimate_tokens([system, messages, tools]),
                _estimate_tokens(reply.content),
            )
        return reply

    def complete_json(self, system, messages, schema):
        reply = self.complete(system, messages)
        self.requests[-1]["schema"] = schema
        return reply

    # Helpers to write scripted replies.
    @staticmethod
    def says(text: str) -> ModelReply:
        block = {"type": "text", "text": text}
        return ModelReply(
            "end_turn", text, [], Usage(), [block]
        )

    @staticmethod
    def calls(*calls: tuple[str, dict]) -> ModelReply:
        tool_calls, content = [], []
        for i, (name, args) in enumerate(calls, start=1):
            call = ToolCall(f"call_{i}_{name}", name, args)
            tool_calls.append(call)
            content.append(
                {
                    "type": "tool_use",
                    "id": call.id,
                    "name": name,
                    "input": args,
                }
            )
        return ModelReply(
            "tool_use", "", tool_calls, Usage(), content
        )

    @staticmethod
    def json(value: Any) -> ModelReply:
        text = json.dumps(value, ensure_ascii=False)
        return FakeModel.says(text)

    @staticmethod
    def truncated(text: str) -> ModelReply:
        block = {"type": "text", "text": text}
        return ModelReply(
            "max_tokens", text, [], Usage(), [block]
        )
