"""Command of chapter 9: assistant evaluate."""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime

from assistant.budget import Ledger
from assistant.config import CODE_DIR
from assistant.corpus import Corpus
from assistant.messages import localize
from assistant.paid import make_anthropic, policy_from_env
from assistant.protocol import (
    EFFORT,
    MAX_TOKENS,
    _real_blocks,
)
from assistant.step09.evaluate import (
    EXPERIMENT,
    Results,
    RoundRefused,
    limits_of,
    load_config,
    report,
    round_max_usd,
    round_runs,
    run_round,
)
from assistant.step09.grade_session import session
from assistant.step09.grading import new_batch, read_grades
from assistant.step09.simulated import SCRIPTS
from assistant.step09.tasks import load_tasks

RESULTS = CODE_DIR / "live_results"


def fake_maker(corpus: Corpus):
    def make(task, arch):
        model = SCRIPTS[arch](task, corpus)
        model.name = (
            "claude-haiku-5-5"  # priced as the real one
        )
        return model

    return make


def real_maker():
    def make(_task, _arch):
        return make_anthropic(
            "claude-haiku-5-5",
            max_tokens=MAX_TOKENS,
            effort=EFFORT,
        )

    return make


def _grid(experiment=EXPERIMENT) -> dict:
    path = experiment / "grading-grid.json"
    return json.loads(path.read_text("utf-8"))


def dry_run(lang: str, experiment=EXPERIMENT, base=None) -> int:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    folder = base or RESULTS / "dryrun" / f"ch09-{stamp}"
    corpus = Corpus.load(experiment / "corpus", "fr")
    ledger = Ledger(folder / "ledger.jsonl")
    for split in ("tuning", "final"):
        run_round(
            split,
            fake_maker(corpus),
            "simulated",
            experiment,
            folder,
            ledger,
        )
    rows = Results(folder / "runs.jsonl").rows
    tasks = load_tasks(experiment / "tasks.json")
    # Forms are prepared; nobody grades in a dry run.
    new_batch(
        rows,
        tasks,
        _grid(experiment),
        folder / "grading",
        "final",
    )
    print(
        report(rows, {}, tasks, load_config(experiment), lang)
    )
    return 0


def evaluate(settings, args) -> int:
    lang = settings.lang
    if args.dry_run:
        return dry_run(lang)
    folder = RESULTS / "real" / "ch09"
    results = Results(folder / "runs.jsonl")
    tasks = load_tasks(EXPERIMENT / "tasks.json")
    if args.sheet:
        return _sheet(args, results, tasks, folder, lang)
    if args.grade:
        session(folder / "grading", _grid())
        return 0
    if args.model_report:
        from assistant.step09 import model_grading as mg

        print(mg.report(folder))
        return 0
    if args.model_grade:
        return _model_grade(settings, args, folder)
    if args.report:
        if not results.rows:
            print(localize(lang, "no real run yet"))
            return 0
        grades = read_grades(folder / "grading")
        config = load_config(EXPERIMENT)
        print(report(results.rows, grades, tasks, config, lang))
        return 0
    if not args.split:
        print(
            localize(
                lang,
                "refused: choose --split, --sheet, --report "
                "or --dry-run",
            )
        )
        return 2
    if not settings.allow_live:
        print(
            localize(
                lang, "refused: ASSISTANT_ALLOW_LIVE is not 1"
            )
        )
        return 2
    if not os.getenv("ANTHROPIC_API_KEY"):
        print(
            localize(
                lang, "refused: ANTHROPIC_API_KEY is not set"
            )
        )
        return 2
    done = _real_blocks(RESULTS / "real")
    if not {"A", "B", "C"} <= done.keys():
        print(
            localize(
                lang, "refused: blocks A, B and C come first"
            )
        )
        return 2
    config = load_config(EXPERIMENT)
    upper = round_max_usd(
        round_runs(tasks, args.split), limits_of(config)
    )
    if not args.yes or args.max_usd is None:
        print(
            localize(
                lang,
                "refused: add --max-usd and --yes for this "
                f"round, {upper:.2f} USD at most, before taxes",
            )
        )
        return 2
    ledger = Ledger(RESULTS / "real" / "ledger.jsonl")
    policy = policy_from_env(ledger, args.max_usd)
    number = len(results.rounds(args.split)) + 1
    limit = ledger.charged_usd + policy.room(
        f"{args.split}:{number}"
    )
    try:
        run_round(
            args.split,
            real_maker(),
            "real-api",
            EXPERIMENT,
            folder,
            ledger,
            limit,
            policy.per_call_usd,
        )
    except RoundRefused as error:
        print(localize(lang, f"refused: {error}"))
        return 2
    return 0


def _sheet(args, results, tasks, folder, lang) -> int:
    if not args.split:
        print(localize(lang, "refused: --sheet needs --split"))
        return 2
    sheet = new_batch(
        results.rows,
        tasks,
        _grid(),
        folder / "grading",
        args.split,
    )
    print(
        localize(
            lang,
            f"written: {sheet}"
            if sheet
            else "nothing new to grade",
        )
    )
    return 0


def _model_grade(settings, args, folder) -> int:
    """Automated grading, two passes plus control cases. Paid,
    off by default, counted in the same ledger."""
    from assistant.budget import GuardedModel, SpendGuard
    from assistant.protocol import MAX_INPUT_TOKENS
    from assistant.step09 import model_grading as mg

    lang = settings.lang
    out = folder / "model-grading"
    if out.exists():
        print(localize(lang, f"refused: already done: {out}"))
        return 2
    if not settings.allow_live or not os.getenv(
        "ANTHROPIC_API_KEY"
    ):
        print(localize(lang, "refused: real use is off"))
        return 2
    if not args.yes or args.max_usd is None:
        print(
            localize(lang, "refused: add --max-usd and --yes")
        )
        return 2
    ledger = Ledger(RESULTS / "real" / "ledger.jsonl")
    policy = policy_from_env(ledger, args.max_usd)
    guard = SpendGuard(
        ledger.charged_usd + policy.room("judge"),
        400,
        MAX_INPUT_TOKENS,
        ledger=ledger,
        phase="judge",
        max_call_usd=policy.per_call_usd,
    )
    model = GuardedModel(
        make_anthropic(
            mg.JUDGE, max_tokens=2000, effort=EFFORT
        ),
        guard,
    )
    lines = mg.read_lines(folder / "grading" / "sheet-1.csv")
    for number in (1, 2):
        mg.run_pass(
            model, _grid(), lines, out / f"pass-{number}.jsonl"
        )
        mg.run_pass(
            model,
            _grid(),
            mg.control_lines(),
            out / f"controls-{number}.jsonl",
        )
    print(f"written: {out}")
    return 0
