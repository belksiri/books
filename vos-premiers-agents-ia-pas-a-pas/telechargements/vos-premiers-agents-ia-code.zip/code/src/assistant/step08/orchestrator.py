"""Step 08: the orchestrator is plain Python.

It decides the order, checks what passes between the roles,
applies limits shared by all of them, and logs each exchange.
No model decides who works next. Single pass: the loop between
writer and verifier, and the comparison with a single agent,
are for chapter 9.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from assistant.corpus import Corpus
from assistant.llm import ModelError
from assistant.step08.contracts import Brief, Draft, Review
from assistant.step08.roles import (
    RoleFailure,
    research,
    verifier_input,
    verify,
    write,
    writer_input,
)


# [snippet:team-budget]
@dataclass
class TeamBudget:
    """Limits shared by all the roles."""

    max_calls: int = 30
    max_tokens: int = 150_000
    calls: dict[str, int] = field(default_factory=dict)
    tokens: dict[str, int] = field(default_factory=dict)

    def check(self, role: str = "") -> None:
        if (
            sum(self.calls.values()) >= self.max_calls
            or sum(self.tokens.values()) >= self.max_tokens
        ):
            raise ModelError("team budget reached", False)

    def add(self, role: str, reply) -> None:
        self.calls[role] = self.calls.get(role, 0) + 1
        self.tokens[role] = (
            self.tokens.get(role, 0) + reply.usage.total
        )


class RoleModel:
    """The same model, seen by one role: counted, limited."""

    def __init__(self, model, budget: TeamBudget, role: str):
        self.model, self.budget, self.role = model, budget, role
        self.name = model.name
        self.max_tokens = model.max_tokens

    def _call(self, call):
        self.budget.check(self.role)  # BETWEEN calls (ch. 4)
        reply = call()
        self.budget.add(self.role, reply)
        return reply

    def complete(self, system, messages, tools=None):
        return self._call(
            lambda: self.model.complete(system, messages, tools)
        )

    def complete_json(self, system, messages, schema):
        return self._call(
            lambda: self.model.complete_json(
                system, messages, schema
            )
        )


# [/snippet]


@dataclass
class Exchange:
    sender: str
    receiver: str
    contract: str
    chars: int  # size of what the receiver is given


@dataclass
class TeamResult:
    status: str = "running"
    brief: Brief | None = None
    draft: Draft | None = None
    review: Review | None = None
    problems: list[str] = field(default_factory=list)
    lost_refs: list[str] = field(default_factory=list)
    log: list[Exchange] = field(default_factory=list)


# [snippet:draft-problems]
def draft_problems(draft: Draft, brief: Brief) -> list[str]:
    """Refuse a claim without a reference, or citing a passage
    the writer was never given."""
    known = {e.ref for e in brief.evidence}
    problems = []
    for i, claim in enumerate(draft.claims, start=1):
        if not claim.refs:
            problems.append(f"{i}: no reference")
        for ref in claim.refs:
            if ref not in known:
                problems.append(f"{i}: not in brief: {ref}")
    return problems


def lost_refs(draft: Draft, brief: Brief) -> list[str]:
    """Given to the writer, used nowhere: to be looked at."""
    used = {r for c in draft.claims for r in c.refs}
    return [e.ref for e in brief.evidence if e.ref not in used]


# [/snippet]


# [snippet:run-team]
def run_team(
    model,
    question: str,
    corpus: Corpus,
    lang: str,
    today: str,
    budget: TeamBudget | None = None,
) -> tuple[TeamResult, TeamBudget]:
    budget = budget or TeamBudget()
    out = TeamResult()

    def role(name: str) -> RoleModel:
        return RoleModel(model, budget, name)

    def note(sender, receiver, contract, text="") -> None:
        out.log.append(
            Exchange(sender, receiver, contract, len(text))
        )

    try:
        note("orchestrator", "researcher", "question", question)
        out.brief, _ = research(
            role("researcher"), question, corpus, lang, today
        )

        given = writer_input(question, out.brief)
        note("researcher", "writer", "Brief", given)
        out.draft = (
            write(role("writer"), question, out.brief, lang)
            if out.brief.evidence
            else Draft(claims=[])
        )
        if not out.draft.claims:  # "not found" is a result
            out.status = "no_answer"
            out.problems = list(out.brief.gaps)
            return out, budget

        out.lost_refs = lost_refs(out.draft, out.brief)
        out.problems = draft_problems(out.draft, out.brief)
        if out.problems:  # no call wasted on a refused draft
            out.status = "draft_refused"
            return out, budget

        given = verifier_input(question, out.draft, corpus)
        note("writer", "verifier", "Draft", given)
        out.review = verify(
            role("verifier"),
            question,
            out.draft,
            corpus,
            lang,
            today,
        )

        note("verifier", "orchestrator", "Review")
        # An opinion: reported, the code changes nothing.
        objections = any(
            not v.supported for v in out.review.verdicts
        )
        out.status = (
            "done_with_objections" if objections else "done"
        )
    except RoleFailure as error:
        out.status = f"failed:{error.role}"
        out.problems = [error.reason]
    except ModelError as error:
        out.status = "stopped"
        out.problems = [str(error)]
    return out, budget


# [/snippet]


def assemble_answer(result: TeamResult) -> list[str]:
    """Written by the code: the claims, then the sources."""
    lines = [
        f"- {c.text} " + " ".join(f"[{r}]" for r in c.refs)
        for c in result.draft.claims
    ]
    used = {r for c in result.draft.claims for r in c.refs}
    for item in result.brief.evidence:
        if item.ref in used:
            lines.append(f'[{item.ref}] "{item.quote}"')
    return lines
