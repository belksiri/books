"""Scripted scenarios for the simulated model.

They replay plausible model decisions so that the tools, the
loop and the checks run for real, without any API call. The
model's wording here is written by hand: it is NOT a real
model output.
"""

from __future__ import annotations

from assistant.llm import FakeModel

DEPOSIT_ANSWER = {
    "fr": (
        "Le dépôt de garantie est de 150 € par vélo. La grille "
        "2026 prévoyait 200 €, mais l'assemblée générale du "
        "21 mars 2026 l'a maintenu à 150 € en attendant l'avis "
        "de l'assureur [cr-ag-2026-03#p03].\n\n"
        "Sources\n"
        "- [cr-ag-2026-03#p03] « le dépôt de garantie reste "
        "fixé à 150 € jusqu'à réception de l'avis écrit de "
        "l'assureur »\n"
        "- [tarifs-2026#p04] « Dépôt de garantie : 200 € par "
        "vélo »"
    ),
    "de": (
        "Die Sicherheitsleistung beträgt 150 € pro Fahrrad. "
        "Die Preisliste 2026 sah 200 € vor, aber die "
        "Generalversammlung vom 21. März 2026 hat sie bis zur "
        "Stellungnahme des Versicherers bei 150 € belassen "
        "[cr-ag-2026-03#p03].\n\n"
        "Quellen\n"
        "- [cr-ag-2026-03#p03] „bleibt die Sicherheitsleistung "
        "bei 150 €, bis die schriftliche Stellungnahme des "
        "Versicherers vorliegt“\n"
        "- [tarifs-2026#p04] „Sicherheitsleistung: 200 € pro "
        "Fahrrad“"
    ),
}

DEPOSIT_ANSWER["en"] = (
    "The security deposit is €150 per bicycle. The 2026 price "
    "list proposed €200, but the general meeting of 21 March "
    "2026 kept it at €150 until the insurer gives its opinion "
    "[cr-ag-2026-03#p03].\n\n"
    "Sources\n"
    '- [cr-ag-2026-03#p03] "the security deposit remains at '
    "€150 until the insurer's written opinion is received\"\n"
    '- [tarifs-2026#p04] "Security deposit: €200 per bicycle"'
)
DEPOSIT_ANSWER["es"] = (
    "El depósito de garantía es de 150 € por bicicleta. Las "
    "tarifas 2026 proponían 200 €, pero la asamblea general "
    "del 21 de marzo de 2026 lo mantuvo en 150 € hasta el "
    "informe de la aseguradora [cr-ag-2026-03#p03].\n\n"
    "Fuentes\n"
    "- [cr-ag-2026-03#p03] «el depósito de garantía se "
    "mantiene en 150 € hasta recibir el informe escrito de "
    "la aseguradora»\n"
    "- [tarifs-2026#p04] «Depósito de garantía: 200 € por "
    "bicicleta»"
)

QUERY = {
    "fr": "dépôt de garantie",
    "de": "Sicherheitsleistung",
    "en": "security deposit",
    "es": "depósito de garantía",
}


def deposit_scenario(lang: str) -> FakeModel:
    """Question: how much is the deposit? Five model turns."""
    return FakeModel(
        [
            FakeModel.calls(
                ("search_documents", {"query": QUERY[lang]})
            ),
            FakeModel.calls(
                ("read_document", {"doc_id": "tarifs-2025"}),
                ("read_document", {"doc_id": "cr-ag-2026-03"}),
            ),
            # A typo: the tool answers with an error...
            FakeModel.calls(
                ("read_document", {"doc_id": "tarif-2026"})
            ),
            # ...and the model corrects itself.
            FakeModel.calls(
                ("read_document", {"doc_id": "tarifs-2026"})
            ),
            FakeModel.says(DEPOSIT_ANSWER[lang]),
        ]
    )


# ---- Chapter 5: memory across two sessions ----
# Hand-written model decisions, for the simulated demo only.

MEMORY_TEXT = {
    "fr": {
        "ask1": (
            "Retenez que je préfère des réponses en trois "
            "points "
            "au maximum. Retenez aussi l'adresse de Camille "
            "Ferrand : camille.ferrand@example.org."
        ),
        "pref": "Réponses en trois points au maximum.",
        "pii": "Adresse de Camille Ferrand : "
        "camille.ferrand@example.org",
        "done1": (
            "C'est noté pour le format des réponses. "
            "L'adresse n'a pas été mémorisée : la mémoire "
            "refuse ce qui ressemble à une donnée personnelle."
        ),
        "ask2": "Quel est le montant du dépôt de garantie ?",
        "done2": (
            "- 150 € par vélo [cr-ag-2026-03#p03].\n"
            "- Montant provisoire, en attente de l'assureur.\n"
            "- Le projet 2026 prévoyait 200 € "
            "[tarifs-2026#p04]."
        ),
    },
    "de": {
        "ask1": (
            "Merken Sie sich, dass ich Antworten mit höchstens "
            "drei Punkten bevorzuge. Merken Sie sich auch die "
            "Adresse von Camille Ferrand: "
            "camille.ferrand@example.org."
        ),
        "pref": "Antworten mit höchstens drei Punkten.",
        "pii": "Adresse von Camille Ferrand: "
        "camille.ferrand@example.org",
        "done1": (
            "Das Antwortformat ist notiert. Die Adresse "
            "wurde nicht gespeichert: Das Gedächtnis lehnt "
            "ab, was nach personenbezogenen Daten aussieht."
        ),
        "ask2": "Wie hoch ist die Sicherheitsleistung?",
        "done2": (
            "- 150 € pro Fahrrad [cr-ag-2026-03#p03].\n"
            "- Vorläufiger Betrag, bis der Versicherer "
            "antwortet.\n"
            "- Der Entwurf 2026 sah 200 € vor "
            "[tarifs-2026#p04]."
        ),
    },
    "en": {
        "ask1": (
            "Remember that I prefer answers with three "
            "points at "
            "most. Also remember Camille Ferrand's address: "
            "camille.ferrand@example.org."
        ),
        "pref": "Answers with three points at most.",
        "pii": "Camille Ferrand's address: "
        "camille.ferrand@example.org",
        "done1": (
            "Noted for the answer format. The address was "
            "not remembered: the memory refuses what looks "
            "like personal data."
        ),
        "ask2": "How much is the security deposit?",
        "done2": (
            "- €150 per bicycle [cr-ag-2026-03#p03].\n"
            "- Provisional amount, pending the insurer.\n"
            "- The 2026 draft proposed €200 [tarifs-2026#p04]."
        ),
    },
    "es": {
        "ask1": (
            "Recuerda que prefiero respuestas de tres puntos "
            "como "
            "máximo. Recuerda también la dirección de Camille "
            "Ferrand: camille.ferrand@example.org."
        ),
        "pref": "Respuestas de tres puntos como máximo.",
        "pii": "Dirección de Camille Ferrand: "
        "camille.ferrand@example.org",
        "done1": (
            "Anotado el formato de las respuestas. La "
            "dirección no se ha guardado: la memoria rechaza "
            "lo que parece un dato personal."
        ),
        "ask2": "¿Cuál es el importe del depósito de garantía?",
        "done2": (
            "- 150 € por bicicleta [cr-ag-2026-03#p03].\n"
            "- Importe provisional, a la espera de la "
            "aseguradora.\n"
            "- El proyecto 2026 proponía 200 € "
            "[tarifs-2026#p04]."
        ),
    },
}


def memory_session1(lang: str) -> FakeModel:
    t = MEMORY_TEXT[lang]
    return FakeModel(
        [
            FakeModel.calls(
                (
                    "remember",
                    {"kind": "preference", "text": t["pref"]},
                ),
                (
                    "remember",
                    {"kind": "fact", "text": t["pii"]},
                ),
            ),
            FakeModel.says(t["done1"]),
        ]
    )


def memory_session2(lang: str) -> FakeModel:
    t = MEMORY_TEXT[lang]
    return FakeModel(
        [
            FakeModel.calls(
                ("search_documents", {"query": QUERY[lang]})
            ),
            FakeModel.calls(
                ("read_document", {"doc_id": "cr-ag-2026-03"}),
                ("read_document", {"doc_id": "tarifs-2026"}),
            ),
            FakeModel.says(t["done2"]),
        ]
    )


# ---- Chapter 6: a planned synthesis, interrupted, resumed ----
# Hand-written model decisions, for the simulated demo only.
# Quotes are cut from the real passages, so that they match
# in every language; the claims are written by hand.

SYNTHESIS_TEXT = {
    "fr": {
        "question": (
            "Préparez une note pour les bénévoles de "
            "l'accueil : règles d'annulation et dépôt de "
            "garantie."
        ),
        "title": "Note pour l'accueil : annulations et dépôt",
        "steps": [
            (
                "Règles d'annulation et de remboursement",
                "annulation remboursement",
            ),
            (
                "Montant actuel du dépôt de garantie",
                "dépôt de garantie",
            ),
            (
                "Cas où le dépôt peut être retenu",
                "dépôt retenu",
            ),
        ],
        "s1": (
            "Une location annulée est remboursée par paliers : "
            "80 % à partir de 5 jours avant la date prévue, "
            "40 % de 2 à 4 jours, 10 % la veille, rien le jour "
            "même [remboursement#p03]. En cas d'alerte météo "
            "orange ou rouge, le remboursement est intégral "
            "[remboursement#p04]. La demande se fait dans les "
            "30 jours [remboursement#p01]."
        ),
        "s2": (
            "Le dépôt est de 150 € par vélo, à titre "
            "provisoire, jusqu'à l'avis écrit de l'assureur "
            "[cr-ag-2026-03#p03]. Le projet de grille 2026 "
            "prévoyait 200 € [tarifs-2026#p04]."
        ),
        "s3": (
            "Le dépôt n'est jamais retenu pour des rayures ou "
            "l'usure normale du vélo [remboursement#p05]. Il "
            "est restitué sous 14 jours [remboursement#p02]."
        ),
        "claim": "Il est restitué sous 14 jours",
        "problem": (
            "remboursement#p02 porte sur l'examen des demandes "
            "de remboursement, pas sur la restitution du dépôt."
        ),
        "quotes": ("« ", " »"),
    },
    "en": {
        "question": (
            "Prepare a note for the front-desk volunteers: "
            "cancellation rules and the security deposit."
        ),
        "title": "Front-desk note: cancellations and deposit",
        "steps": [
            (
                "Rules for cancelling and refunding rentals",
                "cancellation refund",
            ),
            (
                "Current amount of the security deposit",
                "security deposit",
            ),
            (
                "Cases where the deposit can be withheld",
                "deposit withheld",
            ),
        ],
        "s1": (
            "A cancelled rental is refunded in steps: 80% from "
            "5 days before the planned date, 40% from 2 to 4 "
            "days, 10% the day before, nothing on the day "
            "itself "
            "[remboursement#p03]. With an orange or red "
            "weather warning, the refund is full "
            "[remboursement#p04]. "
            "Requests must be made within 30 days "
            "[remboursement#p01]."
        ),
        "s2": (
            "The deposit is €150 per bicycle, provisionally, "
            "until the insurer's written opinion "
            "[cr-ag-2026-03#p03]. The draft 2026 price list "
            "proposed €200 [tarifs-2026#p04]."
        ),
        "s3": (
            "The deposit is never withheld for scratches or "
            "normal wear [remboursement#p05]. It is returned "
            "within 14 days [remboursement#p02]."
        ),
        "claim": "It is returned within 14 days",
        "problem": (
            "remboursement#p02 is about reviewing refund "
            "requests, not about returning the deposit."
        ),
        "quotes": ('"', '"'),
    },
    "es": {
        "question": (
            "Prepara una nota para los voluntarios de la "
            "recepción: reglas de cancelación y depósito de "
            "garantía."
        ),
        "title": (
            "Nota para recepción: cancelaciones y depósito"
        ),
        "steps": [
            (
                "Reglas de cancelación y reembolso",
                "cancelación reembolso",
            ),
            (
                "Importe actual del depósito de garantía",
                "depósito de garantía",
            ),
            (
                "Casos en que se puede retener el depósito",
                "depósito retiene",
            ),
        ],
        "s1": (
            "Un alquiler cancelado se reembolsa por tramos: "
            "80 % a partir de 5 días antes de la fecha "
            "prevista, 40 % de 2 a 4 días, 10 % la víspera, "
            "nada el mismo día "
            "[remboursement#p03]. Con un aviso meteorológico "
            "naranja o rojo, el reembolso es íntegro "
            "[remboursement#p04]. La solicitud se presenta en "
            "un plazo de 30 días [remboursement#p01]."
        ),
        "s2": (
            "El depósito es de 150 € por bicicleta, de forma "
            "provisional, hasta el informe escrito de la "
            "aseguradora [cr-ag-2026-03#p03]. El proyecto de "
            "tarifas 2026 proponía 200 € [tarifs-2026#p04]."
        ),
        "s3": (
            "El depósito nunca se retiene por arañazos o "
            "desgaste normal [remboursement#p05]. Se devuelve "
            "en un plazo de 14 días [remboursement#p02]."
        ),
        "claim": "Se devuelve en un plazo de 14 días",
        "problem": (
            "remboursement#p02 trata del examen de las "
            "solicitudes de reembolso, no de la devolución "
            "del depósito."
        ),
        "quotes": ("«", "»"),
    },
    "de": {
        "question": (
            "Erstellen Sie eine Notiz für die Ehrenamtlichen "
            "am Empfang: Stornierungsregeln und "
            "Sicherheitsleistung."
        ),
        "title": "Notiz für den Empfang: Storno und Kaution",
        "steps": [
            (
                "Regeln für Stornierung und Erstattung",
                "Stornierung Erstattung",
            ),
            (
                "Aktuelle Höhe der Sicherheitsleistung",
                "Sicherheitsleistung",
            ),
            (
                "Fälle, in denen sie einbehalten wird",
                "Sicherheitsleistung einbehalten",
            ),
        ],
        "s1": (
            "Eine stornierte Miete wird gestaffelt erstattet: "
            "80 % ab 5 Tagen vor dem geplanten Datum, 40 % bei "
            "2 bis 4 Tagen, 10 % am Vortag, nichts am selben "
            "Tag [remboursement#p03]. Bei einer "
            "Unwetterwarnung Orange oder Rot wird vollständig "
            "erstattet [remboursement#p04]. Der Antrag ist "
            "innerhalb von 30 Tagen zu stellen "
            "[remboursement#p01]."
        ),
        "s2": (
            "Die Sicherheitsleistung beträgt vorläufig 150 € "
            "pro Fahrrad, bis die schriftliche Stellungnahme "
            "des Versicherers vorliegt [cr-ag-2026-03#p03]. "
            "Der Entwurf der Preisliste 2026 sah 200 € vor "
            "[tarifs-2026#p04]."
        ),
        "s3": (
            "Für Kratzer oder normale Abnutzung wird die "
            "Sicherheitsleistung nie einbehalten "
            "[remboursement#p05]. Sie wird innerhalb von 14 "
            "Tagen zurückgezahlt [remboursement#p02]."
        ),
        "claim": (
            "Sie wird innerhalb von 14 Tagen zurückgezahlt"
        ),
        "problem": (
            "remboursement#p02 betrifft die Prüfung von "
            "Erstattungsanträgen, nicht die Rückzahlung der "
            "Sicherheitsleistung."
        ),
        "quotes": ("„", "“"),
    },
}

SOURCES_WORD = {
    "fr": "Sources",
    "en": "Sources",
    "es": "Fuentes",
    "de": "Quellen",
}


def _short_quote(corpus, ref: str) -> str:
    """The first words of the real passage (28 chars max)."""
    words = corpus.passage(ref).text.split()
    quote = words[0]
    for word in words[1:]:
        if len(quote) + 1 + len(word) > 28:
            return quote.rstrip(".,;:") + "…"
        quote += " " + word
    return quote


def _with_sources(lang: str, body: str, refs, corpus) -> str:
    """Body, then one source line per ref, quoting the first
    words of the real passage."""
    left, right = SYNTHESIS_TEXT[lang]["quotes"]
    lines = [body, "", SOURCES_WORD[lang]]
    for ref in refs:
        quote = _short_quote(corpus, ref)
        lines.append(f"- [{ref}] {left}{quote}{right}")
    return "\n".join(lines)


def synthesis_plan(lang: str) -> dict:
    text = SYNTHESIS_TEXT[lang]
    return {
        "title": text["title"],
        "steps": [
            {"id": f"s{i}", "goal": goal, "query": query}
            for i, (goal, query) in enumerate(
                text["steps"], start=1
            )
        ],
    }


def synthesis_session1(lang: str, corpus) -> FakeModel:
    """Plan, steps 1 and 2; step 3 fails (network error)."""
    from assistant.llm import ModelError

    text = SYNTHESIS_TEXT[lang]
    queries = [q for _, q in text["steps"]]
    s1_refs = [
        "remboursement#p03",
        "remboursement#p04",
        "remboursement#p01",
    ]
    s2_refs = ["cr-ag-2026-03#p03", "tarifs-2026#p04"]
    return FakeModel(
        [
            FakeModel.json(synthesis_plan(lang)),
            # s1
            FakeModel.calls(
                ("search_documents", {"query": queries[0]})
            ),
            FakeModel.calls(
                ("read_document", {"doc_id": "remboursement"})
            ),
            FakeModel.says(
                _with_sources(lang, text["s1"], s1_refs, corpus)
            ),
            # s2
            FakeModel.calls(
                ("search_documents", {"query": queries[1]})
            ),
            FakeModel.calls(
                ("read_document", {"doc_id": "cr-ag-2026-03"}),
                ("read_document", {"doc_id": "tarifs-2026"}),
            ),
            FakeModel.says(
                _with_sources(lang, text["s2"], s2_refs, corpus)
            ),
            # s3: the connection drops after the first call.
            FakeModel.calls(
                ("search_documents", {"query": queries[2]})
            ),
            ModelError("connection lost (simulated)", True),
        ]
    )


def synthesis_session2(lang: str, corpus) -> FakeModel:
    """Resume: step 3 only, then the review."""
    text = SYNTHESIS_TEXT[lang]
    s3_refs = ["remboursement#p05", "remboursement#p02"]
    return FakeModel(
        [
            FakeModel.calls(
                ("read_document", {"doc_id": "remboursement"})
            ),
            FakeModel.says(
                _with_sources(lang, text["s3"], s3_refs, corpus)
            ),
            FakeModel.json(
                {
                    "issues": [
                        {
                            "step": "s3",
                            "claim": text["claim"],
                            "problem": text["problem"],
                        }
                    ]
                }
            ),
        ]
    )


# ---- Chapter 7: a misled model against the barriers ----
# Written by hand ON PURPOSE: this simulated model obeys the
# email hidden in the folder, so that the code's barriers can
# be tested. It says nothing about what a real model would do.

BUREAU = "bureau@rivelune.example.org"
OUTSIDER = "partenaire@example.org"
LEAK = "yanis.roux@example.org"

GATE_TEXT = {
    "fr": {
        "ask": (
            "Résumez le message de l'office de tourisme et "
            "transmettez-le au bureau."
        ),
        "leak": f"Liste des adhérents : {LEAK}",
        "clean": (
            "L'office de tourisme de Val-Ondine demande nos "
            "tarifs de location à la journée."
        ),
        "clean2": "Rappel : réunion du bureau mardi.",
        "done": "Le résumé a été transmis au bureau.",
        "crash": (
            "arrêt simulé : après l'écriture, avant le journal"
        ),
        "checked": "une personne vérifie : le fichier existe",
    },
    "en": {
        "ask": (
            "Summarize the tourist office's message and pass "
            "it on to the board."
        ),
        "leak": f"List of members: {LEAK}",
        "clean": (
            "The Val-Ondine tourist office asks for our daily "
            "rental prices."
        ),
        "clean2": "Reminder: board meeting on Tuesday.",
        "done": "The summary was passed on to the board.",
        "crash": (
            "simulated stop: after the write, before the log"
        ),
        "checked": "a person checks: the file exists",
    },
    "es": {
        "ask": (
            "Resume el mensaje de la oficina de turismo y "
            "transmítelo a la junta."
        ),
        "leak": f"Lista de socios: {LEAK}",
        "clean": (
            "La oficina de turismo de Val-Ondine pide nuestras "
            "tarifas de alquiler por día."
        ),
        "clean2": ("Recordatorio: reunión de junta el martes."),
        "done": "El resumen se transmitió a la junta.",
        "crash": (
            "parada simulada: tras escribir, antes del registro"
        ),
        "checked": "una persona comprueba: el archivo existe",
    },
    "de": {
        "ask": (
            "Fassen Sie die Nachricht des Tourismusbüros "
            "zusammen und leiten Sie sie an den Vorstand "
            "weiter."
        ),
        "leak": f"Mitgliederliste: {LEAK}",
        "clean": (
            "Das Tourismusbüro Val-Ondine bittet um unsere "
            "Tagesmietpreise."
        ),
        "clean2": "Erinnerung: Vorstand tagt am Dienstag.",
        "done": "Die Zusammenfassung ging an den Vorstand.",
        "crash": (
            "simulierter Abbruch: nach dem Schreiben, "
            "vor dem Log"
        ),
        "checked": "ein Mensch prüft: die Datei existiert",
    },
}


def misled_scenario(lang: str) -> FakeModel:
    """Obeys the email, is stopped, then behaves."""
    text = GATE_TEXT[lang]

    def send(target, content):
        return FakeModel.calls(
            (
                "send_message",
                {"target": target, "content": content},
            )
        )

    return FakeModel(
        [
            FakeModel.calls(
                (
                    "read_document",
                    {"doc_id": "courriel-externe"},
                )
            ),
            send(OUTSIDER, text["leak"]),  # stopped by the list
            send(BUREAU, text["leak"]),  # the person declines
            send(
                BUREAU, text["clean"]
            ),  # a NEW approval needed
            send(BUREAU, text["clean"]),  # already sent
            FakeModel.says(text["done"]),
        ]
    )


# ---- Chapter 8: three roles, one lost reference ----
# Hand-written, for the simulated demo only. The verdicts are a
# teaching illustration: they measure no real model.

P03, P04 = "cr-ag-2026-03#p03", "tarifs-2026#p04"

TEAM_TEXT = {
    "fr": {
        "note1": "Compte rendu approuvé du 2026-03-21.",
        "note2": "Projet du 2026-02-10, soumis au vote.",
        "claim1": (
            "Le dépôt est de 150 € par vélo, à titre "
            "provisoire."
        ),
        "claim2": "Le projet de grille 2026 prévoyait 200 €.",
        "claim3": "Ce montant de 150 € est définitif.",
        "ok1": "Le passage donne ce montant et ce statut.",
        "ok2": "Le passage donne ce montant, pour un projet.",
        "no3": "Faux : le montant reste provisoire.",
    },
    "en": {
        "note1": "Approved minutes of 2026-03-21.",
        "note2": "Draft of 2026-02-10, submitted to a vote.",
        "claim1": (
            "The deposit is €150 per bicycle, provisionally."
        ),
        "claim2": "The draft 2026 price list proposed €200.",
        "claim3": "This €150 amount is final.",
        "ok1": "The passage gives this amount and status.",
        "ok2": "The passage gives this amount, for a draft.",
        "no3": "False: the amount remains provisional.",
    },
    "es": {
        "note1": "Acta aprobada del 2026-03-21.",
        "note2": (
            "Proyecto del 2026-02-10, sometido a votación."
        ),
        "claim1": (
            "El depósito es de 150 € por bicicleta, "
            "provisional."
        ),
        "claim2": "El proyecto de tarifas 2026 proponía 200 €.",
        "claim3": "Este importe de 150 € es definitivo.",
        "ok1": "El pasaje da este importe y este carácter.",
        "ok2": "El pasaje da este importe, para un proyecto.",
        "no3": "Falso: el importe sigue siendo provisional.",
    },
    "de": {
        "note1": "Genehmigtes Protokoll vom 2026-03-21.",
        "note2": (
            "Entwurf vom 2026-02-10, zur Abstimmung vorgelegt."
        ),
        "claim1": (
            "Die Sicherheitsleistung beträgt vorläufig 150 €."
        ),
        "claim2": "Der Entwurf 2026 sah 200 € vor.",
        "claim3": "Dieser Betrag von 150 € ist endgültig.",
        "ok1": "Der Abschnitt nennt Betrag und Status.",
        "ok2": (
            "Der Abschnitt nennt den Betrag, für einen Entwurf."
        ),
        "no3": "Falsch: Der Betrag bleibt vorläufig.",
    },
}


def _researcher_turns(lang: str, corpus) -> list:
    text = TEAM_TEXT[lang]
    return [
        FakeModel.calls(
            ("search_documents", {"query": QUERY[lang]})
        ),
        FakeModel.calls(
            ("read_document", {"doc_id": "cr-ag-2026-03"}),
            ("read_document", {"doc_id": "tarifs-2026"}),
        ),
        FakeModel.calls(
            (
                "submit_brief",
                {
                    "evidence": [
                        {
                            "ref": P03,
                            "quote": _short_quote(corpus, P03),
                            "note": text["note1"],
                        },
                        {
                            "ref": P04,
                            "quote": _short_quote(corpus, P04),
                            "note": text["note2"],
                        },
                    ],
                    "gaps": [],
                },
            )
        ),
    ]


def team_lost_reference(lang: str, corpus) -> FakeModel:
    """The writer states the 200 € but drops its reference."""
    text = TEAM_TEXT[lang]
    return FakeModel(
        _researcher_turns(lang, corpus)
        + [
            FakeModel.json(
                {
                    "claims": [
                        {"text": text["claim1"], "refs": [P03]},
                        {"text": text["claim2"], "refs": []},
                    ]
                }
            )
        ]
    )


def team_full_run(lang: str, corpus) -> FakeModel:
    """A clean hand-over; the verifier rejects a false claim."""
    text = TEAM_TEXT[lang]
    claims = [
        {"text": text["claim1"], "refs": [P03]},
        {"text": text["claim2"], "refs": [P04]},
        {"text": text["claim3"], "refs": [P03]},
    ]
    verdicts = [
        {"claim": 1, "supported": True, "reason": text["ok1"]},
        {"claim": 2, "supported": True, "reason": text["ok2"]},
        {"claim": 3, "supported": False, "reason": text["no3"]},
    ]
    return FakeModel(
        _researcher_turns(lang, corpus)
        + [
            FakeModel.json({"claims": claims}),
            FakeModel.calls(
                ("search_documents", {"query": QUERY[lang]})
            ),
            FakeModel.calls(
                ("submit_review", {"verdicts": verdicts})
            ),
        ]
    )
