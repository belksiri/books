"""Messages shown to the reader, in the four book languages."""

import re

MESSAGES = {
    "fr": {
        "turns": "tours",
        "session": "session",
        "confirm": "confirmation demandée",
        "memory_file": "fichier mémoire",
        "entries": "entrée(s)",
        "history": "historique au départ",
        "messages": "message(s)",
        "checks": "contrôles des références :",
        "yes": "oui",
        "no": "non",
        "unknown": "?",
        "cols": "existe consulté extrait soutien",
        "estimated": "estimation",
        "tool": "outil",
        "status": "statut",
        "answer": "réponse",
        "tokens": "jetons (entrée/sortie)",
        "simulated": "modèle simulé : aucun appel réseau",
        "live_off": (
            "Essais réels désactivés. Définissez "
            "ASSISTANT_ALLOW_LIVE=1 et AGENT_MODEL dans .env."
        ),
        "no_key": "Variable ANTHROPIC_API_KEY absente.",
        "cost": "coût estimé",
        "review_demo": (
            "relecture simulée (illustration écrite à la main)"
        ),
        "no_docs": "dossier sans document exploitable",
        "other_folder": (
            "cette mission porte sur un autre dossier"
        ),
        "person_sees": "la personne voit",
        "person_says": "elle répond",
        "journal": "journal",
        "resolve_needs": (
            "Indiquez aussi --happened yes|no et --who."
        ),
        "approve_q": "Envoyer ce texte exact ? [o/N] ",
        "checks_failed": (
            "contrôles non passés : aucun envoi proposé"
        ),
        "not_sent": "non envoyé",
        "corpus_changed": (
            "documents modifiés depuis le début de la mission"
        ),
        "use_restart": (
            "mission non reprise : relancez avec --restart"
        ),
        "researcher": "chercheur",
        "writer": "rédacteur",
        "verifier": "vérificateur",
        "orchestrator": "orchestrateur",
        "attempt": "essai",
        "calls_by_role": "appels par rôle",
        "lost": "référence non reprise",
        "verdicts_demo": (
            "verdicts simulés (illustration écrite à la main)"
        ),
        "plan_ok": "plan proposé par le modèle, validé",
        "plan_refused": "plan refusé",
        "saved": "état sauvegardé",
        "interrupted": "mission interrompue",
        "resumed": "état repris, étapes déjà faites",
        "mission_done": "mission terminée",
        "synthesis": "synthèse",
        "code_checks": "contrôles du code",
        "review": "relecture par un modèle (avis, à vérifier)",
        "no_issue": "aucun problème signalé",
        "no_review": "pas d'avis exploitable",
    },
    "en": {
        "turns": "turns",
        "session": "session",
        "confirm": "confirmation requested",
        "memory_file": "memory file",
        "entries": "entry(ies)",
        "history": "history at start",
        "messages": "message(s)",
        "checks": "reference checks:",
        "yes": "yes",
        "no": "no",
        "unknown": "?",
        "cols": "exists consulted excerpt supported",
        "estimated": "estimate",
        "tool": "tool",
        "status": "status",
        "answer": "answer",
        "tokens": "tokens (input/output)",
        "simulated": "simulated model: no network call",
        "live_off": (
            "Live runs are disabled. Set "
            "ASSISTANT_ALLOW_LIVE=1 and AGENT_MODEL in .env."
        ),
        "no_key": "ANTHROPIC_API_KEY is not set.",
        "cost": "estimated cost",
        "review_demo": (
            "simulated review (hand-written illustration)"
        ),
        "no_docs": "folder without usable documents",
        "other_folder": "this mission is about another folder",
        "person_sees": "the person sees",
        "person_says": "they answer",
        "journal": "journal",
        "resolve_needs": (
            "Also give --happened yes|no and --who."
        ),
        "approve_q": "Send this exact text? [y/N] ",
        "checks_failed": "checks failed: no sending proposed",
        "not_sent": "not sent",
        "corpus_changed": (
            "documents changed since the mission began"
        ),
        "use_restart": (
            "mission not resumed: run again with --restart"
        ),
        "researcher": "researcher",
        "writer": "writer",
        "verifier": "verifier",
        "orchestrator": "orchestrator",
        "attempt": "run",
        "calls_by_role": "calls per role",
        "lost": "reference not used",
        "verdicts_demo": (
            "simulated verdicts (hand-written illustration)"
        ),
        "plan_ok": "plan proposed by the model, validated",
        "plan_refused": "plan refused",
        "saved": "state saved",
        "interrupted": "mission interrupted",
        "resumed": "state resumed, steps already done",
        "mission_done": "mission complete",
        "synthesis": "synthesis",
        "code_checks": "checks by the code",
        "review": "review by a model (opinion, to be checked)",
        "no_issue": "no problem reported",
        "no_review": "no usable opinion",
    },
    "es": {
        "turns": "turnos",
        "session": "sesión",
        "confirm": "confirmación solicitada",
        "memory_file": "archivo de memoria",
        "entries": "entrada(s)",
        "history": "historial al inicio",
        "messages": "mensaje(s)",
        "checks": "controles de las referencias:",
        "yes": "sí",
        "no": "no",
        "unknown": "?",
        "cols": "existe consultado extracto respaldo",
        "estimated": "estimación",
        "tool": "herramienta",
        "status": "estado",
        "answer": "respuesta",
        "tokens": "tokens (entrada/salida)",
        "simulated": "modelo simulado: ninguna llamada de red",
        "live_off": (
            "Pruebas reales desactivadas. Define "
            "ASSISTANT_ALLOW_LIVE=1 y AGENT_MODEL en .env."
        ),
        "no_key": "Falta la variable ANTHROPIC_API_KEY.",
        "cost": "coste estimado",
        "review_demo": (
            "revisión simulada (ilustración escrita a mano)"
        ),
        "no_docs": "carpeta sin documentos utilizables",
        "other_folder": "esta misión trata de otra carpeta",
        "person_sees": "la persona ve",
        "person_says": "responde",
        "journal": "registro",
        "resolve_needs": (
            "Indica también --happened yes|no y --who."
        ),
        "approve_q": "¿Enviar este texto exacto? [s/N] ",
        "checks_failed": "controles no superados: ningún envío",
        "not_sent": "no enviado",
        "corpus_changed": "documentos modificados tras iniciar",
        "use_restart": (
            "misión no reanudada: vuelve a lanzarla c"
            "on --restart"
        ),
        "researcher": "investigador",
        "writer": "redactor",
        "verifier": "verificador",
        "orchestrator": "orquestador",
        "attempt": "intento",
        "calls_by_role": "llamadas por rol",
        "lost": "referencia no usada",
        "verdicts_demo": (
            "veredictos simulados (ilustración escrita a mano)"
        ),
        "plan_ok": "plan propuesto por el modelo, validado",
        "plan_refused": "plan rechazado",
        "saved": "estado guardado",
        "interrupted": "misión interrumpida",
        "resumed": "estado recuperado, pasos ya hechos",
        "mission_done": "misión terminada",
        "synthesis": "síntesis",
        "code_checks": "controles del código",
        "review": (
            "revisión por un modelo (opinión, por verificar)"
        ),
        "no_issue": "ningún problema señalado",
        "no_review": "ninguna opinión utilizable",
    },
    "de": {
        "turns": "Runden",
        "session": "Sitzung",
        "confirm": "Bestätigung angefragt",
        "memory_file": "Gedächtnisdatei",
        "entries": "Eintrag/Einträge",
        "history": "Verlauf zu Beginn",
        "messages": "Nachricht(en)",
        "checks": "Prüfung der Quellenangaben:",
        "yes": "ja",
        "no": "nein",
        "unknown": "?",
        "cols": "existiert gelesen Auszug belegt",
        "estimated": "Schätzung",
        "tool": "Werkzeug",
        "status": "Status",
        "answer": "Antwort",
        "tokens": "Token (Eingabe/Ausgabe)",
        "simulated": "simuliertes Modell: kein Netzwerkaufruf",
        "live_off": (
            "Echte Aufrufe sind deaktiviert. Setzen Sie "
            "ASSISTANT_ALLOW_LIVE=1 und AGENT_MODEL in .env."
        ),
        "no_key": "ANTHROPIC_API_KEY ist nicht gesetzt.",
        "cost": "geschätzte Kosten",
        "review_demo": (
            "simulierte Durchsicht (von Hand geschrieben)"
        ),
        "no_docs": "Ordner ohne verwendbare Dokumente",
        "other_folder": (
            "dieser Auftrag betrifft einen anderen Ordner"
        ),
        "person_sees": "der Mensch sieht",
        "person_says": "Antwort",
        "journal": "Protokoll",
        "resolve_needs": (
            "Geben Sie auch --happened yes|no und --who an."
        ),
        "approve_q": "Genau diesen Text senden? [j/N] ",
        "checks_failed": (
            "Prüfungen nicht bestanden: kein Versand"
        ),
        "not_sent": "nicht gesendet",
        "corpus_changed": "seit dem Start geänderte Dokumente",
        "use_restart": (
            "nicht wieder aufgenommen: erneut mit --r"
            "estart starten"
        ),
        "researcher": "Rechercheur",
        "writer": "Verfasser",
        "verifier": "Prüfer",
        "orchestrator": "Orchestrator",
        "attempt": "Lauf",
        "calls_by_role": "Aufrufe pro Rolle",
        "lost": "nicht verwendete Quelle",
        "verdicts_demo": (
            "simulierte Urteile (von Hand geschrieben)"
        ),
        "plan_ok": "Plan vom Modell vorgeschlagen, geprüft",
        "plan_refused": "Plan abgelehnt",
        "saved": "Zustand gespeichert",
        "interrupted": "Auftrag unterbrochen",
        "resumed": "Zustand übernommen, bereits erledigt",
        "mission_done": "Auftrag abgeschlossen",
        "synthesis": "Synthese",
        "code_checks": "Prüfungen durch den Code",
        "review": (
            "Durchsicht durch ein Modell "
            "(Einschätzung, zu prüfen)"
        ),
        "no_issue": "kein Problem gemeldet",
        "no_review": "keine verwertbare Einschätzung",
    },
}

for _lang, _extra in {
    "fr": {
        "rep_sim": "SIMULÉ : réponses écrites à la main. Ces chiffres ne testent que le programme ; ils ne mesurent aucun modèle et ne comparent rien.",
        "rep_exp": "Expérience conduite en français. Traduire ces résultats ne valide pas les agents dans d'autres langues.",
        "rep_tuning": "Tâches d'ajustement : pas de conclusion",
        "rep_final": "Tâches d'évaluation : échantillon exploratoire",
        "rep_head": "{tasks} tâches, modèle {model} ; aucune conclusion générale.",
        "rep_rounds": "Manches : {complete} complète(s), {partial} partielle(s), {planned} au plus.",
        "rep_runs": "{arch} : {runs} exécutions, {attempts} tentatives",
        "rep_agent": "agent seul",
        "rep_team": "workflow",
        "rep_outcomes": "issues : {kinds}",
        "rep_graded": "notes humaines : {graded} réponse(s) ; sans réponse, 0 par règle : {none} ; à noter : {pending}",
        "rep_auto": "contrôles automatiques, pas une note ({runs}) : {auto}",
        "rep_usage": "appels : {calls} ; jetons : {tokens}",
        "rep_time": "secondes : {seconds} ; dollars comptés : {usd}",
        "rep_limits": "limites atteintes : {limits}",
        "rep_objected": "objections : {objected} ; révisions : {revised}",
        "rep_pairs": "tâche par tâche, notes humaines : agent seul plus haut {agent} ; workflow plus haut {team} ; égal {equal} ; à noter {ungraded}",
        "rep_partial": "Manche {number} PARTIELLE, hors décomptes : {done}/{expected} exécutions ; comparaisons incomplètes : {tasks}",
        "crit_exactitude": "exactitude",
        "crit_sources": "sources",
        "crit_contradictions": "contradictions",
        "crit_absence": "information absente",
        "costs_title": "Coût par mission",
        "costs_head": "mission : tentatives, échecs, jetons entrée/sortie, dollars",
        "costs_total": "total",
        "costs_note": "Dollars calculés aux tarifs publiés, hors taxes. Une tentative échouée compte pour son maximum. La facture fait foi.",
        "costs_empty": "Registre vide.",
    },
    "en": {
        "rep_sim": "SIMULATED: hand-written answers. These figures test the program only; they measure no model and compare nothing.",
        "rep_exp": "Experiment conducted in French. Translating these results does not validate the agents in other languages.",
        "rep_tuning": "Tuning tasks: no conclusion",
        "rep_final": "Evaluation tasks: exploratory sample",
        "rep_head": "{tasks} tasks, model {model}; no general conclusion.",
        "rep_rounds": "Rounds: {complete} complete, {partial} partial, {planned} at most.",
        "rep_runs": "{arch}: {runs} runs, {attempts} attempts",
        "rep_agent": "single agent",
        "rep_team": "workflow",
        "rep_outcomes": "outcomes: {kinds}",
        "rep_graded": "human grades: {graded} answer(s); no answer, 0 by rule: {none}; to grade: {pending}",
        "rep_auto": "automatic checks, not a grade ({runs}): {auto}",
        "rep_usage": "calls: {calls}; tokens: {tokens}",
        "rep_time": "seconds: {seconds}; dollars counted: {usd}",
        "rep_limits": "limits reached: {limits}",
        "rep_objected": "objections: {objected}; revisions: {revised}",
        "rep_pairs": "task by task, human grades: single agent higher {agent}; workflow higher {team}; equal {equal}; to grade {ungraded}",
        "rep_partial": "Round {number} PARTIAL, outside the counts: {done}/{expected} runs; incomplete comparisons: {tasks}",
        "crit_exactitude": "accuracy",
        "crit_sources": "sources",
        "crit_contradictions": "contradictions",
        "crit_absence": "missing information",
        "costs_title": "Cost per mission",
        "costs_head": "mission: attempts, failures, tokens in/out, dollars",
        "costs_total": "total",
        "costs_note": "Dollars computed at published prices, before taxes. A failed attempt counts at its maximum. The invoice is what counts.",
        "costs_empty": "Empty ledger.",
    },
    "es": {
        "rep_sim": "SIMULADO: respuestas escritas a mano. Estas cifras solo prueban el programa; no miden ningún modelo ni comparan nada.",
        "rep_exp": "Experimento realizado en francés. Traducir estos resultados no valida los agentes en otros idiomas.",
        "rep_tuning": "Tareas de ajuste: sin conclusión",
        "rep_final": "Tareas de evaluación: muestra exploratoria",
        "rep_head": "{tasks} tareas, modelo {model}; ninguna conclusión general.",
        "rep_rounds": "Rondas: {complete} completa(s), {partial} parcial(es), {planned} como máximo.",
        "rep_runs": "{arch}: {runs} ejecuciones, {attempts} intentos",
        "rep_agent": "agente único",
        "rep_team": "flujo de trabajo",
        "rep_outcomes": "resultados: {kinds}",
        "rep_graded": "notas humanas: {graded} respuesta(s); sin respuesta, 0 por regla: {none}; por calificar: {pending}",
        "rep_auto": "controles automáticos, no una nota ({runs}): {auto}",
        "rep_usage": "llamadas: {calls}; tokens: {tokens}",
        "rep_time": "segundos: {seconds}; dólares contados: {usd}",
        "rep_limits": "límites alcanzados: {limits}",
        "rep_objected": "objeciones: {objected}; revisiones: {revised}",
        "rep_pairs": "tarea por tarea, notas humanas: agente único más alto {agent}; flujo de trabajo más alto {team}; igual {equal}; por calificar {ungraded}",
        "rep_partial": "Ronda {number} PARCIAL, fuera de los recuentos: {done}/{expected} ejecuciones; comparaciones incompletas: {tasks}",
        "crit_exactitude": "exactitud",
        "crit_sources": "fuentes",
        "crit_contradictions": "contradicciones",
        "crit_absence": "información ausente",
        "costs_title": "Coste por misión",
        "costs_head": "misión: intentos, fallos, tokens entrada/salida, dólares",
        "costs_total": "total",
        "costs_note": "Dólares calculados con los precios publicados, sin impuestos. Un intento fallido cuenta por su máximo. La factura es lo que vale.",
        "costs_empty": "Registro vacío.",
    },
    "de": {
        "rep_sim": "SIMULIERT: von Hand geschriebene Antworten. Diese Zahlen testen nur das Programm; sie messen kein Modell und vergleichen nichts.",
        "rep_exp": "Experiment auf Französisch durchgeführt. Die Übersetzung dieser Ergebnisse bestätigt die Agenten nicht in anderen Sprachen.",
        "rep_tuning": "Anpassungsaufgaben: keine Schlussfolgerung",
        "rep_final": "Bewertungsaufgaben: explorative Stichprobe",
        "rep_head": "{tasks} Aufgaben, Modell {model}; keine allgemeine Schlussfolgerung.",
        "rep_rounds": "Runden: {complete} vollständig, {partial} unvollständig, höchstens {planned}.",
        "rep_runs": "{arch}: {runs} Läufe, {attempts} Versuche",
        "rep_agent": "einzelner Agent",
        "rep_team": "Workflow",
        "rep_outcomes": "Ergebnisse: {kinds}",
        "rep_graded": "menschliche Noten: {graded} Antwort(en); keine Antwort, 0 per Regel: {none}; zu bewerten: {pending}",
        "rep_auto": "automatische Prüfungen, keine Note ({runs}): {auto}",
        "rep_usage": "Aufrufe: {calls}; Token: {tokens}",
        "rep_time": "Sekunden: {seconds}; gezählte Dollar: {usd}",
        "rep_limits": "erreichte Grenzen: {limits}",
        "rep_objected": "Einwände: {objected}; Überarbeitungen: {revised}",
        "rep_pairs": "Aufgabe für Aufgabe, menschliche Noten: einzelner Agent höher {agent}; Workflow höher {team}; gleich {equal}; zu bewerten {ungraded}",
        "rep_partial": "Runde {number} UNVOLLSTÄNDIG, außerhalb der Zählung: {done}/{expected} Läufe; unvollständige Vergleiche: {tasks}",
        "crit_exactitude": "Richtigkeit",
        "crit_sources": "Quellen",
        "crit_contradictions": "Widersprüche",
        "crit_absence": "fehlende Information",
        "costs_title": "Kosten pro Auftrag",
        "costs_head": "Auftrag: Versuche, Fehler, Token ein/aus, Dollar",
        "costs_total": "gesamt",
        "costs_note": "Dollar zu veröffentlichten Preisen, ohne Steuern. Ein gescheiterter Versuch zählt mit seinem Höchstbetrag. Maßgeblich ist die Rechnung.",
        "costs_empty": "Leeres Register.",
    },
}.items():
    MESSAGES[_lang].update(_extra)


# Chapter 11: the interface.
_UI_KEYS = (
    "title",
    "simulated",
    "simulated_tag",
    "password",
    "unlock",
    "no_password",
    "wrong_password",
    "limits",
    "question",
    "folder",
    "no_folder",
    "mode",
    "mode_simulated",
    "mode_real",
    "real_off",
    "real_on",
    "live_refused",
    "ask",
    "waiting",
    "stopped",
    "references",
    "refs_note",
    "no_refs",
    "send_title",
    "target",
    "no_target",
    "who",
    "draft",
    "prepare",
    "preview",
    "personal",
    "approve",
    "changed",
    "sent",
    "refused",
    "unknown_outcome",
    "demo_changed",
    "demo_exact",
    "demo_again",
)
_UI_TEXT = {
    "fr": (
        "Assistant documentaire Rivelune",
        "SIMULÉ : réponse écrite à la main à l'avance, la même quelle que soit la question. Aucun appel au modèle.",
        "SIMULÉ : texte d'exemple, pas une réponse de modèle",
        "Mot de passe d'accès",
        "Entrer",
        "Accès fermé : définissez ASSISTANT_UI_PASSWORD, puis relancez.",
        "Mot de passe incorrect.",
        "Accès minimal : un mot de passe partagé, sans compte ni limite d'essais. À ne pas exposer tel quel sur Internet.",
        "Question",
        "Dossier de documents",
        "Aucun dossier de documents trouvé.",
        "Mode",
        "Simulé (aucun appel)",
        "Réel (payant)",
        "Mode réel désactivé : ASSISTANT_ALLOW_LIVE ne vaut pas 1.",
        "Mode réel : la question et les documents lus partent chez le fournisseur du modèle, et chaque appel est facturé.",
        "Mode réel refusé : activation, modèle, clé ou tarif manquant. Le motif figure dans le journal du serveur.",
        "Poser la question",
        "Recherche en cours : une question réelle prend souvent plusieurs secondes.",
        "Arrêt",
        "Références contrôlées",
        "Existe, consulté, extrait : contrôles automatiques. C'est à vous de juger si le passage soutient l'affirmation.",
        "Aucune référence dans cette réponse.",
        "Envoi (fichier local dans outbox/)",
        "Destinataire",
        "Aucun destinataire autorisé : voir ASSISTANT_ALLOWED_TARGETS.",
        "Votre nom (déclaré, non vérifié)",
        "Texte à envoyer",
        "Préparer l'envoi",
        "aperçu de l'envoi",
        "Attention : ce texte semble contenir une donnée personnelle.",
        "J'approuve ce texte exact",
        "Le texte a changé depuis l'aperçu : préparez de nouveau l'envoi.",
        "Fichier écrit ; rien n'a quitté cette machine",
        "Refusé",
        "Issue inconnue d'un envoi précédent : une personne doit vérifier, puis l'enregistrer avec `assistant actions`.",
        "Texte modifié après l'aperçu",
        "Texte exact approuvé",
        "Même texte, second clic",
    ),
    "en": (
        "Rivelune document assistant",
        "SIMULATED: an answer written by hand in advance, the same whatever the question. No call to the model.",
        "SIMULATED: sample text, not a model answer",
        "Access password",
        "Enter",
        "Access closed: set ASSISTANT_UI_PASSWORD, then start again.",
        "Wrong password.",
        "Minimal access: one shared password, no accounts, no limit on attempts. Do not expose this to the Internet as it is.",
        "Question",
        "Document folder",
        "No document folder found.",
        "Mode",
        "Simulated (no call)",
        "Real (paid)",
        "Real mode is off: ASSISTANT_ALLOW_LIVE is not 1.",
        "Real mode: the question and the documents read go to the model provider, and each call is billed.",
        "Real mode refused: switch, model, key or price missing. The reason is in the server log.",
        "Ask",
        "Working: a real question often takes several seconds.",
        "Stopped",
        "Checked references",
        "Exists, consulted, excerpt: automatic checks. It is up to you to judge whether the passage supports the claim.",
        "No reference in this answer.",
        "Sending (a local file in outbox/)",
        "Recipient",
        "No recipient allowed: see ASSISTANT_ALLOWED_TARGETS.",
        "Your name (stated, not verified)",
        "Text to send",
        "Prepare the sending",
        "sending preview",
        "Warning: this text seems to contain personal data.",
        "I approve this exact text",
        "The text changed since the preview: prepare the sending again.",
        "File written; nothing left this machine",
        "Refused",
        "Unknown outcome of an earlier sending: a person must check, then record it with `assistant actions`.",
        "Text changed after the preview",
        "Exact text approved",
        "Same text, second click",
    ),
    "es": (
        "Asistente documental de Rivelune",
        "SIMULADO: respuesta escrita a mano por adelantado, la misma sea cual sea la pregunta. Ninguna llamada al modelo.",
        "SIMULADO: texto de ejemplo, no una respuesta de un modelo",
        "Contraseña de acceso",
        "Entrar",
        "Acceso cerrado: define ASSISTANT_UI_PASSWORD y vuelve a iniciar.",
        "Contraseña incorrecta.",
        "Acceso mínimo: una contraseña compartida, sin cuentas ni límite de intentos. No la expongas así en Internet.",
        "Pregunta",
        "Carpeta de documentos",
        "No se encontró ninguna carpeta de documentos.",
        "Modo",
        "Simulado (ninguna llamada)",
        "Real (de pago)",
        "Modo real desactivado: ASSISTANT_ALLOW_LIVE no vale 1.",
        "Modo real: la pregunta y los documentos leídos van al proveedor del modelo, y cada llamada se factura.",
        "Modo real rechazado: falta la activación, el modelo, la clave o el precio. El motivo está en el registro del servidor.",
        "Preguntar",
        "Buscando: una pregunta real suele tardar varios segundos.",
        "Detenido",
        "Referencias comprobadas",
        "Existe, consultado, extracto: comprobaciones automáticas. Te toca a ti juzgar si el pasaje respalda la afirmación.",
        "Ninguna referencia en esta respuesta.",
        "Envío (un archivo local en outbox/)",
        "Destinatario",
        "Ningún destinatario autorizado: consulta ASSISTANT_ALLOWED_TARGETS.",
        "Tu nombre (declarado, no verificado)",
        "Texto que se enviará",
        "Preparar el envío",
        "vista previa del envío",
        "Atención: este texto parece contener un dato personal.",
        "Apruebo este texto exacto",
        "El texto cambió desde la vista previa: prepara de nuevo el envío.",
        "Archivo escrito; nada ha salido de esta máquina",
        "Rechazado",
        "Resultado desconocido de un envío anterior: una persona debe comprobarlo y registrarlo con `assistant actions`.",
        "Texto modificado tras la vista previa",
        "Texto exacto aprobado",
        "Mismo texto, segundo clic",
    ),
    "de": (
        "Dokumentenassistent Rivelune",
        "SIMULIERT: eine im Voraus von Hand geschriebene Antwort, gleich bei jeder Frage. Kein Aufruf des Modells.",
        "SIMULIERT: Beispieltext, keine Antwort eines Modells",
        "Zugangspasswort",
        "Anmelden",
        "Zugang geschlossen: Setzen Sie ASSISTANT_UI_PASSWORD und starten Sie neu.",
        "Falsches Passwort.",
        "Minimaler Zugang: ein gemeinsames Passwort, keine Konten, keine Begrenzung der Versuche. Nicht so im Internet bereitstellen.",
        "Frage",
        "Dokumentenordner",
        "Kein Dokumentenordner gefunden.",
        "Modus",
        "Simuliert (kein Aufruf)",
        "Real (kostenpflichtig)",
        "Realer Modus ausgeschaltet: ASSISTANT_ALLOW_LIVE ist nicht 1.",
        "Realer Modus: Die Frage und die gelesenen Dokumente gehen an den Modellanbieter, und jeder Aufruf wird berechnet.",
        "Realer Modus abgelehnt: Aktivierung, Modell, Schlüssel oder Preis fehlt. Der Grund steht im Serverprotokoll.",
        "Frage stellen",
        "Suche läuft: Eine echte Frage dauert oft mehrere Sekunden.",
        "Abgebrochen",
        "Geprüfte Quellenangaben",
        "Existiert, gelesen, Auszug: automatische Prüfungen. Ob die Passage die Aussage stützt, beurteilen Sie selbst.",
        "Keine Quellenangabe in dieser Antwort.",
        "Versand (eine lokale Datei in outbox/)",
        "Empfänger",
        "Kein Empfänger erlaubt: siehe ASSISTANT_ALLOWED_TARGETS.",
        "Ihr Name (angegeben, nicht geprüft)",
        "Zu sendender Text",
        "Versand vorbereiten",
        "Versandvorschau",
        "Achtung: Dieser Text scheint personenbezogene Daten zu enthalten.",
        "Ich genehmige genau diesen Text",
        "Der Text hat sich seit der Vorschau geändert: Bereiten Sie den Versand erneut vor.",
        "Datei geschrieben; nichts hat diesen Rechner verlassen",
        "Abgelehnt",
        "Unbekannter Ausgang eines früheren Versands: Eine Person muss ihn prüfen und mit `assistant actions` festhalten.",
        "Text nach der Vorschau geändert",
        "Genauer Text genehmigt",
        "Gleicher Text, zweiter Klick",
    ),
}
for _lang, _texts in _UI_TEXT.items():
    MESSAGES[_lang].update(
        {
            f"ui_{key}": text
            for key, text in zip(_UI_KEYS, _texts, strict=True)
        }
    )


def t(lang: str, key: str) -> str:
    return MESSAGES[lang][key]


# Text produced by the program stays in English in the code, and
# what tools return to the model too. A person reads it through
# localize(). Text that matches nothing (from the SDK, Pydantic,
# Streamlit) comes back unchanged: it keeps its authentic form.
_PREFIXES = {
    r"-> (.*)": ("-> {0}", "-> {0}", "-> {0}"),
    r"ERROR: (.*)": (
        "ERREUR : {0}",
        "ERROR: {0}",
        "FEHLER: {0}",
    ),
    r"WARNING: (.*)": (
        "ATTENTION : {0}",
        "ATENCIÓN: {0}",
        "WARNUNG: {0}",
    ),
    r"Not sent: (.*)": (
        "Non envoyé : {0}",
        "No enviado: {0}",
        "Nicht gesendet: {0}",
    ),
    r"Not remembered: (.*)": (
        "Non mémorisé : {0}",
        "No memorizado: {0}",
        "Nicht gespeichert: {0}",
    ),
    r"refused or failed: (.*)": (
        "refus ou échec : {0}",
        "rechazo o fallo: {0}",
        "Ablehnung oder Fehler: {0}",
    ),
    r"refused: (.*)": (
        "refusé : {0}",
        "rechazado: {0}",
        "abgelehnt: {0}",
    ),
    r"stop: (.*)": (
        "arrêt : {0}",
        "parada: {0}",
        "Abbruch: {0}",
    ),
}

# (pattern, (fr, es, de)). English is the text itself.
_TRANSLATIONS = {
    r"connection lost \(simulated\)": (
        "connexion perdue (simulé)",
        "conexión perdida (simulado)",
        "Verbindung verloren (simuliert)",
    ),
    # Budget: step 10 and chapter 2.
    r"call cap (\d+) reached": (
        "limite de {0} appels atteinte",
        "límite de {0} llamadas alcanzado",
        "Grenze von {0} Aufrufen erreicht",
    ),
    r"request may exceed (\d+) input tokens": (
        "la requête peut dépasser {0} jetons d'entrée",
        "la solicitud puede superar {0} tokens de entrada",
        "die Anfrage kann {0} Eingabe-Tokens überschreiten",
    ),
    r"no price for (.+)": (
        "aucun tarif connu pour {0}",
        "ningún precio conocido para {0}",
        "kein Preis bekannt für {0}",
    ),
    r"call may cost ([\d.]+) USD; limit per call ([\d.]+)": (
        "cet appel peut coûter {0} USD ; limite par appel : {1}",
        "esta llamada puede costar {0} USD; límite por llamada: {1}",
        "dieser Aufruf kann {0} USD kosten; Grenze pro Aufruf: {1}",
    ),
    r"next call could cost ([\d.]+) USD; spent ([\d.]+) of ([\d.]+)": (
        "limite atteinte : le prochain appel peut coûter {0} USD ; déjà compté {1} sur {2}",
        "límite alcanzado: la próxima llamada puede costar {0} USD; ya contado {1} de {2}",
        "Grenze erreicht: Der nächste Aufruf kann {0} USD kosten; bereits gezählt {1} von {2}",
    ),
    r"real cost above its worst case: bound broken": (
        "coût réel au-dessus du maximum calculé : borne dépassée",
        "coste real por encima del máximo calculado: límite superado",
        "reale Kosten über dem berechneten Maximum: Grenze verletzt",
    ),
    r"team budget reached": (
        "budget de l'équipe atteint",
        "presupuesto del equipo alcanzado",
        "Budget des Teams erreicht",
    ),
    # Sending: chapters 7 and 11.
    r"an earlier sending has an unknown outcome: a person must check it; do not try again": (
        "un envoi précédent a une issue inconnue : une personne doit vérifier ; ne réessayez pas",
        "un envío anterior tiene un resultado desconocido: una persona debe comprobarlo; no lo intentes de nuevo",
        "ein früherer Versand hat einen unbekannten Ausgang: Eine Person muss ihn prüfen; nicht erneut versuchen",
    ),
    r"recipient not allowed: (.+)": (
        "destinataire non autorisé : {0}",
        "destinatario no autorizado: {0}",
        "Empfänger nicht erlaubt: {0}",
    ),
    r"hidden characters: (.+)": (
        "caractères invisibles : {0}",
        "caracteres invisibles: {0}",
        "unsichtbare Zeichen: {0}",
    ),
    r"text too long to send": (
        "texte trop long pour être envoyé",
        "texto demasiado largo para enviarlo",
        "Text zu lang für den Versand",
    ),
    r"this exact action was already sent": (
        "cette action exacte a déjà été envoyée",
        "esta acción exacta ya se envió",
        "genau diese Aktion wurde bereits gesendet",
    ),
    r"declined by the person": (
        "refusé par la personne",
        "rechazado por la persona",
        "von der Person abgelehnt",
    ),
    r"a name is required to approve": (
        "un nom est nécessaire pour approuver",
        "se necesita un nombre para aprobar",
        "zum Genehmigen ist ein Name nötig",
    ),
    r"content too large": (
        "contenu trop volumineux",
        "contenido demasiado grande",
        "Inhalt zu groß",
    ),
    r"text changed since the preview": (
        "texte modifié depuis l'aperçu",
        "texto modificado desde la vista previa",
        "Text seit der Vorschau geändert",
    ),
    r"no approval": (
        "aucune approbation",
        "ninguna aprobación",
        "keine Genehmigung",
    ),
    r"content changed since approval": (
        "contenu modifié depuis l'approbation",
        "contenido modificado desde la aprobación",
        "Inhalt seit der Genehmigung geändert",
    ),
    r"approval already used": (
        "approbation déjà utilisée",
        "aprobación ya utilizada",
        "Genehmigung bereits verwendet",
    ),
    r"nothing to resolve: (.+)": (
        "rien à régler : {0}",
        "nada que resolver: {0}",
        "nichts zu klären: {0}",
    ),
    # Files and documents.
    r"outside allowed folders: (.+)": (
        "hors des dossiers autorisés : {0}",
        "fuera de las carpetas autorizadas: {0}",
        "außerhalb der erlaubten Ordner: {0}",
    ),
    r"file name refused: (.+)": (
        "nom de fichier refusé : {0}",
        "nombre de archivo rechazado: {0}",
        "Dateiname abgelehnt: {0}",
    ),
    r"file already exists: (.+)": (
        "le fichier existe déjà : {0}",
        "el archivo ya existe: {0}",
        "Datei existiert bereits: {0}",
    ),
    r"not a document folder: (.+)": (
        "pas un dossier de documents : {0}",
        "no es una carpeta de documentos: {0}",
        "kein Dokumentenordner: {0}",
    ),
    r"(.+): missing header": (
        "{0} : en-tête manquant",
        "{0}: falta la cabecera",
        "{0}: Kopfzeilen fehlen",
    ),
    r"(.+): id does not match file name": (
        "{0} : l'identifiant ne correspond pas au nom du fichier",
        "{0}: el identificador no coincide con el nombre del archivo",
        "{0}: Kennung passt nicht zum Dateinamen",
    ),
    r"(.+): duplicate (.+)": (
        "{0} : {1} en double",
        "{0}: {1} duplicado",
        "{0}: {1} doppelt",
    ),
    r"invalid file name: (.+)": (
        "nom de fichier invalide : {0}",
        "nombre de archivo no válido: {0}",
        "ungültiger Dateiname: {0}",
    ),
    # Memory: chapter 5.
    r"kind must be one of (.+)": (
        "le type doit être l'un de {0}",
        "el tipo debe ser uno de {0}",
        "die Art muss eine von {0} sein",
    ),
    r"text must be 1 to (\d+) characters": (
        "le texte doit compter de 1 à {0} caractères",
        "el texto debe tener de 1 a {0} caracteres",
        "der Text muss 1 bis {0} Zeichen haben",
    ),
    r"angle brackets not allowed": (
        "chevrons non autorisés",
        "corchetes angulares no permitidos",
        "spitze Klammern nicht erlaubt",
    ),
    r"looks like personal data: refused": (
        "ressemble à une donnée personnelle : refusé",
        "parece un dato personal: rechazado",
        "sieht nach personenbezogenen Daten aus: abgelehnt",
    ),
    r"looks like personal data": (
        "ressemble à une donnée personnelle",
        "parece un dato personal",
        "sieht nach personenbezogenen Daten aus",
    ),
    r"already remembered": (
        "déjà mémorisé",
        "ya memorizado",
        "bereits gespeichert",
    ),
    r"memory full: forget an entry": (
        "mémoire pleine : oubliez une entrée",
        "memoria llena: olvida una entrada",
        "Speicher voll: Löschen Sie einen Eintrag",
    ),
    r"the user declined": (
        "la personne a refusé",
        "la persona rechazó",
        "die Person hat abgelehnt",
    ),
    r"no memory entry '(.+)'": (
        "aucune entrée de mémoire « {0} »",
        "ninguna entrada de memoria «{0}»",
        "kein Speichereintrag „{0}“",
    ),
    # What tools return, as a trace shows it.
    r"No document '(.+)'\. Call list_documents to see valid ids\.": (
        "Aucun document « {0} ». Appelez list_documents pour voir les identifiants valides.",
        "Ningún documento «{0}». Llama a list_documents para ver los identificadores válidos.",
        "Kein Dokument „{0}“. Rufen Sie list_documents auf, um die gültigen Kennungen zu sehen.",
    ),
    r"No passage matches these words\.": (
        "Aucun passage ne correspond à ces mots.",
        "Ningún pasaje coincide con estas palabras.",
        "Keine Passage passt zu diesen Wörtern.",
    ),
    r"Remembered as (.+)\.": (
        "Mémorisé sous {0}.",
        "Memorizado como {0}.",
        "Gespeichert als {0}.",
    ),
    r"Forgotten: (.+)\.": (
        "Oublié : {0}.",
        "Olvidado: {0}.",
        "Gelöscht: {0}.",
    ),
    r"Sent \(simulated\): (.+)": (
        "Envoyé (simulé) : {0}",
        "Enviado (simulado): {0}",
        "Gesendet (simuliert): {0}",
    ),
    r"Unknown tool: (.+)": (
        "Outil inconnu : {0}",
        "Herramienta desconocida: {0}",
        "Unbekanntes Werkzeug: {0}",
    ),
    r"Invalid input\. (.+)": (
        "Entrée invalide. {0}",
        "Entrada no válida. {0}",
        "Ungültige Eingabe. {0}",
    ),
    r"turn (\d+): (.+)": (
        "tour {0} : {1}",
        "turno {0}: {1}",
        "Runde {0}: {1}",
    ),
    # Plans and roles: chapters 6 and 8.
    r"no plan: (.+)": (
        "aucun plan : {0}",
        "ningún plan: {0}",
        "kein Plan: {0}",
    ),
    r"no brief \((.+)\)": (
        "aucun Brief ({0})",
        "ningún Brief ({0})",
        "kein Brief ({0})",
    ),
    r"no review \((.+)\)": (
        "aucune relecture ({0})",
        "ninguna revisión ({0})",
        "keine Prüfung ({0})",
    ),
    r"no result: (.+)": (
        "aucun résultat : {0}",
        "ningún resultado: {0}",
        "kein Ergebnis: {0}",
    ),
    r"(.+): no such passage": (
        "{0} : ce passage n'existe pas",
        "{0}: ese pasaje no existe",
        "{0}: diese Passage gibt es nicht",
    ),
    r"(.+): you did not read it": (
        "{0} : passage non lu",
        "{0}: pasaje no leído",
        "{0}: Passage nicht gelesen",
    ),
    r"(.+): quote not in passage": (
        "{0} : citation absente du passage",
        "{0}: cita ausente del pasaje",
        "{0}: Zitat nicht in der Passage",
    ),
    r"(\d+): no reference": (
        "{0} : aucune référence",
        "{0}: ninguna referencia",
        "{0}: keine Quellenangabe",
    ),
    r"(\d+): not in brief: (.+)": (
        "{0} : absent du Brief : {1}",
        "{0}: ausente del Brief: {1}",
        "{0}: nicht im Brief: {1}",
    ),
    # The experiment: chapter 9.
    r"limits may change only after a tuning round": (
        "les limites ne changent qu'après une manche d'ajustement",
        "los límites solo cambian tras una ronda de ajuste",
        "die Grenzen ändern sich erst nach einer Anpassungsrunde",
    ),
    r"a change of limits needs a written justification": (
        "un changement de limites demande une justification écrite",
        "un cambio de límites requiere una justificación escrita",
        "eine Änderung der Grenzen braucht eine schriftliche Begründung",
    ),
    r"final runs exist: no more tuning; adjusting now would need new final tasks": (
        "des exécutions d'évaluation existent : plus d'ajustement ; ajuster demanderait de nouvelles tâches d'évaluation",
        "ya hay ejecuciones de evaluación: no más ajustes; ajustar exigiría nuevas tareas de evaluación",
        "Bewertungsläufe existieren: keine Anpassung mehr; sie würde neue Bewertungsaufgaben erfordern",
    ),
    r"tuning rounds used up": (
        "manches d'ajustement épuisées",
        "rondas de ajuste agotadas",
        "Anpassungsrunden aufgebraucht",
    ),
    r"run a tuning round first": (
        "lancez d'abord une manche d'ajustement",
        "lanza primero una ronda de ajuste",
        "Starten Sie zuerst eine Anpassungsrunde",
    ),
    r"planned final rounds done": (
        "manches d'évaluation prévues terminées",
        "rondas de evaluación previstas terminadas",
        "geplante Bewertungsrunden abgeschlossen",
    ),
    r"prompts, code, tasks, grid, limits or rounds changed since the first final run": (
        "consignes, code, tâches, grille, limites ou manches modifiés depuis la première exécution d'évaluation",
        "instrucciones, código, tareas, rúbrica, límites o rondas modificados desde la primera ejecución de evaluación",
        "Anweisungen, Code, Aufgaben, Raster, Grenzen oder Runden seit dem ersten Bewertungslauf geändert",
    ),
    r"maximal cost ([\d.]+) USD does not fit: spent ([\d.]+), limit ([\d.]+)": (
        "le coût maximal de {0} USD ne tient pas : déjà compté {1}, limite {2}",
        "el coste máximo de {0} USD no cabe: ya contado {1}, límite {2}",
        "die Maximalkosten von {0} USD passen nicht: bereits gezählt {1}, Grenze {2}",
    ),
    r"(.+): bad grade (.+)": (
        "{0} : note invalide {1}",
        "{0}: nota no válida {1}",
        "{0}: ungültige Note {1}",
    ),
    r"(.+): graded but not signed": (
        "{0} : noté mais non signé",
        "{0}: calificado pero sin firmar",
        "{0}: bewertet, aber nicht unterschrieben",
    ),
    r"already frozen: (.+)": (
        "déjà figé : {0}",
        "ya congelado: {0}",
        "bereits eingefroren: {0}",
    ),
    r"no real run yet": (
        "aucune exécution réelle pour l'instant",
        "ninguna ejecución real por ahora",
        "noch kein realer Lauf",
    ),
    r"choose --split, --sheet, --report or --dry-run": (
        "choisissez --split, --sheet, --report ou --dry-run",
        "elige --split, --sheet, --report o --dry-run",
        "wählen Sie --split, --sheet, --report oder --dry-run",
    ),
    r"ASSISTANT_ALLOW_LIVE is not 1": (
        "ASSISTANT_ALLOW_LIVE ne vaut pas 1",
        "ASSISTANT_ALLOW_LIVE no vale 1",
        "ASSISTANT_ALLOW_LIVE ist nicht 1",
    ),
    r"ANTHROPIC_API_KEY is not set": (
        "ANTHROPIC_API_KEY n'est pas définie",
        "ANTHROPIC_API_KEY no está definida",
        "ANTHROPIC_API_KEY ist nicht gesetzt",
    ),
    r"blocks A, B and C come first": (
        "les blocs A, B et C passent d'abord",
        "los bloques A, B y C van primero",
        "die Blöcke A, B und C kommen zuerst",
    ),
    r"add --max-usd and --yes for this round, ([\d.]+) USD at most, before taxes": (
        "ajoutez --max-usd et --yes pour cette manche, {0} USD au plus, hors taxes",
        "añade --max-usd y --yes para esta ronda, {0} USD como máximo, sin impuestos",
        "ergänzen Sie --max-usd und --yes für diese Runde, höchstens {0} USD, ohne Steuern",
    ),
    r"--sheet needs --split": (
        "--sheet demande --split",
        "--sheet necesita --split",
        "--sheet braucht --split",
    ),
    r"written: (.+)": (
        "écrit : {0}",
        "escrito: {0}",
        "geschrieben: {0}",
    ),
    r"nothing new to grade": (
        "rien de nouveau à noter",
        "nada nuevo que calificar",
        "nichts Neues zu bewerten",
    ),
    r'usage: first_call "question"': (
        'usage : first_call "question"',
        'uso: first_call "pregunta"',
        'Aufruf: first_call "Frage"',
    ),
}
_COLUMN = {"fr": 0, "es": 1, "de": 2}


def localize(lang: str, text: str) -> str:
    """Our own English messages, for the person who reads them.
    Anything else comes back unchanged."""
    if lang == "en":
        return text
    column = _COLUMN[lang]
    for pattern, forms in _PREFIXES.items():
        found = re.fullmatch(pattern, text, re.DOTALL)
        if found:
            return forms[column].format(
                localize(lang, found[1])
            )
    for pattern, forms in _TRANSLATIONS.items():
        found = re.fullmatch(pattern, text, re.DOTALL)
        if found:
            return forms[column].format(*found.groups())
    if "; " in text:  # several problems, joined by the code
        return "; ".join(
            localize(lang, part) for part in text.split("; ")
        )
    return text


_PREVIEW_LABELS = {
    "fr": (
        "action",
        "destinataire",
        "empreinte",
        "contenu",
        "fin",
    ),
    "es": (
        "acción",
        "destinatario",
        "huella",
        "contenido",
        "fin",
    ),
    "de": (
        "Aktion",
        "Empfänger",
        "Prüfsumme",
        "Inhalt",
        "Ende",
    ),
}


def localize_preview(lang: str, preview: str) -> str:
    """The labels around the text to approve, never the text:
    the gate goes on comparing the preview itself."""
    if lang == "en":
        return preview
    action, target, digest, content, end = _PREVIEW_LABELS[lang]
    labels = {
        "action: ": f"{action}: ",
        "target: ": f"{target}: ",
        "digest: ": f"{digest}: ",
    }
    lines = preview.split("\n")
    colon = " : " if lang == "fr" else ": "
    for i, line in enumerate(lines):
        if line == "--- content ---":
            lines[i] = f"--- {content} ---"
            if (
                lines[-1] == "--- end ---"
                and len(lines) - 1 > i
            ):
                lines[-1] = f"--- {end} ---"
            break
        if line.startswith("WARNING: "):
            lines[i] = localize(lang, line)
        for old, new in labels.items():
            if line.startswith(old):
                value = line[len(old) :]
                head = new.split(":")[0]
                lines[i] = f"{head}{colon}{value}"
    return "\n".join(lines)
