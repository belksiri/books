"""Command line: demo, memory-demo, search, ask, and the
synthesis commands of chapter 6 (synthesis_cli.py)."""

from __future__ import annotations

import argparse
import json
import tempfile
import textwrap
from datetime import date
from pathlib import Path

from assistant.config import LANGS, load_settings
from assistant.corpus import Corpus
from assistant.llm import ModelError
from assistant.memory import MemoryStore
from assistant.messages import localize, t
from assistant.pricing import estimate_cost
from assistant.prompts import load
from assistant.scenarios import (
    MEMORY_TEXT,
    deposit_scenario,
    memory_session1,
    memory_session2,
)
from assistant.step04.agent import new_state, run
from assistant.step04.tools import build_toolbox, simple_search
from assistant.step05.bm25 import bm25_search
from assistant.step05.citations import check_citations
from assistant.step05.tools import build_toolbox_step05

WIDTH = 64


def _c(lang: str) -> str:
    """Colon with French spacing where needed."""
    return "\u00a0: " if lang == "fr" else ": "


def _cut(line: str) -> str:
    return (
        line if len(line) <= WIDTH else line[: WIDTH - 1] + "…"
    )


def _mark(lang: str, value: bool | None) -> str:
    if value is None:
        return t(lang, "unknown")
    return t(lang, "yes") if value else t(lang, "no")


QUESTIONS = {
    "fr": "Quel est le montant du dépôt de garantie ?",
    "de": "Wie hoch ist die Sicherheitsleistung?",
    "en": "How much is the security deposit?",
    "es": "¿Cuál es el importe del depósito de garantía?",
}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="assistant")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("demo", help="simulated run, no API call")
    sub.add_parser(
        "memory-demo", help="two simulated sessions with memory"
    )
    search = sub.add_parser("search", help="run a search")
    search.add_argument("query")
    search.add_argument("--bm25", action="store_true")
    sub.add_parser(
        "synthesis-demo",
        help="simulated synthesis, interrupted then resumed",
    )
    synth = sub.add_parser(
        "synthesis", help="planned synthesis (paid)"
    )
    synth.add_argument("--question", required=True)
    synth.add_argument(
        "--plan", choices=["model", "fixed"], default="model"
    )
    synth.add_argument("--mission", help="id, to resume")
    synth.add_argument(
        "--dossier",
        help="folder of documents to analyse "
        "(default: the demo folder)",
    )
    synth.add_argument(
        "--corpus-lang",
        choices=LANGS,
        help="language of the documents, for the search "
        "(default: ASSISTANT_LANG)",
    )
    synth.add_argument(
        "--date", default=date.today().isoformat()
    )
    synth.add_argument(
        "--restart",
        action="store_true",
        help="start again, discarding the saved mission",
    )
    synth.add_argument(
        "--send-to",
        help="after the checks, ask a person to approve a "
        "simulated sending to this recipient",
    )
    sub.add_parser(
        "approval-demo",
        help="simulated misled model against the barriers",
    )
    actions = sub.add_parser(
        "actions", help="sendings with an unknown outcome"
    )
    actions.add_argument("--resolve", help="digest to settle")
    actions.add_argument("--happened", choices=["yes", "no"])
    actions.add_argument("--who", help="who checked")
    sub.add_parser(
        "team-demo", help="simulated team of three roles"
    )
    team = sub.add_parser(
        "team", help="three roles on a question (paid)"
    )
    team.add_argument("--question", required=True)
    team.add_argument("--dossier", help="folder of documents")
    team.add_argument(
        "--corpus-lang",
        choices=LANGS,
        help="language of the documents, for the search",
    )
    team.add_argument(
        "--date", default=date.today().isoformat()
    )
    evaluate = sub.add_parser(
        "evaluate",
        help="one agent against the team, by the same rules",
    )
    evaluate.add_argument(
        "--dry-run",
        action="store_true",
        help="whole experiment on scripted models, no call",
    )
    evaluate.add_argument(
        "--split", choices=["tuning", "final"]
    )
    evaluate.add_argument("--report", action="store_true")
    evaluate.add_argument(
        "--sheet",
        action="store_true",
        help="blind grading forms for a person",
    )
    evaluate.add_argument(
        "--model-grade",
        action="store_true",
        help="automated grading by a model (paid); never human",
    )
    evaluate.add_argument(
        "--model-report",
        action="store_true",
        help="report of the automated grading, no call",
    )
    evaluate.add_argument(
        "--grade",
        action="store_true",
        help="guided blind grading, for a person",
    )
    evaluate.add_argument(
        "--max-usd",
        type=float,
        help="limit applied by the program to this round",
    )
    evaluate.add_argument("--yes", action="store_true")
    sub.add_parser(
        "costs-demo", help="cost report on a simulated ledger"
    )
    sub.add_parser(
        "interface-demo",
        help="logic of the web page, simulated, in a terminal",
    )
    costs = sub.add_parser(
        "costs", help="cost per mission, from the real ledger"
    )
    costs.add_argument("--ledger", help="ledger file")
    ask = sub.add_parser("ask", help="real run (paid)")
    ask.add_argument("question")
    ask.add_argument("--date", default=date.today().isoformat())
    args = parser.parse_args(argv)

    settings = load_settings()
    lang = settings.lang
    corpus = Corpus.load(settings.data_dir, lang)

    if args.command == "search":
        find = bm25_search if args.bm25 else simple_search
        for passage in find(corpus, args.query, 5):
            print(_cut(f"[{passage.ref}] {passage.text}"))
        return 0

    if args.command == "memory-demo":
        return memory_demo(lang, corpus)

    if args.command == "team-demo":
        from assistant.team_cli import team_demo

        return team_demo(lang, corpus)

    if args.command == "costs-demo":
        from assistant.step10.costs import costs_demo

        return costs_demo(lang, corpus)

    if args.command == "interface-demo":
        from assistant.step11.demo import interface_demo

        return interface_demo(settings)

    if args.command == "costs":
        from assistant.budget import Ledger
        from assistant.config import CODE_DIR
        from assistant.step10.costs import (
            cost_report,
            print_report,
        )

        path = args.ledger or (
            CODE_DIR / "live_results" / "real" / "ledger.jsonl"
        )
        print_report(cost_report(Ledger(path).records), lang)
        return 0

    if args.command == "evaluate":
        from assistant.evaluate_cli import evaluate

        return evaluate(settings, args)

    if args.command == "team":
        from assistant.team_cli import team_live

        return team_live(settings, args)

    if args.command == "approval-demo":
        from assistant.actions_cli import approval_demo

        return approval_demo(lang, corpus)

    if args.command == "actions":
        from assistant.actions_cli import actions as run_actions

        return run_actions(settings, args)

    if args.command == "synthesis-demo":
        from assistant.synthesis_cli import synthesis_demo

        return synthesis_demo(lang, corpus)

    if args.command == "synthesis":
        from assistant.synthesis_cli import synthesis_live

        return synthesis_live(settings, args)

    if args.command == "demo":
        model = deposit_scenario(lang)
        question, today = QUESTIONS[lang], "2026-06-15"
        print(f"({t(lang, 'simulated')})")
    else:
        from assistant.paid import mission_key, open_model

        model = open_model(
            settings, mission_key("ask", args.question), 12
        )
        if model is None:
            return 2
        question, today = args.question, args.date

    state = new_state()
    toolbox = build_toolbox(
        corpus, settings.notes_dir, state.consulted
    )
    system = load("step04", lang, today=today)
    try:
        run_result = run(
            model, system, question, toolbox, state
        )
    except ModelError as error:
        print(localize(lang, f"stop: {error}"))
        return 3

    _report(
        lang,
        corpus,
        run_result,
        state,
        model.name,
        simulated=args.command == "demo",
    )
    return 0


def memory_demo(lang: str, corpus: Corpus) -> int:
    """Two sessions: history is lost, confirmed memory stays."""
    print(f"({t(lang, 'simulated')})")
    texts = MEMORY_TEXT[lang]
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp) / "memory"

        def confirm(text: str) -> bool:
            print(
                _cut(f"{t(lang, 'confirm')} : {text}")
                if lang == "fr"
                else _cut(f"{t(lang, 'confirm')}: {text}")
            )
            return True  # scripted "yes" of the simulated user

        scripts = [
            (memory_session1, texts["ask1"]),
            (memory_session2, texts["ask2"]),
        ]
        for number, (script, question) in enumerate(scripts, 1):
            print(f"=== {t(lang, 'session')} {number} ===")
            memory = MemoryStore(
                folder, confirm, today=lambda: "2026-06-15"
            )
            state = new_state()
            toolbox = build_toolbox_step05(
                corpus,
                Path(tmp) / "notes",
                state.consulted,
                memory,
            )
            print(
                f"{t(lang, 'history')}{_c(lang)}1 "
                f"{t(lang, 'messages')}"
            )
            print(
                f"{t(lang, 'memory_file')}{_c(lang)}"
                f"{len(memory.entries)} {t(lang, 'entries')}"
            )
            system = load(
                "step05",
                lang,
                today="2026-06-15",
                memory=memory.as_context(),
            )
            model = script(lang)
            result = run(
                model, system, question, toolbox, state
            )
            _report(
                lang,
                corpus,
                result,
                state,
                model.name,
                simulated=True,
            )
        saved = json.loads((folder / "memory.json").read_text())
        label = t(lang, "memory_file")
        print(f"{label} memory.json{_c(lang).rstrip()}")
        for entry in saved:
            print(
                _cut(
                    f"  {entry['id']} {entry['kind']}: "
                    f"{entry['text']}"
                )
            )
    return 0


def _report(
    lang, corpus, run_result, state, model_name, simulated: bool
) -> None:
    """Print a run: tool calls, answer, reference checks."""
    for i, event in enumerate(state.events, start=1):
        call, result = event.split("\n", 1)
        print(_cut(f"{i}. {call}"))
        print(_cut(f"   {localize(lang, result)}"))
    print(
        f"{t(lang, 'status')}{_c(lang)}{run_result.status}, "
        f"{t(lang, 'turns')}{_c(lang)}{state.turns}"
    )
    print(f"--- {t(lang, 'answer')} ---")
    for paragraph in run_result.answer.split("\n"):
        print(
            textwrap.fill(
                paragraph, WIDTH, break_on_hyphens=False
            )
            or ""
        )
    print("---")
    checks = check_citations(
        run_result.answer, corpus, state.consulted
    )
    if checks:
        print(t(lang, "checks"))
        print(f"  {'':<20} {t(lang, 'cols')}")
    cols = t(lang, "cols").split()
    for check in checks:
        marks = [
            check.exists,
            check.consulted,
            check.excerpt,
            check.supported,
        ]
        cells = [
            f"{_mark(lang, m):<{len(c)}}"
            for m, c in zip(marks, cols, strict=True)
        ]
        print(f"  {check.ref:<20} " + " ".join(cells).rstrip())
    usage = state.usage
    note = ""
    if simulated:
        note = f" ({t(lang, 'estimated')})"
    print(
        f"{t(lang, 'tokens')}{_c(lang)}{usage.input_tokens}"
        f"/{usage.output_tokens}{note}"
    )
    cost = estimate_cost(model_name, usage)
    if cost is not None:
        print(f"{t(lang, 'cost')}{_c(lang)}{cost:.4f} USD")


if __name__ == "__main__":
    raise SystemExit(main())
