"""Step 05: a small persistent memory, written under control.

What it is: a JSON file of short, explicit entries (user
preferences, stable facts) that survives between sessions.
What it is not: the conversation history (one conversation),
the run state (one mission) or the documents (searched).

Rules enforced here, not in the prompt:
- every new entry is shown to the user and needs a "yes";
- a few obvious kinds of personal data are refused (e-mail,
  phone number, member number). This filter is LIMITED: it
  misses names, postal addresses, obfuscated addresses...
  (false negatives) and refuses some harmless numbers (false
  positives). It reduces risk; it does not detect all personal
  data. User confirmation remains necessary;
- short entries, a small maximum count, no duplicates;
- no angle brackets: an entry cannot fake the delimiter of
  the memory block in the system prompt;
- the file lives in workspace/memory/ and is replaced as a
  whole (see FileAccessPolicy.replace for what this
  guarantees and what it does not).

Memory goes into the system prompt AFTER the rules, inside a
<memory> block, as lower-priority data. This placement is a
request made to the model, not an enforcement: what must
never happen is refused by the code (tools, file policy),
whatever the memory says.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path

from assistant.policy import FileAccessPolicy

FILE_NAME = "memory.json"
KINDS = ("preference", "fact")
# [snippet:pii]
# Best-effort patterns, not a detector of all personal data.
PERSONAL_DATA = [
    re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),  # e-mail
    # phone: 10 digits or more (a date has only 8)
    re.compile(r"\+?(?:\d[ .-]?){9,14}\d"),
    re.compile(r"\bR-\d{4}\b"),  # Rivelune member number
]
# [/snippet]


class MemoryRefused(Exception):
    """Explained to the model as a tool error."""


@dataclass(frozen=True)
class MemoryEntry:
    id: str
    kind: str
    text: str
    created: str


class MemoryStore:
    def __init__(
        self,
        folder: Path,
        confirm: Callable[[str], bool],
        max_entries: int = 20,
        max_chars: int = 200,
        today: Callable[[], str] = lambda: (
            date.today().isoformat()
        ),
    ):
        self.folder = Path(folder)
        self.confirm = confirm
        self.max_entries = max_entries
        self.max_chars = max_chars
        self.today = today
        self._policy = FileAccessPolicy(
            read_roots=[self.folder], write_roots=[self.folder]
        )
        self._entries = self._load()

    def _load(self) -> list[MemoryEntry]:
        path = self.folder / FILE_NAME
        if not path.exists():
            return []
        raw = self._policy.check_read(path).read_text("utf-8")
        return [MemoryEntry(**e) for e in json.loads(raw)]

    def _save(self) -> None:
        data = [asdict(e) for e in self._entries]
        self._policy.replace(
            self.folder,
            FILE_NAME,
            json.dumps(data, ensure_ascii=False, indent=2),
        )

    @property
    def entries(self) -> list[MemoryEntry]:
        return list(self._entries)

    # [snippet:remember]
    def remember(self, kind: str, text: str) -> MemoryEntry:
        text = " ".join(text.split())
        if kind not in KINDS:
            raise MemoryRefused(f"kind must be one of {KINDS}")
        if not text or len(text) > self.max_chars:
            raise MemoryRefused(
                f"text must be 1 to {self.max_chars} characters"
            )
        if "<" in text or ">" in text:
            # Could fake the <memory> delimiter of the prompt.
            raise MemoryRefused("angle brackets not allowed")
        if any(p.search(text) for p in PERSONAL_DATA):
            raise MemoryRefused(
                "looks like personal data: refused"
            )
        if any(e.text == text for e in self._entries):
            raise MemoryRefused("already remembered")
        if len(self._entries) >= self.max_entries:
            raise MemoryRefused("memory full: forget an entry")

        if not self.confirm(f"[{kind}] {text}"):
            raise MemoryRefused("the user declined")

        entry = MemoryEntry(
            self._next_id(), kind, text, self.today()
        )
        self._entries.append(entry)
        self._save()
        return entry

    # [/snippet]

    def _next_id(self) -> str:
        used = [int(e.id[1:]) for e in self._entries]
        return f"m{max(used, default=0) + 1:03d}"

    def forget(self, entry_id: str) -> None:
        kept = [e for e in self._entries if e.id != entry_id]
        if len(kept) == len(self._entries):
            raise MemoryRefused(f"no memory entry '{entry_id}'")
        self._entries = kept
        self._save()

    # [snippet:as-context]
    def as_context(self) -> str:
        """Entries for the system prompt, clearly delimited."""
        if not self._entries:
            return "(empty)"
        return "\n".join(
            f"- [{e.id}] ({e.kind}, {e.created}) {e.text}"
            for e in self._entries
        )

    # [/snippet]
