# Code figé de l'expérience du chapitre 9

Copie octet pour octet des dix fichiers couverts par l'empreinte
de l'expérience (`8376d976b0fd296b`), tels qu'ils étaient lors
des manches réelles du 5 novembre 2026. Ne les modifiez pas : ils
servent de référence.

- `assistant.step09.frozen_code.historical_fingerprint()` recalcule
  l'empreinte sur cette copie ; elle doit rester `8376d976b0fd296b`.
- `assistant.step09.frozen_code.differences()` liste les fichiers
  distribués qui ne correspondent plus à cette copie. Dans cette
  édition, la liste est vide : le code distribué de ces fichiers
  est celui de l'expérience.

Différence avec la version pédagogique distribuée : le chapitre 4
ajoute un outil par `assistant/step04/extend.py` (`with_tools`), un
fichier nouveau qui n'existait pas lors de l'expérience et qu'elle
n'utilise pas. Les résultats publiés au chapitre 9 proviennent du
code figé, pas de ce fichier.
