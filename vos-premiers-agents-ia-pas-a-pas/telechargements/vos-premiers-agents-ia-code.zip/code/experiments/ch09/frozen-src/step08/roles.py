"""Step 08: three roles, each with one responsibility.

researcher  agent: read-only tools, stops when a brief is
            accepted, or at its limits;
writer      one model call, no tools, sees only the brief;
verifier    agent: read-only tools, sees the claims and the full
            cited passages, never the researcher's notes; stops
            when a review is accepted, or at its limits.
"""

from __future__ import annotations

import json

from pydantic import ValidationError

from assistant.corpus import Corpus
from assistant.prompts import load
from assistant.runstate import Limits
from assistant.step04.agent import new_state, run
from assistant.step04.tools import (
    Tool,
    Toolbox,
    ToolError,
    build_toolbox,
)
from assistant.step05.bm25 import bm25_search
from assistant.step05.citations import excerpt_in
from assistant.step08.contracts import (
    BRIEF_SCHEMA,
    DRAFT_SCHEMA,
    REVIEW_SCHEMA,
    Brief,
    Draft,
    Review,
)


class RoleFailure(Exception):
    def __init__(self, role: str, reason: str):
        super().__init__(f"{role}: {reason}")
        self.role, self.reason = role, reason


class _Submitted(Exception):
    """Ends a role's loop: its result has been accepted."""


# [snippet:evidence-problems]
def evidence_problems(
    brief: Brief, corpus: Corpus, consulted: dict[str, str]
) -> list[str]:
    """Checked BEFORE the brief leaves the researcher."""
    problems = []
    for item in brief.evidence:
        seen = consulted.get(item.ref)
        if corpus.passage(item.ref) is None:
            problems.append(f"{item.ref}: no such passage")
        elif seen is None:
            problems.append(f"{item.ref}: you did not read it")
        elif not excerpt_in(item.quote, seen):
            problems.append(f"{item.ref}: quote not in passage")
    return problems


# [/snippet]


def _submit_loop(
    model,
    system,
    task,
    corpus,
    consulted_state,
    name,
    describe,
    schema,
    params,
    handler,
):
    """A read-only agent that ends by submitting its result."""
    box = build_toolbox(
        corpus,
        None,
        consulted_state.consulted,
        search=bm25_search,
    )

    def submit(args):
        handler(args)  # raises ToolError if not acceptable
        raise _Submitted

    tool = Tool(name, describe, schema, params, submit)
    toolbox = Toolbox(
        list(box._tools.values()) + [tool],
        box.consulted,
        box.max_chars,
    )
    try:
        result = run(
            model, system, task, toolbox, consulted_state
        )
    except _Submitted:
        return None
    return result.status


# [snippet:research]
def research(
    model,
    question: str,
    corpus: Corpus,
    lang: str,
    today: str,
    limits: Limits | None = None,
) -> tuple[Brief, dict[str, str]]:
    state = new_state(limits)
    accepted: list[Brief] = []

    def handler(brief: Brief) -> None:
        problems = evidence_problems(
            brief, corpus, state.consulted
        )
        if problems:  # told to the model, which may correct
            raise ToolError("; ".join(problems))
        accepted.append(brief)

    status = _submit_loop(
        model,
        load("step08-researcher", lang, today=today),
        question,
        corpus,
        state,
        "submit_brief",
        "Hand over the passages found. This ends your work.",
        BRIEF_SCHEMA,
        Brief,
        handler,
    )
    if not accepted:  # ended, or stopped by a limit
        raise RoleFailure("researcher", f"no brief ({status})")
    return accepted[0], dict(state.consulted)


# [/snippet]


def _validated(reply, contract, role: str):
    if reply.stop_reason != "end_turn":
        raise RoleFailure(
            role, f"no result: {reply.stop_reason}"
        )
    try:
        return contract.model_validate_json(reply.text)
    except ValidationError as error:
        first = error.errors()[0]
        where = ".".join(str(x) for x in first["loc"])
        raise RoleFailure(
            role, f"{where}: {first['msg']}"
        ) from error


def writer_input(question: str, brief: Brief) -> str:
    """Minimal context: the question and the brief only."""
    data = json.dumps(
        brief.model_dump(), ensure_ascii=False, indent=1
    )
    return (
        f"<question>\n{question}\n</question>\n"
        f"<brief>\n{data}\n</brief>"
    )


# [snippet:write]
def write(
    model, question: str, brief: Brief, lang: str
) -> Draft:
    """One call, no tools. Its only source is the brief."""
    reply = model.complete_json(
        load("step08-writer", lang),
        [
            {
                "role": "user",
                "content": writer_input(question, brief),
            }
        ],
        DRAFT_SCHEMA,
    )
    return _validated(reply, Draft, "writer")


# [/snippet]


def verifier_input(
    question: str, draft: Draft, corpus: Corpus
) -> str:
    """The claims and the full passages, taken from the folder
    by the code: not the quotes chosen by the other roles."""
    parts = [f"<question>\n{question}\n</question>"]
    for i, claim in enumerate(draft.claims, start=1):
        refs = " ".join(claim.refs)
        parts.append(
            f'<claim n="{i}" refs="{refs}">\n'
            f"{claim.text}\n</claim>"
        )
    cited = dict.fromkeys(
        r for c in draft.claims for r in c.refs
    )
    for ref in cited:
        passage = corpus.passage(ref)
        if passage:
            parts.append(
                f'<passage ref="{ref}">\n'
                f"{passage.text}\n</passage>"
            )
    return "\n".join(parts)


def verify(
    model,
    question: str,
    draft: Draft,
    corpus: Corpus,
    lang: str,
    today: str,
    limits: Limits | None = None,
) -> Review:
    state = new_state(limits)
    accepted: list[Review] = []

    def handler(review: Review) -> None:
        wanted = set(range(1, len(draft.claims) + 1))
        given = [v.claim for v in review.verdicts]
        if sorted(given) != sorted(wanted):
            raise ToolError(
                "give exactly one verdict for claims "
                f"{sorted(wanted)}"
            )
        accepted.append(review)

    status = _submit_loop(
        model,
        load("step08-verifier", lang, today=today),
        verifier_input(question, draft, corpus),
        corpus,
        state,
        "submit_review",
        "Hand over one verdict per claim. This ends your work.",
        REVIEW_SCHEMA,
        Review,
        handler,
    )
    if not accepted:
        raise RoleFailure("verifier", f"no review ({status})")
    return accepted[0]
