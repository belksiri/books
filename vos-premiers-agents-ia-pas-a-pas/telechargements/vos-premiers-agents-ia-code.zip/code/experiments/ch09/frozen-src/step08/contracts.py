"""Step 08: what the roles hand to each other.

Same dual schema as before: the JSON schemas guide the model,
the Pydantic classes are what the code enforces.
"""

from __future__ import annotations

from pydantic import Field

from assistant.step04.tools import Strict

REF_PATTERN = r"^[a-z0-9][a-z0-9-]*#p\d{2}$"


# [snippet:contracts]
class Evidence(Strict):
    ref: str = Field(pattern=REF_PATTERN)
    quote: str = Field(min_length=1, max_length=300)
    note: str = Field(min_length=1, max_length=200)


class Brief(Strict):  # researcher -> writer
    # Empty if nothing useful exists: a valid result.
    evidence: list[Evidence] = Field(max_length=12)
    gaps: list[str] = Field(max_length=5)  # not found


class Claim(Strict):
    text: str = Field(min_length=1, max_length=400)
    refs: list[str] = Field(max_length=5)


class Draft(Strict):  # writer -> verifier
    # Empty: the brief does not allow an answer.
    claims: list[Claim] = Field(max_length=12)


class Verdict(Strict):
    claim: int = Field(ge=1)  # 1 = first claim
    supported: bool
    reason: str = Field(min_length=1, max_length=300)


class Review(Strict):  # verifier -> orchestrator
    verdicts: list[Verdict] = Field(min_length=1, max_length=12)


# [/snippet]


def _obj(properties: dict) -> dict:
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


_TEXT = {"type": "string"}
_TEXTS = {"type": "array", "items": _TEXT}

BRIEF_SCHEMA = _obj(
    {
        "evidence": {
            "type": "array",
            "items": _obj(
                {"ref": _TEXT, "quote": _TEXT, "note": _TEXT}
            ),
        },
        "gaps": _TEXTS,
    }
)
DRAFT_SCHEMA = _obj(
    {
        "claims": {
            "type": "array",
            "items": _obj({"text": _TEXT, "refs": _TEXTS}),
        }
    }
)
REVIEW_SCHEMA = _obj(
    {
        "verdicts": {
            "type": "array",
            "items": _obj(
                {
                    "claim": {"type": "integer"},
                    "supported": {"type": "boolean"},
                    "reason": _TEXT,
                }
            ),
        }
    }
)
