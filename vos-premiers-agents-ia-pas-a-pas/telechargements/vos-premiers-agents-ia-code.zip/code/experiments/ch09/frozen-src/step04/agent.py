"""Step 04: the agent loop, now able to call tools."""

from __future__ import annotations

from dataclasses import dataclass, field

from assistant.llm import ModelClient
from assistant.runstate import Limits, RunState
from assistant.step04.tools import Toolbox


@dataclass
class ToolRunState(RunState):
    # ref -> passage text as transmitted to the model
    consulted: dict[str, str] = field(default_factory=dict)
    tool_calls: int = 0

    def exceeded(self) -> str | None:
        if self.tool_calls >= self.limits.max_tool_calls:
            return "max_tool_calls"
        return super().exceeded()


@dataclass
class RunResult:
    status: str
    answer: str
    state: ToolRunState


# [snippet:loop-model]
def run(
    model: ModelClient,
    system: str,
    question: str,
    toolbox: Toolbox,
    state: ToolRunState,
) -> RunResult:
    messages = [{"role": "user", "content": question}]
    while True:
        reason = state.exceeded()
        if reason:
            return RunResult(reason, "", state)

        reply = model.complete(
            system, messages, toolbox.definitions()
        )
        state.turns += 1
        state.usage += reply.usage
        messages.append(
            {"role": "assistant", "content": reply.content}
        )

        if reply.stop_reason != "tool_use":
            status = (
                "done"
                if reply.stop_reason == "end_turn"
                else f"stopped:{reply.stop_reason}"
            )
            return RunResult(status, reply.text, state)
        # [/snippet]
        # [snippet:loop-tools]
        results = []
        for call in reply.tool_calls:
            # Checked before each tool, not during it.
            reason = state.exceeded()
            if reason:
                return RunResult(reason, "", state)
            outcome = toolbox.execute(call)
            state.tool_calls += 1
            state.log(_describe(call, outcome))
            results.append(outcome.as_block())
        # All results go back together, in one user message.
        messages.append({"role": "user", "content": results})


# [/snippet]


def _describe(call, outcome) -> str:
    args = ", ".join(
        f"{k}={v!r}" for k, v in call.input.items()
    )
    flag = "ERROR: " if outcome.is_error else ""
    first = outcome.content.splitlines()[0]
    return f"{call.name}({args})\n-> {flag}{first}"


def new_state(limits: Limits | None = None) -> ToolRunState:
    return ToolRunState(limits or Limits())
