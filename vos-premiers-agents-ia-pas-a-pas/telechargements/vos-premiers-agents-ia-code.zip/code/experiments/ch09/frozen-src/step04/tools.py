"""Step 04: tools the agent can call, and how they run safely.

Two layers, on purpose:
- `schema` is what the model sees (kept simple: the API's
  strict mode ignores bounds such as maxLength);
- `params` is a Pydantic model the code enforces before
  running anything.

Traceability: a tool that shows passages returns `Shown`. The
toolbox formats it, cuts it to the size limit, and only then
records in `consulted` what the model really received:
`consulted[ref]` is the passage text as transmitted, the whole
text or only its beginning when the passage was cut.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
)

from assistant.corpus import Corpus, Passage
from assistant.llm import ToolCall
from assistant.policy import AccessDenied, FileAccessPolicy
from assistant.text import tokenize

MAX_RESULT_CHARS = 6_000


class ToolError(Exception):
    """An expected failure, explained to the model."""


@dataclass(frozen=True)
class Shown:
    """Passages a tool wants to show, before any cut."""

    header: str
    passages: list[Passage]


# [snippet:tool-class]
@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    schema: dict  # what the model sees
    params: type[BaseModel]  # what the code enforces
    run: Callable[[BaseModel], str | Shown]

    def definition(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.schema,
            "strict": True,
        }


# [/snippet]


# [snippet:tool-outcome]
@dataclass(frozen=True)
class ToolOutcome:
    call_id: str
    content: str
    is_error: bool = False

    def as_block(self) -> dict:
        return {
            "type": "tool_result",
            "tool_use_id": self.call_id,
            "content": self.content,
            "is_error": self.is_error,
        }


# [/snippet]


class Toolbox:
    def __init__(
        self,
        tools: list[Tool],
        consulted: dict[str, str] | None = None,
        max_chars: int = MAX_RESULT_CHARS,
    ):
        self._tools = {t.name: t for t in tools}
        # ref -> passage text as transmitted to the model
        self.consulted = {} if consulted is None else consulted
        self.max_chars = max_chars

    def definitions(self) -> list[dict]:
        return [t.definition() for t in self._tools.values()]

    # [snippet:execute]
    def execute(self, call: ToolCall) -> ToolOutcome:
        """Expected failures become error results for the
        model; an unexpected exception (a bug) is raised."""
        tool = self._tools.get(call.name)
        if tool is None:
            return ToolOutcome(
                call.id, f"Unknown tool: {call.name}", True
            )

        try:
            args = tool.params.model_validate(call.input)
            result = tool.run(args)
        except ValidationError as error:
            return ToolOutcome(call.id, _explain(error), True)
        except (ToolError, AccessDenied) as error:
            return ToolOutcome(call.id, str(error), True)

        if isinstance(result, Shown):
            return ToolOutcome(call.id, self._show(result))
        if len(result) > self.max_chars:
            result = result[: self.max_chars] + "\n[truncated]"
        return ToolOutcome(call.id, result)

    # [/snippet]

    # [snippet:show]
    def _show(self, shown: Shown) -> str:
        """Cut to max_chars, then record what was sent."""
        lines = [shown.header] if shown.header else []
        used = sum(len(line) + 1 for line in lines)
        for i, passage in enumerate(shown.passages):
            prefix = f"[{passage.ref}] "
            room = self.max_chars - used - len(prefix)
            visible = passage.text[: max(room, 0)]
            if len(visible) < 20:  # not worth a stump
                visible = ""
            if visible:
                lines.append(prefix + visible)
                used += len(prefix) + len(visible) + 1
                self._record(passage.ref, visible)
            if visible != passage.text:
                left = len(shown.passages) - i
                lines.append(
                    f"[truncated: {left} passage(s) "
                    "cut or not shown]"
                )
                break
        return "\n".join(lines)

    def _record(self, ref: str, visible: str) -> None:
        # Never shrink: a passage once seen whole stays whole.
        if len(visible) > len(self.consulted.get(ref, "")):
            self.consulted[ref] = visible

    # [/snippet]


def _explain(error: ValidationError) -> str:
    problems = [
        f"{'.'.join(map(str, e['loc'])) or 'input'}: {e['msg']}"
        for e in error.errors()
    ]
    return "Invalid input. " + "; ".join(problems)


# ---- Parameters enforced by the code ----


class Strict(BaseModel):
    # No silent conversion: "5" is not accepted for 5.
    model_config = ConfigDict(extra="forbid", strict=True)


class NoParams(Strict):
    pass


# [snippet:search-params]
class SearchParams(Strict):
    query: str = Field(min_length=2, max_length=200)
    max_results: int = Field(default=5, ge=1, le=10)


# [/snippet]


class ReadParams(Strict):
    doc_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{0,39}$")


class NoteParams(Strict):
    name: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{0,59}\.md$")
    content: str = Field(min_length=1, max_length=8_000)


# ---- Tool functions ----


# [snippet:search-simple]
def simple_search(
    corpus: Corpus, query: str, k: int
) -> list[Passage]:
    """Rank passages by how many query words they contain."""
    words = set(tokenize(query, corpus.lang))
    scored = []
    for passage in corpus.all_passages():
        found = words & set(tokenize(passage.text, corpus.lang))
        if found:
            scored.append((len(found), passage))
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [passage for _, passage in scored[:k]]


# [/snippet]


# [snippet:search-schema]
SEARCH_SCHEMA = {
    "type": "object",
    "properties": {
        "query": {
            "type": "string",
            "description": "Keywords, not a sentence.",
        },
        "max_results": {
            "type": "integer",
            "description": "1 to 10, default 5.",
        },
    },
    "required": ["query"],
    "additionalProperties": False,
}
# [/snippet]

READ_SCHEMA = {
    "type": "object",
    "properties": {"doc_id": {"type": "string"}},
    "required": ["doc_id"],
    "additionalProperties": False,
}

NOTE_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "content": {"type": "string"},
    },
    "required": ["name", "content"],
    "additionalProperties": False,
}

EMPTY_SCHEMA = {
    "type": "object",
    "properties": {},
    "additionalProperties": False,
}

DESCRIPTIONS = {
    "list_documents": (
        "List the available documents with their id, title,"
        " date and status."
    ),
    "search_documents": (
        "Search passages containing the words of the query."
        " Returns passages with their reference doc_id#pNN."
    ),
    "read_document": (
        "Read a whole document by its id (see list_documents)."
        " Returns its header and all its passages."
    ),
    "save_note": (
        "Save a new Markdown note in the workspace. Name:"
        " lowercase letters, digits, dashes, ending in .md."
        " Existing notes cannot be overwritten."
    ),
}

Search = Callable[[Corpus, str, int], list[Passage]]


def build_toolbox(
    corpus: Corpus,
    notes_dir: Path | None,
    consulted: dict[str, str],
    search: Search = simple_search,
    max_chars: int = MAX_RESULT_CHARS,
) -> Toolbox:
    """Create the tools; `consulted` records passages shown.

    With `notes_dir=None` the toolbox is read-only: no tool can
    change anything, so replaying a step has no side effect.
    """
    policy = FileAccessPolicy(
        [], write_roots=[notes_dir] if notes_dir else []
    )

    def list_documents(_: NoParams) -> str:
        return "\n".join(
            f"{d.id} | {d.title} | date: {d.meta.get('date')}"
            f" | status: {d.meta.get('status')}"
            for d in corpus.documents
        )

    # [snippet:search-tool]
    def search_documents(args: SearchParams) -> str | Shown:
        hits = search(corpus, args.query, args.max_results)
        if not hits:
            return "No passage matches these words."
        return Shown("", hits)

    # [/snippet]

    # [snippet:read-tool]
    def read_document(args: ReadParams) -> Shown:
        doc = corpus.get(args.doc_id)
        if doc is None:
            raise ToolError(
                f"No document '{args.doc_id}'. Call"
                " list_documents to see valid ids."
            )
        header = " | ".join(
            f"{k}: {v}" for k, v in doc.meta.items()
        )
        return Shown(header, list(doc.passages))

    # [/snippet]

    def save_note(args: NoteParams) -> str:
        path = policy.write_new(
            notes_dir, args.name, args.content
        )
        return f"Note saved: workspace/notes/{path.name}"

    specs = [
        (
            "list_documents",
            EMPTY_SCHEMA,
            NoParams,
            list_documents,
        ),
        (
            "search_documents",
            SEARCH_SCHEMA,
            SearchParams,
            search_documents,
        ),
        (
            "read_document",
            READ_SCHEMA,
            ReadParams,
            read_document,
        ),
    ]
    if notes_dir is not None:
        specs.append(
            ("save_note", NOTE_SCHEMA, NoteParams, save_note)
        )
    return Toolbox(
        [
            Tool(name, DESCRIPTIONS[name], schema, params, run)
            for name, schema, params, run in specs
        ],
        consulted,
        max_chars,
    )
