"""Step 05: BM25 lexical ranking, kept short on purpose.

BM25 scores a passage higher when it contains rare query
words, several times, in a passage that is not too long.
It is still lexical: no synonyms, no meaning.
"""

from __future__ import annotations

import math
from collections import Counter

from assistant.corpus import Corpus, Passage
from assistant.text import tokenize


# [snippet:bm25]
def bm25_scores(
    query: list[str],
    docs: list[list[str]],
    k1: float = 1.5,
    b: float = 0.75,
) -> list[float]:
    n = len(docs)
    avg_len = sum(map(len, docs)) / n
    df = Counter(word for doc in docs for word in set(doc))
    scores = []
    for doc in docs:
        tf, score = Counter(doc), 0.0
        for word in set(query):
            if word not in tf:
                continue
            idf = math.log(
                1 + (n - df[word] + 0.5) / (df[word] + 0.5)
            )
            norm = k1 * (1 - b + b * len(doc) / avg_len)
            score += (
                idf * tf[word] * (k1 + 1) / (tf[word] + norm)
            )
        scores.append(score)
    return scores


# [/snippet]


def bm25_search(
    corpus: Corpus, query: str, k: int
) -> list[Passage]:
    passages = corpus.all_passages()
    docs = [tokenize(p.text, corpus.lang) for p in passages]
    scores = bm25_scores(tokenize(query, corpus.lang), docs)
    order = sorted(
        range(len(passages)), key=lambda i: -scores[i]
    )
    return [passages[i] for i in order[:k] if scores[i] > 0]
