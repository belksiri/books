"""The two architectures, under the same limits.

Same model, same read-only tools, same documents, same limits
per run. A run ends with a `kind`, so that nothing is lost:
complete    an answer was delivered;
incomplete  a limit, a cut reply, a refused hand-over;
refusal     the model refused;
api_error   the service failed.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from assistant.budget import BudgetStop, CapReached
from assistant.corpus import Corpus
from assistant.llm import ModelError
from assistant.prompts import load
from assistant.runstate import Limits
from assistant.step04.agent import new_state, run
from assistant.step04.tools import build_toolbox
from assistant.step05.bm25 import bm25_search
from assistant.step08.contracts import (
    DRAFT_SCHEMA,
    Brief,
    Draft,
    Review,
)
from assistant.step08.orchestrator import (
    RoleModel,
    TeamBudget,
    draft_problems,
)
from assistant.step08.roles import (
    RoleFailure,
    _validated,
    research,
    verify,
    write,
    writer_input,
)

MAX_REVISIONS = 1
ARCHITECTURES = ("agent", "team")
RESERVES = "Réserves du vérificateur"


@dataclass(frozen=True)
class RunLimits:
    """One shared constraint of resources, per run. It does not
    make the architectures equivalent: the team has more steps
    to fit in. Fixed in experiments/ch09/config.json."""

    max_calls: int = 10
    max_tokens: int = 60_000
    max_seconds: float = 300.0

    def loop(self) -> Limits:
        return Limits(
            max_turns=self.max_calls,
            max_seconds=self.max_seconds,
            max_tokens=self.max_tokens,
        )


DEFAULT_LIMITS = RunLimits()


@dataclass
class Outcome:
    kind: str = "incomplete"
    status: str = ""
    answer: str = ""  # the common final answer
    consulted: dict[str, str] = field(default_factory=dict)
    objections: list[str] = field(default_factory=list)
    revisions: int = 0
    calls_by_role: dict[str, int] = field(default_factory=dict)
    tokens_by_role: dict[str, int] = field(default_factory=dict)

    @property
    def full_output(self) -> str:
        """As the user would see it, reservations included."""
        if not self.objections:
            return self.answer
        notes = "\n".join(f"- {o}" for o in self.objections)
        return f"{self.answer}\n\n{RESERVES}\n{notes}"


def _budget(limits: RunLimits) -> TeamBudget:
    return TeamBudget(limits.max_calls, limits.max_tokens)


def _failure_kind(error: ModelError) -> str:
    if isinstance(error, BudgetStop):
        return "incomplete"
    if "team budget" in str(error):
        return "incomplete"
    return "api_error"


def _status_kind(status: str) -> str:
    if status.startswith("done"):
        return "complete"
    return "refusal" if "refusal" in status else "incomplete"


def single_agent(
    model,
    question: str,
    corpus: Corpus,
    today: str,
    limits: RunLimits = DEFAULT_LIMITS,
) -> Outcome:
    budget = _budget(limits)
    out = Outcome(
        calls_by_role=budget.calls, tokens_by_role=budget.tokens
    )
    state = new_state(limits.loop())
    toolbox = build_toolbox(
        corpus, None, state.consulted, search=bm25_search
    )
    try:
        result = run(
            RoleModel(model, budget, "agent"),
            load("step04", "fr", today=today),
            question,
            toolbox,
            state,
        )
        out.status = result.status
        out.kind = _status_kind(result.status)
        out.answer = (
            result.answer if out.kind == "complete" else ""
        )
    except CapReached:
        raise  # nothing more may run: the round stops
    except ModelError as error:
        out.status, out.kind = str(error), _failure_kind(error)
    out.consulted = dict(state.consulted)
    return out


# [snippet:revise]
def revise(
    model, question: str, brief: Brief, draft: Draft, notes
) -> Draft:
    """One new call: the same writer, told the objections."""
    objections = "\n".join(f"- {note}" for note in notes)
    claims = "\n".join(f"- {c.text}" for c in draft.claims)
    content = (
        f"{writer_input(question, brief)}\n"
        f"<previous_claims>\n{claims}\n</previous_claims>\n"
        f"<objections>\n{objections}\n</objections>"
    )
    reply = model.complete_json(
        load("step08-writer", "fr"),
        [{"role": "user", "content": content}],
        DRAFT_SCHEMA,
    )
    return _validated(reply, Draft, "writer")


# [/snippet]


def _objections(draft: Draft, review: Review) -> list[str]:
    return [
        f"{draft.claims[v.claim - 1].text} : {v.reason}"
        for v in review.verdicts
        if not v.supported
    ]


def answer_text(brief: Brief, draft: Draft) -> str:
    """Written by the code, in the format of the single agent,
    so that one checker reads both."""
    lines = [
        f"- {c.text} " + " ".join(f"[{r}]" for r in c.refs)
        for c in draft.claims
    ]
    used = {r for c in draft.claims for r in c.refs}
    lines += ["", "Sources"]
    lines += [
        f"- [{e.ref}] « {e.quote} »"
        for e in brief.evidence
        if e.ref in used
    ]
    return "\n".join(lines)


def _not_found(brief: Brief) -> str:
    lines = ["Les documents ne permettent pas de répondre."]
    lines += [f"- {gap}" for gap in brief.gaps]
    return "\n".join(lines)


def team(
    model,
    question: str,
    corpus: Corpus,
    today: str,
    limits: RunLimits = DEFAULT_LIMITS,
) -> Outcome:
    """Researcher, writer, verifier; at most one revision."""
    budget = _budget(limits)
    out = Outcome(
        calls_by_role=budget.calls, tokens_by_role=budget.tokens
    )

    def role(name: str) -> RoleModel:
        if hasattr(model, "new_conversation"):
            model.new_conversation()
        return RoleModel(model, budget, name)

    brief, draft, delivered = None, None, False
    try:
        brief, out.consulted = research(
            role("researcher"),
            question,
            corpus,
            "fr",
            today,
            limits.loop(),
        )
        draft = (
            write(role("writer"), question, brief, "fr")
            if brief.evidence
            else Draft(claims=[])
        )
        if not draft.claims:
            out.status, out.kind = "no_answer", "complete"
            out.answer = _not_found(brief)
            return out
        problems = draft_problems(draft, brief)
        if problems:
            out.status = "draft_refused: " + "; ".join(problems)
            return out
        review = verify(
            role("verifier"),
            question,
            draft,
            corpus,
            "fr",
            today,
            limits.loop(),
        )
        delivered = True
        out.objections = _objections(draft, review)
        out.status = (
            "done_with_objections" if out.objections else "done"
        )
        out.kind = "complete"
        if out.objections and MAX_REVISIONS:
            draft = _revision(
                role,
                question,
                brief,
                draft,
                corpus,
                today,
                out,
                limits,
            )
        out.answer = answer_text(brief, draft)
    except (ModelError, RoleFailure) as error:
        if delivered:  # the reviewed draft is kept
            out.answer = answer_text(brief, draft)
            out.status += f"; revision stopped: {error}"
        elif isinstance(error, CapReached):
            raise
        elif isinstance(error, ModelError):
            out.status = str(error)
            out.kind = _failure_kind(error)
        else:
            out.status = f"failed:{error.role}: {error.reason}"
            out.kind = _status_kind(error.reason)
    return out


# [snippet:revision]
def _revision(
    role, question, brief, draft, corpus, today, out, limits
) -> Draft:
    """A revised draft replaces the first only if it passes
    the code's checks AND is reviewed. Otherwise the first one
    stays, with its objections."""
    out.revisions += 1
    new = revise(
        role("writer"), question, brief, draft, out.objections
    )
    if not new.claims or draft_problems(new, brief):
        out.status += "; revision refused"
        return draft
    review = verify(
        role("verifier"),
        question,
        new,
        corpus,
        "fr",
        today,
        limits.loop(),
    )
    out.objections = _objections(new, review)
    out.status = (
        "done_with_objections" if out.objections else "done"
    )
    return new


# [/snippet]


def limit_reached(status: str) -> str | None:
    """Which limit ended this run, for the report."""
    for marker, name in (
        ("max_turns", "calls"),
        ("call cap", "calls"),
        ("team budget", "calls_or_tokens"),
        ("token_budget", "tokens"),
        ("max_seconds", "seconds"),
        ("max_tool_calls", "tool_calls"),
        ("may exceed", "input"),
    ):
        if marker in status:
            return name
    return None


RUNNERS = {"agent": single_agent, "team": team}
