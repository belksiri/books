# Licence du dossier de démonstration (proposée, non publiée)

Les documents de `demo_data/` (FR, EN, ES, DE) décrivent un organisme
fictif, « Rivelune ». Toutes les personnes, entreprises, lieux et coordonnées
sont inventés ; les adresses utilisent le domaine réservé `example.org`.
Leur origine est décrite dans `PROVENANCE.md`.

Licence proposée : Creative Commons Attribution 4.0 International
(CC BY 4.0), https://creativecommons.org/licenses/by/4.0/ — attribution :
« Belk Siri, *Vos premiers agents IA, pas à pas*, dossier de démonstration
Rivelune ».

Portée : cette licence est accordée **dans la seule mesure des droits que
l'auteur détient** sur ces textes. Elle ne prétend accorder aucun droit
inexistant ou appartenant à un tiers. Voir le point à trancher dans
`PROVENANCE.md` avant publication.

Ces documents sont exclus de la licence MIT du code.
