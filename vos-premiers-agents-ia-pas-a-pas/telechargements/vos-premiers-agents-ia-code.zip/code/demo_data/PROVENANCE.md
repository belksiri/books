# Origine du dossier de démonstration Rivelune

Document établi le 2026-10-31, complété le 2026-11-05, avant l'application de
toute licence.

## Ce qui a été produit, comment et quand

| Langue | Fichiers | Rédaction |
|---|---|---|
| FR | 10 documents, 40 passages | 2026-10-31, rédigés par l'assistant IA de programmation (Claude, Anthropic) travaillant pour l'auteur, Belk Siri, d'après le cahier des charges de l'auteur (cadrage validé : organisme fictif, contradictions tarifaires datées, injection de prompt, données personnelles synthétiques) |
| DE, EN, ES | mêmes documents, mêmes identifiants | 2026-10-31, traductions du français par le même assistant |

- **Aucune source extérieure** n'a été copiée, adaptée ni consultée pour
  rédiger ces textes, selon cette déclaration. Ils n'ont pas été tirés de
  documents réels d'une coopérative, d'une entreprise ou d'une administration.
  Le projet ne conserve aucune autre trace de la rédaction ; un échantillonnage
  est décrit dans `docs/inventaire-rivelune.md`, § 5.
- **Éléments fictifs** : la coopérative « Rivelune », la localité
  « Val-Ondine », toutes les personnes
  (Camille Ferrand, Yanis Roux, Léa Garnier, Inès Morvan) et tous les numéros
  d'adhérent.
- **Adresses électroniques** : domaine `example.org`, réservé à la
  documentation (RFC 2606), donc sans destinataire réel.
- **Éléments génériques** non propres à une source : grilles tarifaires,
  procédure de remboursement, consignes de sécurité, niveaux d'alerte
  météorologique « orange » et « rouge » (vocabulaire courant).

## Vérifications faites et non faites

- Fait : relecture de la cohérence interne, tests automatiques (identifiants
  identiques dans les quatre langues, adresses limitées à `example.org`).
- **Non fait** : recherche d'homonymie des noms fictifs (personnes,
  entreprise, localité) dans des registres de marques. Le 2026-11-05, seule
  une interrogation de l'annuaire public des entreprises a porté sur les noms
  d'organismes (`docs/inventaire-rivelune.md`, § 5).
  Une coïncidence avec une personne ou une entité réelle reste possible ; à
  vérifier avant publication.

## Point à trancher avant d'appliquer CC BY 4.0

Une licence ne peut porter que sur les droits effectivement détenus. Ces
textes ont été rédigés avec un assistant IA, sur instructions de l'auteur.
Selon les juridictions, la protection par le droit d'auteur d'un texte
produit de cette manière, et la titularité de ces droits, peuvent être
incertaines ou dépendre de la contribution humaine (choix, consignes,
sélection, modifications). Conséquences :

1. la mention CC BY 4.0 est formulée « dans la mesure des droits détenus » ;
2. l'auteur relira, modifiera au besoin et validera ces textes, ce qui
   renforcera et documentera sa contribution ;
3. le statut définitif sera confirmé par l'auteur, avec un conseil juridique
   si nécessaire, avant toute publication.

Inventaire complet à examiner : `docs/inventaire-rivelune.md`. La copie figée de
`code/experiments/ch09/corpus/` a la même origine.

Rien n'a été publié.

## Modifications du 2026-11-05

- `remboursement#p03`, dans les quatre langues : barème réécrit (valeurs et formulation), parce que l'ancien était identique à celui d'un loueur réel, sans preuve d'emprunt.
- `fournisseurs#p01`, dans les quatre langues : le nom d'atelier inventé est remplacé par une désignation générique.

La déclaration ci-dessus dit comment les textes ont été produits. **Elle ne prouve pas l'absence d'emprunt**, et ces corrections ne constituent pas une validation juridique.
