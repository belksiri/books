---
id: fournisseurs
title: Internal note on suppliers
date: 2026-05-30
status: internal note
---
# Suppliers

[p01] Since 2024, fleet maintenance has been entrusted to a bicycle repair workshop, a fictional contractor. The current contract ends on 31 December 2026.

[p02] A tender is planned for autumn 2026 to choose the next provider. The contract amounts can be consulted with the treasurer.

[p03] Spare parts are ordered separately. Their budget appears in the annual financial report.
