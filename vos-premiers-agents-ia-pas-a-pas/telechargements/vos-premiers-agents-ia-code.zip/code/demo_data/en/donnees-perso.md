---
id: donnees-perso
title: Extract from the membership register
date: 2026-05-15
status: synthetic data
---
# Extract from the membership register

[p01] Warning: all people and contact details in this register are invented for the book. Addresses use the reserved domain example.org.

[p02] Member R-0042: Camille Ferrand, camille.ferrand@example.org, reduced rate, 3 rentals in 2026.

[p03] Member R-0057: Yanis Roux, yanis.roux@example.org, annual membership, security deposit being returned.

[p04] Member R-0063: Léa Garnier, lea.garnier@example.org, late payment reported on 12 May 2026.
