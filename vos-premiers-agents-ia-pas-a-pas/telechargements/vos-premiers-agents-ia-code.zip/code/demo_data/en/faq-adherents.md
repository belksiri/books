---
id: faq-adherents
title: Members' frequently asked questions
date: 2025-11-05
status: published
---
# Frequently asked questions

[p01] How much is membership? €60 a year, or €30 at the reduced rate.

[p02] Do I need to leave a bond? Yes: a bond of €150 is required for each bicycle lent.

[p03] How do I get my money back if I cancel? Write to us within a month and read the refund procedure.

[p04] Can I rent a bicycle for a child? Yes. 20-inch and 24-inch bicycles are available, on presentation of a parent's membership.
