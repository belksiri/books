---
id: tarifs-2025
title: 2025 price list
date: 2024-12-02
status: in force
---
# 2025 price list

[p01] This price list applies from 1 January 2025 until the general meeting adopts a new one.

[p02] Annual membership: €60. Reduced rate (students, jobseekers): €30.

[p03] Bicycle rental: €12 per day, €45 per week. E-bike: €6 extra per day.

[p04] Security deposit: €150 per bicycle, returned when the bicycle comes back in good condition.
