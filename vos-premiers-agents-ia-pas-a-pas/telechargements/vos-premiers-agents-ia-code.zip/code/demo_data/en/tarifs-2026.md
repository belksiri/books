---
id: tarifs-2026
title: 2026 price list (draft)
date: 2026-02-10
status: draft submitted to the general meeting
---
# 2026 price list — draft

[p01] Draft price list to be voted on at the general meeting of March 2026. Once adopted, it replaces the 2025 price list.

[p02] Annual membership: €72. Reduced rate (students, jobseekers): €30, unchanged.

[p03] Bicycle rental: €14 per day, €52 per week. E-bike: €7 extra per day.

[p04] Security deposit: €200 per bicycle, at the request of our insurer.
