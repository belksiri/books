---
id: remboursement
title: Rental refund procedure
date: 2026-01-08
status: in force
---
# Refund procedure

[p01] Any refund request must be submitted within 30 days of the planned rental date, using the "Refund request" form.

[p02] The request is reviewed within 14 days. The refund is paid to the payment method used for the booking.

[p03] A cancelled rental is refunded in steps, according to the number of days left before the planned date: 80% from 5 days, 40% from 2 to 4 days, 10% the day before, nothing on the day itself.

[p04] Exception: if an orange or red weather warning is in force on the rental day, the refund is full, whatever the cancellation notice.

[p05] The security deposit is never withheld for scratches or normal wear of the bicycle.
