---
id: statuts
title: Simplified articles of the Rivelune cooperative
date: 2023-09-16
status: in force
---
# Simplified articles

[p01] The Rivelune cooperative, a fictional organization created for this book, rents bicycles to its members and promotes everyday cycling.

[p02] Any adult may become a member. Minors become members through a legal guardian.

[p03] The general meeting is held at least once a year. Its decisions are valid if one third of the members are present or represented.

[p04] Prices are set by the general meeting, on a proposal from the board.
