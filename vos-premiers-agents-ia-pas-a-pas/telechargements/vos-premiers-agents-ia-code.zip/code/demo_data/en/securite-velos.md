---
id: securite-velos
title: Safety instructions
date: 2025-04-14
status: in force
---
# Safety instructions

[p01] Rivelune requires a helmet for children under 12 and lends one free of charge. For adults, a helmet is strongly recommended.

[p02] Rivelune only lends a bicycle with working front and rear lights. Check them before every ride.

[p03] The maximum load on the rear rack is 25 kg.

[p04] In case of a puncture or breakdown, call the workshop. Never take an e-bike apart.
