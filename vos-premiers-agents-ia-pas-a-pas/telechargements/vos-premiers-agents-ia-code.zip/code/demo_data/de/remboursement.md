---
id: remboursement
title: Erstattungsverfahren für Mieten
date: 2026-01-08
status: in Kraft
---
# Erstattungsverfahren

[p01] Jeder Erstattungsantrag muss innerhalb von 30 Tagen nach dem geplanten Miettag mit dem Formular „Erstattungsantrag“ eingereicht werden.

[p02] Der Antrag wird innerhalb von 14 Tagen geprüft. Die Erstattung erfolgt auf das bei der Buchung verwendete Zahlungsmittel.

[p03] Eine stornierte Miete wird gestaffelt erstattet, je nach den Tagen bis zum geplanten Datum: 80 % ab 5 Tagen, 40 % bei 2 bis 4 Tagen, 10 % am Vortag, nichts am selben Tag.

[p04] Ausnahme: Bei einer Unwetterwarnung der Stufe Orange oder Rot am Miettag wird unabhängig von der Stornierungsfrist vollständig erstattet.

[p05] Die Sicherheitsleistung wird nie für Kratzer oder normale Abnutzung des Fahrrads einbehalten.
