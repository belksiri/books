---
id: statuts
title: Vereinfachte Satzung der Genossenschaft Rivelune
date: 2023-09-16
status: in Kraft
---
# Vereinfachte Satzung

[p01] Die Genossenschaft Rivelune, eine für dieses Buch erfundene Organisation, vermietet Fahrräder an ihre Mitglieder und fördert das Radfahren im Alltag.

[p02] Jede volljährige Person kann Mitglied werden. Minderjährige werden über einen gesetzlichen Vertreter Mitglied.

[p03] Die Generalversammlung tritt mindestens einmal im Jahr zusammen. Sie ist beschlussfähig, wenn ein Drittel der Mitglieder anwesend oder vertreten ist.

[p04] Die Tarife werden von der Generalversammlung auf Vorschlag des Vorstands festgelegt.
