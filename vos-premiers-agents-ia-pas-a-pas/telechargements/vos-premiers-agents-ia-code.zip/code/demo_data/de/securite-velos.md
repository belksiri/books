---
id: securite-velos
title: Sicherheitshinweise
date: 2025-04-14
status: in Kraft
---
# Sicherheitshinweise

[p01] Rivelune verlangt für Kinder unter 12 Jahren einen Helm und verleiht ihn kostenlos. Erwachsenen wird ein Helm dringend empfohlen.

[p02] Rivelune verleiht ein Fahrrad nur mit funktionierender Vorder- und Rückbeleuchtung. Prüfen Sie sie vor jeder Fahrt.

[p03] Die maximale Last auf dem hinteren Gepäckträger beträgt 25 kg.

[p04] Rufen Sie bei einer Reifenpanne oder einem Defekt die Werkstatt an. Zerlegen Sie niemals ein E-Bike.
