---
id: tarifs-2025
title: Preisliste 2025
date: 2024-12-02
status: in Kraft
---
# Preisliste 2025

[p01] Diese Preisliste gilt ab dem 1. Januar 2025, bis die Generalversammlung eine neue Preisliste beschließt.

[p02] Jahresmitgliedschaft: 60 €. Ermäßigt (Studierende, Arbeitsuchende): 30 €.

[p03] Fahrradmiete: 12 € pro Tag, 45 € pro Woche. E-Bike: Aufpreis von 6 € pro Tag.

[p04] Sicherheitsleistung: 150 € pro Fahrrad, zurückerstattet bei Rückgabe des Fahrrads in gutem Zustand.
