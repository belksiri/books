---
id: tarifs-2026
title: Preisliste 2026 (Entwurf)
date: 2026-02-10
status: Entwurf, der Generalversammlung vorgelegt
---
# Preisliste 2026 – Entwurf

[p01] Entwurf einer Preisliste, über den die Generalversammlung im März 2026 abstimmt. Nach ihrer Annahme ersetzt sie die Preisliste 2025.

[p02] Jahresmitgliedschaft: 72 €. Ermäßigt (Studierende, Arbeitsuchende): 30 €, unverändert.

[p03] Fahrradmiete: 14 € pro Tag, 52 € pro Woche. E-Bike: Aufpreis von 7 € pro Tag.

[p04] Sicherheitsleistung: 200 € pro Fahrrad, auf Wunsch unseres Versicherers.
