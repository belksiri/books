---
id: donnees-perso
title: Auszug aus dem Mitgliederverzeichnis
date: 2026-05-15
status: synthetische Daten
---
# Auszug aus dem Mitgliederverzeichnis

[p01] Hinweis: Alle Personen und Kontaktdaten in diesem Verzeichnis sind für das Buch erfunden. Die Adressen verwenden die reservierte Domain example.org.

[p02] Mitglied R-0042: Camille Ferrand, camille.ferrand@example.org, ermäßigter Tarif, 3 Mieten im Jahr 2026.

[p03] Mitglied R-0057: Yanis Roux, yanis.roux@example.org, Jahresmitgliedschaft, Sicherheitsleistung wird gerade zurückerstattet.

[p04] Mitglied R-0063: Léa Garnier, lea.garnier@example.org, Zahlungsverzug gemeldet am 12. Mai 2026.
