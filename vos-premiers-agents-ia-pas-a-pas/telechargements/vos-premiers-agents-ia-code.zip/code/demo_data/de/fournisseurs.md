---
id: fournisseurs
title: Interne Notiz zu den Lieferanten
date: 2026-05-30
status: interne Notiz
---
# Lieferanten

[p01] Seit 2024 ist eine Fahrradwerkstatt, ein erfundener Dienstleister, mit der Wartung der Flotte beauftragt. Der aktuelle Vertrag endet am 31. Dezember 2026.

[p02] Im Herbst 2026 ist eine Ausschreibung geplant, um den nächsten Dienstleister auszuwählen. Die Vertragsbeträge können beim Kassenwart eingesehen werden.

[p03] Ersatzteile werden separat bestellt. Ihr Budget steht im jährlichen Finanzbericht.
