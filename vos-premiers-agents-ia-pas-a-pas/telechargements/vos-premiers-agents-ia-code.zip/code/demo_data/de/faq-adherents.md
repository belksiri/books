---
id: faq-adherents
title: Häufige Fragen der Mitglieder
date: 2025-11-05
status: veröffentlicht
---
# Häufige Fragen

[p01] Was kostet die Mitgliedschaft? 60 € pro Jahr oder 30 € ermäßigt.

[p02] Muss ich eine Kaution hinterlegen? Ja: Für jedes verliehene Fahrrad wird eine Kaution von 150 € verlangt.

[p03] Wie bekomme ich mein Geld zurück, wenn ich storniere? Schreiben Sie uns innerhalb eines Monats und lesen Sie das Erstattungsverfahren.

[p04] Kann ich ein Fahrrad für ein Kind mieten? Ja. Fahrräder mit 20 und 24 Zoll sind verfügbar, gegen Vorlage der Mitgliedschaft eines Elternteils.
