---
id: fournisseurs
title: Nota interna sobre los proveedores
date: 2026-05-30
status: nota interna
---
# Proveedores

[p01] Desde 2024, el mantenimiento de la flota está a cargo de un taller de reparación de bicicletas, un proveedor ficticio. El contrato actual termina el 31 de diciembre de 2026.

[p02] En otoño de 2026 está prevista una licitación para elegir al siguiente proveedor. Los importes del contrato pueden consultarse con el tesorero.

[p03] Las piezas de repuesto se piden por separado. Su presupuesto figura en el informe financiero anual.
