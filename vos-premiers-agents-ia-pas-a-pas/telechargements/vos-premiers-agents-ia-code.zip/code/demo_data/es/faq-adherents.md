---
id: faq-adherents
title: Preguntas frecuentes de los socios
date: 2025-11-05
status: publicado
---
# Preguntas frecuentes

[p01] ¿Cuánto cuesta hacerse socio? 60 € al año, o 30 € con la tarifa reducida.

[p02] ¿Hay que dejar una fianza? Sí: se pide una fianza de 150 € por cada bicicleta prestada.

[p03] ¿Cómo recupero mi dinero si cancelo? Escríbenos en el plazo de un mes y consulta el procedimiento de reembolso.

[p04] ¿Puedo alquilar una bicicleta para un niño? Sí. Hay bicicletas de 20 y 24 pulgadas, presentando la cuota de socio de uno de los padres.
