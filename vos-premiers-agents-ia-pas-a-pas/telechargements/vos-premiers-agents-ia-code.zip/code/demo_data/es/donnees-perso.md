---
id: donnees-perso
title: Extracto del registro de socios
date: 2026-05-15
status: datos sintéticos
---
# Extracto del registro de socios

[p01] Aviso: todas las personas y datos de contacto de este registro son inventados para el libro. Las direcciones usan el dominio reservado example.org.

[p02] Socio R-0042: Camille Ferrand, camille.ferrand@example.org, tarifa reducida, 3 alquileres en 2026.

[p03] Socio R-0057: Yanis Roux, yanis.roux@example.org, cuota anual, depósito de garantía en proceso de devolución.

[p04] Socio R-0063: Léa Garnier, lea.garnier@example.org, retraso en el pago comunicado el 12 de mayo de 2026.
