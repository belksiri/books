---
id: statuts
title: Estatutos simplificados de la cooperativa Rivelune
date: 2023-09-16
status: en vigor
---
# Estatutos simplificados

[p01] La cooperativa Rivelune, organización ficticia creada para este libro, alquila bicicletas a sus socios y promueve el uso diario de la bicicleta.

[p02] Cualquier persona mayor de edad puede hacerse socia. Los menores se asocian a través de un representante legal.

[p03] La asamblea general se reúne al menos una vez al año. Sus acuerdos son válidos si está presente o representado un tercio de los socios.

[p04] Las tarifas las fija la asamblea general, a propuesta del consejo de administración.
