---
id: securite-velos
title: Normas de seguridad
date: 2025-04-14
status: en vigor
---
# Normas de seguridad

[p01] Rivelune exige el casco a los menores de 12 años y lo presta gratis. Para los adultos, el casco es muy recomendable.

[p02] Rivelune solo presta una bicicleta con luces delantera y trasera en buen estado. Compruébalas antes de cada salida.

[p03] La carga máxima en el portaequipajes trasero es de 25 kg.

[p04] En caso de pinchazo o avería, llama al taller. No desmontes nunca una bicicleta eléctrica.
