---
id: tarifs-2025
title: Tarifas 2025
date: 2024-12-02
status: en vigor
---
# Tarifas 2025

[p01] Estas tarifas se aplican desde el 1 de enero de 2025 hasta que la asamblea general apruebe otras nuevas.

[p02] Cuota anual de socio: 60 €. Tarifa reducida (estudiantes, personas desempleadas): 30 €.

[p03] Alquiler de bicicleta: 12 € por día, 45 € por semana. Bicicleta eléctrica: suplemento de 6 € por día.

[p04] Depósito de garantía: 150 € por bicicleta, que se devuelve cuando la bicicleta vuelve en buen estado.
