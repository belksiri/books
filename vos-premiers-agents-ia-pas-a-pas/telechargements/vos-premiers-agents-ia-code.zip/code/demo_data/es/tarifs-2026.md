---
id: tarifs-2026
title: Tarifas 2026 (proyecto)
date: 2026-02-10
status: proyecto presentado a la asamblea general
---
# Tarifas 2026 — proyecto

[p01] Proyecto de tarifas que se votará en la asamblea general de marzo de 2026. Una vez aprobado, sustituye a las tarifas de 2025.

[p02] Cuota anual de socio: 72 €. Tarifa reducida (estudiantes, personas desempleadas): 30 €, sin cambios.

[p03] Alquiler de bicicleta: 14 € por día, 52 € por semana. Bicicleta eléctrica: suplemento de 7 € por día.

[p04] Depósito de garantía: 200 € por bicicleta, a petición de nuestra aseguradora.
