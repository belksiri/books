---
id: remboursement
title: Procedimiento de reembolso de alquileres
date: 2026-01-08
status: en vigor
---
# Procedimiento de reembolso

[p01] Toda solicitud de reembolso debe presentarse en los 30 días siguientes a la fecha prevista del alquiler, con el formulario «Solicitud de reembolso».

[p02] La solicitud se examina en un plazo de 14 días. El reembolso se abona en el medio de pago utilizado en la reserva.

[p03] Un alquiler cancelado se reembolsa por tramos, según los días que faltan para la fecha prevista: 80 % a partir de 5 días, 40 % de 2 a 4 días, 10 % la víspera, nada el mismo día.

[p04] Excepción: si hay un aviso meteorológico naranja o rojo el día del alquiler, el reembolso es íntegro, sea cual sea el plazo de cancelación.

[p05] El depósito de garantía nunca se retiene por arañazos o por el desgaste normal de la bicicleta.
