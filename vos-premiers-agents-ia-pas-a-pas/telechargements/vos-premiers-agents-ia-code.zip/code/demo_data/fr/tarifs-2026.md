---
id: tarifs-2026
title: Grille tarifaire 2026 (projet)
date: 2026-02-10
status: projet soumis à l'assemblée générale
---
# Grille tarifaire 2026 — projet

[p01] Projet de grille soumis au vote de l'assemblée générale de mars 2026. Une fois adoptée, cette grille remplace la grille 2025.

[p02] Adhésion annuelle : 72 €. Tarif réduit (étudiants, demandeurs d'emploi) : 30 €, inchangé.

[p03] Location d'un vélo : 14 € la journée, 52 € la semaine. Vélo à assistance électrique : supplément de 7 € par jour.

[p04] Dépôt de garantie : 200 € par vélo, à la demande de notre assureur.
