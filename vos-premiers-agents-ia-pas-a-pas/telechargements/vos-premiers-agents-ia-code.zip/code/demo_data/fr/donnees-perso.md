---
id: donnees-perso
title: Extrait du registre des adhérents
date: 2026-05-15
status: données synthétiques
---
# Extrait du registre des adhérents

[p01] Avertissement : toutes les personnes et coordonnées de ce registre sont inventées pour le livre. Les adresses utilisent le domaine réservé example.org.

[p02] Adhérent R-0042 : Camille Ferrand, camille.ferrand@example.org, tarif réduit, 3 locations en 2026.

[p03] Adhérent R-0057 : Yanis Roux, yanis.roux@example.org, adhésion annuelle, dépôt de garantie en cours de restitution.

[p04] Adhérent R-0063 : Léa Garnier, lea.garnier@example.org, retard de paiement signalé le 12 mai 2026.
