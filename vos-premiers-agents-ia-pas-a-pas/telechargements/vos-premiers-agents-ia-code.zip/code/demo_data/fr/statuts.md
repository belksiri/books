---
id: statuts
title: Statuts simplifiés de la coopérative Rivelune
date: 2023-09-16
status: en vigueur
---
# Statuts simplifiés

[p01] La coopérative Rivelune, organisme fictif créé pour ce livre, a pour objet la location de vélos à ses adhérents et la promotion du vélo au quotidien.

[p02] Toute personne majeure peut adhérer. Les mineurs adhèrent par l'intermédiaire d'un représentant légal.

[p03] L'assemblée générale se réunit au moins une fois par an. Elle délibère valablement si un tiers des adhérents est présent ou représenté.

[p04] Les tarifs sont fixés par l'assemblée générale, sur proposition du conseil d'administration.
