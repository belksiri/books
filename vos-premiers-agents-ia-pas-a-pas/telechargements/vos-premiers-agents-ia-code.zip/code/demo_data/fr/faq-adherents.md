---
id: faq-adherents
title: Questions fréquentes des adhérents
date: 2025-11-05
status: publié
---
# Questions fréquentes

[p01] Combien coûte l'adhésion ? 60 € par an, ou 30 € au tarif réduit.

[p02] Faut-il laisser une caution ? Oui : une caution de 150 € est demandée pour chaque vélo prêté.

[p03] Comment récupérer mon argent si j'annule ? Écrivez-nous dans le mois qui suit et consultez la procédure de remboursement.

[p04] Peut-on louer un vélo pour un enfant ? Oui. Des vélos de 20 et 24 pouces sont disponibles, sur présentation de l'adhésion d'un parent.
