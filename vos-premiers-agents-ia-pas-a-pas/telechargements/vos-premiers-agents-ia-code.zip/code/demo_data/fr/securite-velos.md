---
id: securite-velos
title: Consignes de sécurité
date: 2025-04-14
status: en vigueur
---
# Consignes de sécurité

[p01] Rivelune exige le port du casque pour les enfants de moins de 12 ans et prête un casque gratuitement. Pour les adultes, il est fortement recommandé.

[p02] Rivelune ne prête un vélo qu'avec un éclairage avant et arrière en état de marche. Vérifiez-le avant chaque départ.

[p03] La charge maximale sur le porte-bagages arrière est de 25 kg.

[p04] En cas de crevaison ou de panne, appelez l'atelier. Ne démontez jamais un vélo à assistance électrique.
