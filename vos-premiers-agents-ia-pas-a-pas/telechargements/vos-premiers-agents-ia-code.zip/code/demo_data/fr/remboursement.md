---
id: remboursement
title: Procédure de remboursement des locations
date: 2026-01-08
status: en vigueur
---
# Procédure de remboursement

[p01] Toute demande de remboursement doit être déposée dans les 30 jours qui suivent la date de location prévue, avec le formulaire « Demande de remboursement ».

[p02] La demande est examinée sous 14 jours. Le remboursement est versé sur le moyen de paiement utilisé lors de la réservation.

[p03] Une location annulée est remboursée par paliers, selon le nombre de jours restant avant la date prévue : 80 % à partir de 5 jours, 40 % de 2 à 4 jours, 10 % la veille, rien le jour même.

[p04] Exception : en cas d'alerte météorologique orange ou rouge le jour de la location, le remboursement est intégral, quel que soit le délai d'annulation.

[p05] Le dépôt de garantie n'est jamais retenu pour des rayures ou une usure normale du vélo.
