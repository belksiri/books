---
id: fournisseurs
title: Note interne sur les fournisseurs
date: 2026-05-30
status: note interne
---
# Fournisseurs

[p01] Depuis 2024, l'entretien de la flotte est confié à un atelier de réparation de vélos, prestataire fictif. Le contrat actuel se termine le 31 décembre 2026.

[p02] Une consultation est prévue à l'automne 2026 pour choisir le prochain prestataire. Les montants du contrat peuvent être consultés auprès du trésorier.

[p03] Les pièces détachées sont commandées séparément. Leur budget figure dans le rapport financier annuel.
