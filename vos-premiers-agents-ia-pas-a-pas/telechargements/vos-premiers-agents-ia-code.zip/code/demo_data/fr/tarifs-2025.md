---
id: tarifs-2025
title: Grille tarifaire 2025
date: 2024-12-02
status: en vigueur
---
# Grille tarifaire 2025

[p01] Cette grille s'applique à partir du 1er janvier 2025, jusqu'à l'adoption d'une nouvelle grille par l'assemblée générale.

[p02] Adhésion annuelle : 60 €. Tarif réduit (étudiants, demandeurs d'emploi) : 30 €.

[p03] Location d'un vélo : 12 € la journée, 45 € la semaine. Vélo à assistance électrique : supplément de 6 € par jour.

[p04] Dépôt de garantie : 150 € par vélo, restitué au retour du vélo en bon état.
