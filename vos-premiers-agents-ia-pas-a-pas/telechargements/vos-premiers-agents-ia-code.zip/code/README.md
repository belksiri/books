# Code d'accompagnement — « Vos premiers agents IA, pas à pas »

Assistant documentaire de la coopérative fictive Rivelune, construit étape par
étape. Les identifiants du code et ses commentaires sont en anglais (socle
commun aux quatre éditions) ; les instructions système et les messages
affichés au lecteur existent en français, anglais, espagnol et allemand.

## Plateformes

| Plateforme | État |
|---|---|
| macOS 26 (Apple Silicon), Python 3.12.4, uv 0.12.10 | **testé** (tests simulés uniquement, voir plus bas) |
| Linux | documenté, **non testé** |
| Windows 10/11 | documenté, **non testé** |

## Installation

1. Installez [uv](https://docs.astral.sh/uv/) (gestionnaire d'environnement
   Python ; il installe aussi Python si nécessaire).
   - macOS / Linux : `curl -LsSf https://astral.sh/uv/install.sh | sh`
   - Windows (PowerShell) :
     `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"`
2. Dans ce dossier `code/` :

   ```bash
   uv sync --locked
   ```

   Les versions exactes sont figées dans `pyproject.toml` et `uv.lock`.

## Essais sans clé et sans coût

```bash
uv run pytest                 # tous les tests, sans réseau
uv run assistant demo         # mission simulée (FakeModel)
uv run assistant search "dépôt de garantie"
uv run assistant search --bm25 "annulation 24 heures"
```

Choisissez la langue du dossier de démonstration avec `ASSISTANT_LANG`
(`fr` ou `de` pour l'instant ; `en` et `es` à venir).

## Interface web (chapitre 11, facultative)

Mode simulé par défaut. Sans `ASSISTANT_UI_PASSWORD`, la page reste fermée.

```bash
uv sync --locked --extra interface
uv run assistant interface-demo    # sa logique, simulée, dans le terminal
uv run --extra interface pytest tests/test_step11.py
uv run --extra interface streamlit run src/assistant/step11/app.py \
    --server.address 127.0.0.1 --server.headless true \
    --browser.gatherUsageStats false
```

`experimental/docker/` : ressource complémentaire **expérimentale, jamais construite ni testée**, hors du parcours du livre.
Aucun déploiement n'a été testé, sur aucun hébergeur.

## Configurer une clé API (essais réels, payants)

L'usage de l'API Claude est facturé séparément des abonnements à
l'interface de discussion (les forfaits Max, Ultra et Team incluent des
crédits API mensuels : voir docs/sources.md, P5). Ne collez jamais votre clé dans une conversation,
un ticket ou un fichier versionné.

1. Créez une clé dans la console Claude (https://platform.claude.com/).
2. Copiez le modèle de configuration :
   - macOS / Linux : `cp .env.example .env`
   - Windows (PowerShell) : `Copy-Item .env.example .env`
3. Ouvrez `.env` dans votre éditeur et renseignez `ANTHROPIC_API_KEY`,
   `AGENT_MODEL`, puis `ASSISTANT_ALLOW_LIVE=1`. Le fichier `.env` est exclu
   du dépôt par `.gitignore`.

Les commandes payantes refusent de s'exécuter tant que
`ASSISTANT_ALLOW_LIVE` ne vaut pas `1`.

```bash
uv run assistant ask "Quel est le montant du dépôt de garantie ?"
uv run assistant-live plan              # bornes, aucun appel
uv run assistant-live dryrun --block A  # modèles simulés (A, B, C ou D)
uv run assistant-live run --block A --yes
uv run assistant evaluate --dry-run     # comparaison du ch. 9, simulée
```

`assistant-live run` suit `docs/protocole-essais.md` : blocs lancés dans
l'ordre, plafond total de 2,00 $ vérifié avant chaque appel (`budget.py`),
`max_tokens` 4 096. `assistant ask` est plafonné par
`ASSISTANT_MAX_USD` (0,10 $ par défaut). Fixez aussi une limite de dépense
dans la console (page *Billing*) : c'est la barrière côté serveur.

## Organisation

```
src/assistant/
  llm.py            couche d'accès au modèle + FakeModel
  llm_anthropic.py  seul module qui importe le SDK anthropic
  policy.py         restrictions de fichiers (lecture, écriture)
  approval.py       validation humaine d'une action exacte
  corpus.py         chargement des documents et passages
  runstate.py       état d'exécution et limites (chapitre 3)
  step03/           boucle sans outils
  step04/           outils et boucle avec outils (chapitre 4)
  step05/           BM25 et contrôles des références (chapitre 5)
  solutions/        corrigés des exercices
  prompts/          instructions système par langue
demo_data/<lang>/   documents Rivelune (CC BY 4.0 proposée, fictifs)
workspace/notes/    seul dossier où l'agent peut écrire (créé au besoin)
outbox/             « envois » simulés, après validation humaine
```

Licence du code : MIT (fichier `LICENSE`, préparé, non publié). Données : CC BY 4.0 proposée, dans la seule mesure des droits détenus (non publié). Voir `../LICENSES.md`.
