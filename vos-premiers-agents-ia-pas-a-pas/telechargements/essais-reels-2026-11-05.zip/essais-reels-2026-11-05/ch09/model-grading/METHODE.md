# Évaluation automatisée (ajoutée après les expériences)

- **Pourquoi :** la notation humaine prévue a été abandonnée par l'auteur (voir `../grading/ABANDONNEE.md`). Le plan fixé avant les essais excluait tout juge modèle : ce changement de méthode est postérieur aux expériences, qui restent inchangées.
- **Quoi :** `claude-sonnet-5-5`, effort `medium`, `max_tokens` 2 000, sortie structurée. Code : `code/src/assistant/step09/model_grading.py`. Commande : `uv run assistant evaluate --model-grade --max-usd 2.95 --yes` (payante).
- **Entrée, à l'aveugle :** la feuille `sheet-1.csv` (question, points attendus, réponse finale commune, critères applicables), sans architecture, coût ni durée. Pas les documents : les sources sont jugées sur les extraits cités, comme le prévoyait la consigne humaine.
- **Contrôles :** deux passages complets ; 5 cas inventés dont les notes ont été fixées d'avance par l'assistant (pas par une personne).
- **Résultat :** `report.txt` ; détail, raisons comprises : `pass-*.jsonl`, `controls-*.jsonl`. Coût compté : 106 tentatives, 0,53 $.
- **Biais connus :** même fournisseur que le modèle évalué ; style reconnaissable ; tendance possible à l'indulgence : la réponse `final:2:f5-storm:team:1` contient une réserve contredite par `remboursement#p04`, signalée par le vérificateur du workflow, et notée 2 en exactitude aux deux passages ; points attendus écrits par nous ; deux cas de contrôle notés autrement que prévu, de façon identique aux deux passages.
- **Ce n'est pas** un jugement humain, ni une preuve indépendante.
