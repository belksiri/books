# Notation humaine abandonnée

Le 2026-11-05, l'auteur a renoncé à la notation humaine à l'aveugle. **Aucune note n'a été saisie** : `sheet-1.csv` et `reservations-1.csv` sont restés vierges (0 ligne signée, 0 critère rempli). Ces fichiers sont conservés tels quels, comme trace ; ils ne contiennent aucune évaluation humaine, même partielle.

`key-1.json` (correspondance des réponses) a servi ensuite à rapporter l'évaluation automatisée de `../model-grading/`, qui n'est pas une évaluation humaine.
