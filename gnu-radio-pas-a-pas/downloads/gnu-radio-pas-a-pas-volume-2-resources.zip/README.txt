GNU Radio pas a pas — Volume 2
Modulations, communications numériques et RTL-SDR
Chapitres CH27 à CH42

Belk Siri — ressources du lecteur v1.0.0 (2026-09-20)

===========================================================================
CE QUE CONTIENT CETTE ARCHIVE
===========================================================================

16 fichiers, 631172 octets.

  flowgraphs/CHnn/   les montages d'exemple des chapitres
  flowgraphs/TP-nn/  les montages des travaux pratiques

Le fichier son book-audio.wav est depose DANS le dossier de chaque travail
pratique qui le lit. Les montages le designent par son nom seul, donc dans
le dossier courant : il doit rester a cote du fichier .grc. Copiez le
dossier entier, pas seulement le .grc.

Deux fichiers ne sont PAS fournis, parce que c'est vous qui les produisez :
echantillons.iq, ecrit par le montage du TP 8, et le fichier .cfile
d'echantillons reels enregistre au TP 18.

L'organisation est celle que le livre annonce a la section « Recuperer et
utiliser les fichiers du livre » : un dossier par chapitre ou par travail
pratique, nomme d'apres son identifiant. Le nom du fichier reprend
l'identifiant du montage en minuscules ; il est aussi inscrit dans le bloc
Options, ce qui permet de le retrouver apres un changement de nom.

===========================================================================
VERSIONS DE REFERENCE
===========================================================================

  GNU Radio    3.10.12.0
  Radioconda   2025.03.14 (osx-arm64)
  Systeme      macOS 26.6.2, Apple Silicon

Les montages ont ete enregistres avec GNU Radio 3.10.12.0. Ouvrez-les avec
la meme version, ou une version plus recente de la serie 3.10. Une version
plus ancienne ne saura pas les lire : le format de fichier a change entre
3.7 et 3.8.

===========================================================================
DEMARRER
===========================================================================

1. Decompressez cette archive dans votre dossier de travail.
2. Copiez le dossier du chapitre qui vous interesse dans votre propre
   dossier flowgraphs/, puis travaillez sur la copie. Les exercices vous
   feront modifier des valeurs ; l'original permet de revenir a l'etat de
   depart sans retelecharger.
3. Ouvrez le fichier .grc dans GNU Radio Companion (menu File, puis Open).
4. Generez avec F5, executez avec F6, arretez avec F7.

Le programme Python que GRC ecrit a cote du fichier .grc est reconstruit a
chaque generation. Il n'est pas fourni ici, et il n'y a jamais lieu de le
modifier ni de le sauvegarder.

===========================================================================
MATERIEL
===========================================================================

5 montage(s) de cette archive exigent un recepteur RTL-SDR branche.
Les autres fonctionnent en simulation, sans aucun materiel.

===========================================================================
CE QUI A REELLEMENT ETE VERIFIE
===========================================================================

macOS 26.6.2, Apple Silicon
  Systeme de reference du livre. Chaine complete verifiee : chargement des
  definitions de blocs, ouverture des montages, generation, execution.
  Sortie audio verifiee avec ecoute confirmee (ton de 440 Hz, 3 secondes).

Windows 11 Pro 25H2 (18/09/2026)
  Installation et execution verifiees : installeur controle, Radioconda
  isole, GRC lance, trois montages sans materiel executes — 39 points sur 39.
  N'ONT PAS ETE ESSAYES : l'assistant graphique d'installation, l'invite
  « radioconda Prompt », la SORTIE AUDIO, et tout materiel radio — donc le
  pilote WinUSB installe avec Zadig.

Recepteur RTL-SDR
  Les mesures des chapitres 34 a 37 ont ete faites avec un boitier RTL2832U
  a tuner R820T reellement branche, antenne raccordee, emissions reellement
  recues.
  LE RTL-SDR BLOG V3, MODELE DE REFERENCE DU LIVRE, N'A PAS ETE ESSAYE.
  AUCUNE ECOUTE n'a ete validee pendant ces seances : aucun son n'y a ete
  produit ni entendu.

Aucune autre configuration n'a ete essayee. Ce qui n'est pas ecrit ici n'a
pas ete verifie.

===========================================================================
LICENCE
===========================================================================

(c) 2026 Belk Siri. Tous droits reserves.

Ces fichiers sont mis a disposition pour accompagner le livre « GNU Radio
pas a pas ». Leur telechargement et leur usage personnel sont autorises.
Aucune licence de reutilisation, de modification publique ou de
redistribution n'est accordee a ce stade.

Le fichier audio/book-audio.wav est une synthese originale produite pour le
livre : six notes aux frequences exactes 220, 330, 440, 550, 440 et 220 Hz,
44 100 echantillons par seconde, une voie, 16 bits, 6 secondes. Il ne
contient aucun enregistrement de tiers et aucune voix.

Les montages .grc sont des fichiers texte crees pour ce livre. Ils ne
contiennent ni logo, ni code, ni ressource appartenant au projet GNU Radio.

===========================================================================
NON-AFFILIATION
===========================================================================

GNU Radio est cite comme le logiciel etudie dans cet ouvrage. Cette
publication independante n'est ni editee, ni parrainee, ni approuvee par le
projet GNU Radio ou par la Free Software Foundation.

===========================================================================
VERIFIER CETTE ARCHIVE
===========================================================================

Le fichier MANIFEST.json donne le chemin, la taille et l'empreinte SHA-256
de chaque fichier. Pour verifier un fichier :

  macOS   shasum -a 256 flowgraphs/TP-03/fg_tp03_001.grc
  Windows certutil -hashfile flowgraphs\TP-03\fg_tp03_001.grc SHA256
  Linux   sha256sum flowgraphs/TP-03/fg_tp03_001.grc

L'empreinte de l'archive elle-meme est publiee sur la page du volume :
https://belksiri.github.io/books/gnu-radio-pas-a-pas/fr/volume-2/

===========================================================================
PAGE DU LIVRE
===========================================================================

https://belksiri.github.io/books/gnu-radio-pas-a-pas/

Corrections, mises a jour et signalement de probleme s'y trouvent.
